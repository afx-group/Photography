import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, Filter, Grid, List, SortAsc, Calendar, Camera, MapPin, Tag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import ImagePreviewModal from "@/components/ImagePreviewModal";

interface PortfolioImage {
  id: string;
  src: string;
  alt: string;
  title: string;
  description: string;
  category: string;
  subcategory?: string;
  location?: string;
  date: string;
  camera?: string;
  lens?: string;
  settings?: string;
  tags: string[];
  featured: boolean;
  award?: string;
  client?: string;
}

// Extended portfolio data with metadata
const portfolioImages: PortfolioImage[] = [
  {
    id: "1",
    src: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
    alt: "Scottish Highlands at sunrise",
    title: "Highland Dawn",
    description: "The first light of dawn breaks over the misty Scottish Highlands, creating an ethereal landscape that speaks to the soul.",
    category: "Landscape",
    subcategory: "Mountains",
    location: "Scottish Highlands",
    date: "2023-08-15",
    camera: "Canon EOS R5",
    lens: "24-70mm f/2.8",
    settings: "ISO 100, f/8, 1/125s",
    tags: ["sunrise", "mountains", "mist", "scotland", "dramatic"],
    featured: true,
    award: "Nature Photography Awards 2023"
  },
  {
    id: "2",
    src: "https://images.unsplash.com/photo-1439066615861-d1af74d74000?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
    alt: "Crystal clear mountain lake",
    title: "Mirror Lake",
    description: "Perfect reflections in a pristine mountain lake, showcasing nature's symmetry.",
    category: "Landscape",
    subcategory: "Water",
    location: "Lake District",
    date: "2023-07-22",
    camera: "Canon EOS R5",
    lens: "16-35mm f/2.8",
    settings: "ISO 64, f/11, 2s",
    tags: ["lake", "reflections", "calm", "symmetry", "peaceful"],
    featured: true
  },
  {
    id: "3",
    src: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
    alt: "Professional corporate headshot",
    title: "Executive Portrait",
    description: "A confident corporate executive captured with natural lighting and authentic expression.",
    category: "Portrait",
    subcategory: "Corporate",
    location: "London Studio",
    date: "2023-09-10",
    camera: "Canon EOS R6",
    lens: "85mm f/1.4",
    settings: "ISO 200, f/2.8, 1/160s",
    tags: ["corporate", "professional", "headshot", "business", "confident"],
    featured: false,
    client: "Chen & Associates"
  },
  {
    id: "4",
    src: "https://images.unsplash.com/photo-1494790108755-2616c96c3639?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
    alt: "Natural light portrait",
    title: "Golden Hour",
    description: "Soft natural light creates a warm, intimate portrait that captures genuine emotion.",
    category: "Portrait",
    subcategory: "Fine Art",
    location: "Edinburgh",
    date: "2023-06-18",
    camera: "Canon EOS R6",
    lens: "85mm f/1.4",
    settings: "ISO 400, f/1.8, 1/200s",
    tags: ["golden hour", "natural light", "emotion", "intimate", "warmth"],
    featured: true
  },
  {
    id: "5",
    src: "https://images.unsplash.com/photo-1519741497674-611481863552?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
    alt: "Wedding ceremony moment",
    title: "The Promise",
    description: "A tender moment during the wedding ceremony, capturing the emotion and significance of the vows.",
    category: "Wedding",
    subcategory: "Ceremony",
    location: "Stirling Castle",
    date: "2023-07-15",
    camera: "Canon EOS R6",
    lens: "70-200mm f/2.8",
    settings: "ISO 800, f/2.8, 1/250s",
    tags: ["wedding", "ceremony", "emotion", "couple", "traditional"],
    featured: true,
    client: "Wilson Wedding"
  },
  {
    id: "6",
    src: "https://images.unsplash.com/photo-1542038784456-1ea8e935640e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
    alt: "Corporate event photography",
    title: "Innovation Summit",
    description: "Capturing the energy and collaboration at a major technology conference.",
    category: "Event",
    subcategory: "Corporate",
    location: "Glasgow Conference Centre",
    date: "2023-09-25",
    camera: "Canon EOS R5",
    lens: "24-70mm f/2.8",
    settings: "ISO 1600, f/4, 1/200s",
    tags: ["conference", "technology", "networking", "business", "innovation"],
    featured: false,
    client: "Tech Scotland"
  }
];

const categories = ["All", "Landscape", "Portrait", "Wedding", "Event"];
const subcategories = ["Mountains", "Water", "Corporate", "Fine Art", "Ceremony"];
const locations = ["Scottish Highlands", "Lake District", "London Studio", "Edinburgh", "Stirling Castle", "Glasgow Conference Centre"];

type ViewMode = "grid" | "list";
type SortOption = "date" | "title" | "category" | "featured";

export default function AdvancedPortfolioSection() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [selectedSubcategories, setSelectedSubcategories] = useState<string[]>([]);
  const [selectedLocations, setSelectedLocations] = useState<string[]>([]);
  const [showFeaturedOnly, setShowFeaturedOnly] = useState(false);
  const [sortBy, setSortBy] = useState<SortOption>("date");
  const [viewMode, setViewMode] = useState<ViewMode>("grid");
  const [showFilters, setShowFilters] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const filteredImages = useMemo(() => {
    let filtered = portfolioImages;

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(image => 
        image.title.toLowerCase().includes(query) ||
        image.description.toLowerCase().includes(query) ||
        image.tags.some(tag => tag.toLowerCase().includes(query)) ||
        image.location?.toLowerCase().includes(query) ||
        image.category.toLowerCase().includes(query)
      );
    }

    // Category filter
    if (selectedCategory !== "All") {
      filtered = filtered.filter(image => image.category === selectedCategory);
    }

    // Subcategory filter
    if (selectedSubcategories.length > 0) {
      filtered = filtered.filter(image => 
        image.subcategory && selectedSubcategories.includes(image.subcategory)
      );
    }

    // Location filter
    if (selectedLocations.length > 0) {
      filtered = filtered.filter(image => 
        image.location && selectedLocations.includes(image.location)
      );
    }

    // Featured filter
    if (showFeaturedOnly) {
      filtered = filtered.filter(image => image.featured);
    }

    // Sort
    filtered.sort((a, b) => {
      switch (sortBy) {
        case "date":
          return new Date(b.date).getTime() - new Date(a.date).getTime();
        case "title":
          return a.title.localeCompare(b.title);
        case "category":
          return a.category.localeCompare(b.category);
        case "featured":
          return Number(b.featured) - Number(a.featured);
        default:
          return 0;
      }
    });

    return filtered;
  }, [searchQuery, selectedCategory, selectedSubcategories, selectedLocations, showFeaturedOnly, sortBy]);

  const handleImageClick = (index: number) => {
    setCurrentImageIndex(index);
    setIsModalOpen(true);
  };

  const toggleSubcategory = (subcategory: string) => {
    setSelectedSubcategories(prev => 
      prev.includes(subcategory) 
        ? prev.filter(s => s !== subcategory)
        : [...prev, subcategory]
    );
  };

  const toggleLocation = (location: string) => {
    setSelectedLocations(prev => 
      prev.includes(location) 
        ? prev.filter(l => l !== location)
        : [...prev, location]
    );
  };

  const clearFilters = () => {
    setSearchQuery("");
    setSelectedCategory("All");
    setSelectedSubcategories([]);
    setSelectedLocations([]);
    setShowFeaturedOnly(false);
  };

  return (
    <section id="portfolio-advanced" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl sm:text-5xl font-thin text-gradient mb-6">
            Explore My Work
          </h2>
          <p className="text-xl text-apple-gray max-w-3xl mx-auto">
            Browse through my complete portfolio with advanced search and filtering capabilities.
          </p>
        </motion.div>

        {/* Search and Filter Controls */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-8"
        >
          <Card className="p-6">
            {/* Top Row: Search, Category, View Mode */}
            <div className="flex flex-col lg:flex-row gap-4 mb-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search by title, description, tags, or location..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-full lg:w-48">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map(category => (
                    <SelectItem key={category} value={category}>{category}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <div className="flex gap-2">
                <Button
                  variant={showFilters ? "default" : "outline"}
                  onClick={() => setShowFilters(!showFilters)}
                >
                  <Filter className="w-4 h-4 mr-2" />
                  Filters
                </Button>
                
                <div className="flex rounded-md border">
                  <Button
                    variant={viewMode === "grid" ? "default" : "ghost"}
                    size="sm"
                    onClick={() => setViewMode("grid")}
                    className="rounded-r-none"
                  >
                    <Grid className="w-4 h-4" />
                  </Button>
                  <Button
                    variant={viewMode === "list" ? "default" : "ghost"}
                    size="sm"
                    onClick={() => setViewMode("list")}
                    className="rounded-l-none border-l"
                  >
                    <List className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Advanced Filters */}
            <AnimatePresence>
              {showFilters && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden"
                >
                  <Separator className="my-4" />
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {/* Subcategories */}
                    <div>
                      <h4 className="font-medium mb-3 flex items-center">
                        <Tag className="w-4 h-4 mr-2" />
                        Subcategories
                      </h4>
                      <div className="space-y-2">
                        {subcategories.map(subcategory => (
                          <div key={subcategory} className="flex items-center space-x-2">
                            <Checkbox
                              id={`sub-${subcategory}`}
                              checked={selectedSubcategories.includes(subcategory)}
                              onCheckedChange={() => toggleSubcategory(subcategory)}
                            />
                            <label htmlFor={`sub-${subcategory}`} className="text-sm">
                              {subcategory}
                            </label>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Locations */}
                    <div>
                      <h4 className="font-medium mb-3 flex items-center">
                        <MapPin className="w-4 h-4 mr-2" />
                        Locations
                      </h4>
                      <div className="space-y-2">
                        {locations.map(location => (
                          <div key={location} className="flex items-center space-x-2">
                            <Checkbox
                              id={`loc-${location}`}
                              checked={selectedLocations.includes(location)}
                              onCheckedChange={() => toggleLocation(location)}
                            />
                            <label htmlFor={`loc-${location}`} className="text-sm">
                              {location}
                            </label>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Sort and Options */}
                    <div>
                      <h4 className="font-medium mb-3 flex items-center">
                        <SortAsc className="w-4 h-4 mr-2" />
                        Sort & Options
                      </h4>
                      <div className="space-y-3">
                        <Select value={sortBy} onValueChange={(value: SortOption) => setSortBy(value)}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="date">Latest First</SelectItem>
                            <SelectItem value="title">Title A-Z</SelectItem>
                            <SelectItem value="category">Category</SelectItem>
                            <SelectItem value="featured">Featured First</SelectItem>
                          </SelectContent>
                        </Select>
                        
                        <div className="flex items-center space-x-2">
                          <Checkbox
                            id="featured-only"
                            checked={showFeaturedOnly}
                            onCheckedChange={(checked) => setShowFeaturedOnly(checked === true)}
                          />
                          <label htmlFor="featured-only" className="text-sm">
                            Featured only
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-between items-center mt-4 pt-4 border-t">
                    <span className="text-sm text-gray-600">
                      {filteredImages.length} image{filteredImages.length !== 1 ? 's' : ''} found
                    </span>
                    <Button variant="ghost" onClick={clearFilters}>
                      Clear all filters
                    </Button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </Card>
        </motion.div>

        {/* Results */}
        <AnimatePresence mode="wait">
          <motion.div
            key={`${viewMode}-${filteredImages.length}`}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.4 }}
          >
            {filteredImages.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-xl text-gray-600">No images match your current filters.</p>
                <Button onClick={clearFilters} className="mt-4">
                  Clear filters
                </Button>
              </div>
            ) : viewMode === "grid" ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredImages.map((image, index) => (
                  <motion.div
                    key={image.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.4, delay: index * 0.05 }}
                    className="group cursor-pointer"
                    onClick={() => handleImageClick(index)}
                  >
                    <Card className="overflow-hidden hover:shadow-xl transition-all duration-300">
                      <div className="relative">
                        <img
                          src={image.src}
                          alt={image.alt}
                          className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        {image.featured && (
                          <Badge className="absolute top-2 left-2 bg-blue-600">Featured</Badge>
                        )}
                        {image.award && (
                          <Badge className="absolute top-2 right-2 bg-yellow-600">Award Winner</Badge>
                        )}
                        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-300 flex items-center justify-center">
                          <motion.div
                            initial={{ opacity: 0, scale: 0.8 }}
                            whileHover={{ opacity: 1, scale: 1 }}
                            className="text-white text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                          >
                            Click to view
                          </motion.div>
                        </div>
                      </div>
                      <CardContent className="p-4">
                        <h3 className="font-semibold text-lg mb-1">{image.title}</h3>
                        <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
                          <Badge variant="secondary">{image.category}</Badge>
                          <span className="flex items-center">
                            <Calendar className="w-3 h-3 mr-1" />
                            {new Date(image.date).getFullYear()}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600 line-clamp-2">{image.description}</p>
                        {image.location && (
                          <p className="text-xs text-gray-500 mt-2 flex items-center">
                            <MapPin className="w-3 h-3 mr-1" />
                            {image.location}
                          </p>
                        )}
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                {filteredImages.map((image, index) => (
                  <motion.div
                    key={image.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.03 }}
                    className="group cursor-pointer"
                    onClick={() => handleImageClick(index)}
                  >
                    <Card className="overflow-hidden hover:shadow-lg transition-all duration-300">
                      <div className="flex">
                        <img
                          src={image.src}
                          alt={image.alt}
                          className="w-32 h-32 object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <CardContent className="flex-1 p-4">
                          <div className="flex justify-between items-start mb-2">
                            <h3 className="font-semibold text-xl">{image.title}</h3>
                            <div className="flex gap-2">
                              {image.featured && <Badge className="bg-blue-600">Featured</Badge>}
                              {image.award && <Badge className="bg-yellow-600">Award</Badge>}
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-4 text-sm text-gray-600 mb-3">
                            <Badge variant="secondary">{image.category}</Badge>
                            <span className="flex items-center">
                              <Calendar className="w-3 h-3 mr-1" />
                              {new Date(image.date).toLocaleDateString()}
                            </span>
                            {image.location && (
                              <span className="flex items-center">
                                <MapPin className="w-3 h-3 mr-1" />
                                {image.location}
                              </span>
                            )}
                            {image.camera && (
                              <span className="flex items-center">
                                <Camera className="w-3 h-3 mr-1" />
                                {image.camera}
                              </span>
                            )}
                          </div>
                          
                          <p className="text-gray-600 mb-2">{image.description}</p>
                          
                          <div className="flex flex-wrap gap-1">
                            {image.tags.map(tag => (
                              <Badge key={tag} variant="outline" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        </CardContent>
                      </div>
                    </Card>
                  </motion.div>
                ))}
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Image Preview Modal */}
      <ImagePreviewModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        images={filteredImages}
        currentIndex={currentImageIndex}
        onIndexChange={setCurrentImageIndex}
      />
    </section>
  );
}
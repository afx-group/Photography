import { useState } from "react";
import { motion } from "framer-motion";
import { Book, Calendar, Download, Eye, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import BookViewer from "@/components/BookViewer";

interface Publication {
  id: string;
  title: string;
  description: string;
  coverImage: string;
  pdfUrl: string;
  publishDate: string;
  isbn?: string;
  pages: number;
  category: string;
  featured: boolean;
  price?: string;
  blurbUrl?: string;
}

// This will be populated with your actual publication data
const publications: Publication[] = [
  {
    id: "1",
    title: "Landscapes of Scotland",
    description: "A photographic journey through the dramatic landscapes of the Scottish Highlands, capturing the raw beauty and mystique of this ancient land.",
    coverImage: "https://images.unsplash.com/photo-1551632811-561732d1e306?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
    pdfUrl: "/publications/landscapes-scotland.pdf",
    publishDate: "2023",
    isbn: "978-1-234-56789-0",
    pages: 120,
    category: "Landscape",
    featured: true,
    price: "$45.00",
    blurbUrl: "https://www.blurb.com/b/example1"
  },
  {
    id: "2", 
    title: "Urban Shadows",
    description: "Exploring the interplay of light and shadow in metropolitan environments, revealing the hidden poetry of city life.",
    coverImage: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
    pdfUrl: "/publications/urban-shadows.pdf",
    publishDate: "2022",
    isbn: "978-1-234-56789-1",
    pages: 96,
    category: "Urban",
    featured: true,
    price: "$38.00",
    blurbUrl: "https://www.blurb.com/b/example2"
  },
  {
    id: "3",
    title: "Portraits in Time",
    description: "A collection of intimate portraits that capture the essence of human emotion and the stories etched in every face.",
    coverImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000",
    pdfUrl: "/publications/portraits-time.pdf",
    publishDate: "2021",
    pages: 80,
    category: "Portrait",
    featured: false,
    price: "$32.00",
    blurbUrl: "https://www.blurb.com/b/example3"
  }
];

export default function PublicationsSection() {
  const [selectedBook, setSelectedBook] = useState<Publication | null>(null);
  const [isBookViewerOpen, setIsBookViewerOpen] = useState(false);

  const openBookViewer = (publication: Publication) => {
    setSelectedBook(publication);
    setIsBookViewerOpen(true);
  };

  const closeBookViewer = () => {
    setIsBookViewerOpen(false);
    setSelectedBook(null);
  };

  const featuredBooks = publications.filter(pub => pub.featured);
  const otherBooks = publications.filter(pub => !pub.featured);

  return (
    <section id="publications" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl sm:text-5xl font-thin text-gradient mb-6">
            Published Works
          </h2>
          <p className="text-xl text-apple-gray max-w-3xl mx-auto">
            Explore my published photography books, each telling a unique story through carefully curated collections of images.
          </p>
        </motion.div>

        {/* Featured Publications */}
        {featuredBooks.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="mb-16"
          >
            <h3 className="text-3xl font-light text-apple-dark mb-8 text-center">
              Featured Publications
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {featuredBooks.map((publication, index) => (
                <motion.div
                  key={publication.id}
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                >
                  <Card className="group hover:shadow-2xl transition-all duration-300 overflow-hidden">
                    <div className="relative">
                      <img
                        src={publication.coverImage}
                        alt={publication.title}
                        className="w-full h-80 object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute top-4 left-4">
                        <Badge className="bg-blue-600 text-white">
                          <Star className="w-3 h-3 mr-1" />
                          Featured
                        </Badge>
                      </div>
                      <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-300 flex items-center justify-center">
                        <motion.div
                          initial={{ opacity: 0, scale: 0.8 }}
                          whileHover={{ opacity: 1, scale: 1 }}
                          className="opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                        >
                          <Button
                            onClick={() => openBookViewer(publication)}
                            className="bg-white text-black hover:bg-gray-100"
                          >
                            <Eye className="w-4 h-4 mr-2" />
                            Preview Book
                          </Button>
                        </motion.div>
                      </div>
                    </div>
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="text-xl mb-2">{publication.title}</CardTitle>
                          <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
                            <span className="flex items-center">
                              <Calendar className="w-4 h-4 mr-1" />
                              {publication.publishDate}
                            </span>
                            <span className="flex items-center">
                              <Book className="w-4 h-4 mr-1" />
                              {publication.pages} pages
                            </span>
                          </div>
                        </div>
                        {publication.price && (
                          <div className="text-right">
                            <div className="text-2xl font-bold text-blue-600">{publication.price}</div>
                          </div>
                        )}
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600 mb-4">{publication.description}</p>
                      <div className="flex space-x-3">
                        <Button
                          onClick={() => openBookViewer(publication)}
                          variant="outline"
                          className="flex-1"
                        >
                          <Eye className="w-4 h-4 mr-2" />
                          Preview
                        </Button>
                        {publication.blurbUrl && (
                          <Button
                            onClick={() => window.open(publication.blurbUrl, '_blank')}
                            className="flex-1 bg-blue-600 hover:bg-blue-700"
                          >
                            <Download className="w-4 h-4 mr-2" />
                            Order on Blurb
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Other Publications */}
        {otherBooks.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h3 className="text-3xl font-light text-apple-dark mb-8 text-center">
              All Publications
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {otherBooks.map((publication, index) => (
                <motion.div
                  key={publication.id}
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                >
                  <Card className="group hover:shadow-xl transition-all duration-300 overflow-hidden h-full">
                    <div className="relative">
                      <img
                        src={publication.coverImage}
                        alt={publication.title}
                        className="w-full h-60 object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-300 flex items-center justify-center">
                        <motion.div
                          initial={{ opacity: 0, scale: 0.8 }}
                          whileHover={{ opacity: 1, scale: 1 }}
                          className="opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                        >
                          <Button
                            onClick={() => openBookViewer(publication)}
                            size="sm"
                            className="bg-white text-black hover:bg-gray-100"
                          >
                            <Eye className="w-3 h-3 mr-1" />
                            Preview
                          </Button>
                        </motion.div>
                      </div>
                    </div>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg">{publication.title}</CardTitle>
                      <div className="flex items-center justify-between text-sm text-gray-600">
                        <span>{publication.publishDate}</span>
                        <Badge variant="secondary">{publication.category}</Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <p className="text-gray-600 text-sm mb-4 line-clamp-3">{publication.description}</p>
                      <div className="flex justify-between items-center">
                        <Button
                          onClick={() => openBookViewer(publication)}
                          variant="outline"
                          size="sm"
                        >
                          Preview
                        </Button>
                        {publication.price && (
                          <span className="font-semibold text-blue-600">{publication.price}</span>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </div>

      {/* Book Viewer Modal */}
      {selectedBook && (
        <BookViewer
          isOpen={isBookViewerOpen}
          onClose={closeBookViewer}
          pdfUrl={selectedBook.pdfUrl}
          title={selectedBook.title}
          description={selectedBook.description}
          publishDate={selectedBook.publishDate}
          isbn={selectedBook.isbn}
        />
      )}
    </section>
  );
}
import { useState, useRef } from "react";
import { motion } from "framer-motion";
import { 
  Plus, 
  Upload, 
  Download, 
  Search, 
  Filter,
  Edit3,
  Save,
  X,
  Check,
  Calendar,
  MapPin,
  Camera,
  Eye,
  Trash2
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import SmartPhotoUpload from "./SmartPhotoUpload";

interface Asset {
  id: number;
  afxId: string;
  fileName: string;
  title?: string;
  description?: string;
  category?: string;
  photographer: string;
  deviceUsed?: string;
  dateTaken?: string;
  gpsCoordinates?: string;
  copyrightStatus: string;
  licenseType?: string;
  featured: number;
  createdAt: string;
  updatedAt?: string;
  fileLocation?: string;
  shotTakenBy?: string;
  copyrightNotes?: string;
}

export default function AssetSpreadsheet() {
  const [searchQuery, setSearchQuery] = useState("");
  const [editingCell, setEditingCell] = useState<{ id: number; field: string } | null>(null);
  const [editValue, setEditValue] = useState("");
  const [showUploadDialog, setShowUploadDialog] = useState(false);
  const [newAsset, setNewAsset] = useState<Partial<Asset>>({
    photographer: "Andrew Gwynn",
    copyrightStatus: "All Rights Reserved"
  });

  const queryClient = useQueryClient();

  // Fetch assets with proper typing
  const { data: assets = [], isLoading } = useQuery({
    queryKey: ['/api/assets'],
    queryFn: async () => {
      const response = await apiRequest('/api/assets');
      return Array.isArray(response) ? response : [];
    }
  });

  // Create asset mutation
  const createAssetMutation = useMutation({
    mutationFn: (data: any) => apiRequest('/api/assets', 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/assets'] });
      setNewAsset({
        photographer: "Andrew Gwynn",
        copyrightStatus: "All Rights Reserved"
      });
    }
  });

  // Update asset mutation
  const updateAssetMutation = useMutation({
    mutationFn: ({ id, ...data }: any) => apiRequest(`/api/assets/${id}`, 'PATCH', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/assets'] });
      setEditingCell(null);
    }
  });

  const handleCellEdit = (asset: Asset, field: string) => {
    setEditingCell({ id: asset.id, field });
    setEditValue((asset as any)[field] || "");
  };

  const handleSaveEdit = () => {
    if (editingCell) {
      updateAssetMutation.mutate({
        id: editingCell.id,
        [editingCell.field]: editValue
      });
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSaveEdit();
    } else if (e.key === 'Escape') {
      setEditingCell(null);
    }
  };

  const handleMetadataExtracted = (metadata: any) => {
    setNewAsset({
      ...newAsset,
      fileName: metadata.fileName,
      title: metadata.title,
      description: metadata.description,
      photographer: metadata.photographer,
      deviceUsed: metadata.deviceUsed,
      dateTaken: metadata.dateTaken,
      gpsCoordinates: metadata.gpsCoordinates,
      copyrightStatus: metadata.copyrightStatus,
      fileLocation: metadata.filePath
    });
    setShowUploadDialog(false);
  };

  const handleCreateAsset = () => {
    if (newAsset.fileName) {
      createAssetMutation.mutate({
        ...newAsset,
        afxId: `AFX-${Date.now()}`,
        featured: 0
      });
    }
  };

  const filteredAssets = assets.filter((asset: Asset) =>
    searchQuery === "" ||
    asset.fileName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    asset.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    asset.afxId.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const columns = [
    { key: 'afxId', label: 'AFX ID', width: '120px' },
    { key: 'fileName', label: 'File Name', width: '200px' },
    { key: 'title', label: 'Title', width: '200px' },
    { key: 'category', label: 'Category', width: '120px' },
    { key: 'photographer', label: 'Shot Taken By', width: '150px' },
    { key: 'deviceUsed', label: 'Device Used', width: '150px' },
    { key: 'dateTaken', label: 'Date Taken', width: '120px' },
    { key: 'gpsCoordinates', label: 'GPS Coordinates', width: '150px' },
    { key: 'copyrightStatus', label: 'Copyright Status', width: '150px' },
    { key: 'licenseType', label: 'License', width: '120px' },
    { key: 'featured', label: 'Featured', width: '100px' },
    { key: 'fileLocation', label: 'File Location', width: '200px' }
  ];

  const renderCell = (asset: Asset, column: any) => {
    const isEditing = editingCell?.id === asset.id && editingCell?.field === column.key;
    const value = (asset as any)[column.key] || '';

    if (isEditing) {
      return (
        <div className="flex items-center space-x-1">
          <Input
            value={editValue}
            onChange={(e) => setEditValue(e.target.value)}
            onKeyDown={handleKeyPress}
            className="h-8 text-xs"
            autoFocus
          />
          <Button size="sm" variant="ghost" onClick={handleSaveEdit}>
            <Check className="w-3 h-3" />
          </Button>
          <Button size="sm" variant="ghost" onClick={() => setEditingCell(null)}>
            <X className="w-3 h-3" />
          </Button>
        </div>
      );
    }

    return (
      <div
        className="cursor-pointer hover:bg-gray-50 p-1 rounded text-xs min-h-[24px] flex items-center"
        onClick={() => handleCellEdit(asset, column.key)}
      >
        {column.key === 'featured' ? (
          <Badge variant={value ? "default" : "secondary"}>
            {value ? "Yes" : "No"}
          </Badge>
        ) : column.key === 'dateTaken' && value ? (
          <span className="flex items-center">
            <Calendar className="w-3 h-3 mr-1" />
            {new Date(value).toLocaleDateString()}
          </span>
        ) : column.key === 'gpsCoordinates' && value ? (
          <span className="flex items-center">
            <MapPin className="w-3 h-3 mr-1" />
            {value.substring(0, 15)}...
          </span>
        ) : column.key === 'deviceUsed' && value ? (
          <span className="flex items-center">
            <Camera className="w-3 h-3 mr-1" />
            {value}
          </span>
        ) : (
          <span className="truncate">{value || '-'}</span>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-4">
      {/* Header Actions */}
      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Search assets..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 w-64"
            />
          </div>
          <Button variant="outline" size="sm">
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="sm">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
          <Button onClick={() => setShowUploadDialog(true)} size="sm">
            <Upload className="w-4 h-4 mr-2" />
            Smart Upload
          </Button>
          <Button 
            onClick={() => setNewAsset({ photographer: "Andrew Gwynn", copyrightStatus: "All Rights Reserved" })}
            size="sm"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Row
          </Button>
        </div>
      </div>

      {/* New Asset Row */}
      {newAsset.fileName && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 space-y-2">
          <h4 className="font-medium text-blue-900">New Asset Ready</h4>
          <div className="grid grid-cols-3 gap-4 text-sm">
            <div><strong>File:</strong> {newAsset.fileName}</div>
            <div><strong>Title:</strong> {newAsset.title}</div>
            <div><strong>Camera:</strong> {newAsset.deviceUsed}</div>
          </div>
          <div className="flex justify-end space-x-2">
            <Button variant="outline" size="sm" onClick={() => setNewAsset({ photographer: "Andrew Gwynn", copyrightStatus: "All Rights Reserved" })}>
              Cancel
            </Button>
            <Button size="sm" onClick={handleCreateAsset} disabled={createAssetMutation.isPending}>
              {createAssetMutation.isPending ? "Adding..." : "Add to Database"}
            </Button>
          </div>
        </div>
      )}

      {/* Spreadsheet Table */}
      <div className="border rounded-lg overflow-hidden bg-white">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="w-12 p-2 text-left text-xs font-medium text-gray-500 uppercase">
                  #
                </th>
                {columns.map((column) => (
                  <th
                    key={column.key}
                    className="p-2 text-left text-xs font-medium text-gray-500 uppercase border-r"
                    style={{ width: column.width }}
                  >
                    {column.label}
                  </th>
                ))}
                <th className="w-20 p-2 text-left text-xs font-medium text-gray-500 uppercase">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {isLoading ? (
                <tr>
                  <td colSpan={columns.length + 2} className="p-8 text-center">
                    <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600 mx-auto"></div>
                    <p className="mt-2 text-sm text-gray-500">Loading assets...</p>
                  </td>
                </tr>
              ) : filteredAssets.length === 0 ? (
                <tr>
                  <td colSpan={columns.length + 2} className="p-8 text-center text-gray-500">
                    No assets found. Use Smart Upload to add your first photo.
                  </td>
                </tr>
              ) : (
                filteredAssets.map((asset: Asset, index: number) => (
                  <tr key={asset.id} className="hover:bg-gray-50">
                    <td className="p-2 text-xs text-gray-500">
                      {index + 1}
                    </td>
                    {columns.map((column) => (
                      <td
                        key={column.key}
                        className="p-1 border-r"
                        style={{ width: column.width }}
                      >
                        {renderCell(asset, column)}
                      </td>
                    ))}
                    <td className="p-2">
                      <div className="flex space-x-1">
                        <Button variant="ghost" size="sm">
                          <Eye className="w-3 h-3" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <Trash2 className="w-3 h-3 text-red-500" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Results Summary */}
      <div className="text-sm text-gray-600">
        Showing {filteredAssets.length} of {assets.length} assets
      </div>

      {/* Smart Upload Dialog */}
      <Dialog open={showUploadDialog} onOpenChange={setShowUploadDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Smart Photo Upload</DialogTitle>
          </DialogHeader>
          <SmartPhotoUpload
            onMetadataExtracted={handleMetadataExtracted}
            onClose={() => setShowUploadDialog(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
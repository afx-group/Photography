import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight, X, Download, Share2, ZoomIn, ZoomOut, RotateCw } from "lucide-react";
import { Button } from "@/components/ui/button";

interface BookViewerProps {
  isOpen: boolean;
  onClose: () => void;
  pdfUrl: string;
  title: string;
  description?: string;
  publishDate?: string;
  isbn?: string;
}

interface Page {
  pageNumber: number;
  imageUrl: string;
  width: number;
  height: number;
}

export default function BookViewer({
  isOpen,
  onClose,
  pdfUrl,
  title,
  description,
  publishDate,
  isbn
}: BookViewerProps) {
  const [pages, setPages] = useState<Page[]>([]);
  const [currentPage, setCurrentPage] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);
  const [isFlipping, setIsFlipping] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Convert PDF to pages (this would need PDF.js integration)
  useEffect(() => {
    if (isOpen && pdfUrl) {
      loadPdfPages();
    }
  }, [isOpen, pdfUrl]);

  const loadPdfPages = async () => {
    setIsLoading(true);
    try {
      // This is where PDF.js would be used to convert PDF pages to images
      // For now, creating placeholder structure
      const mockPages: Page[] = Array.from({ length: 20 }, (_, i) => ({
        pageNumber: i + 1,
        imageUrl: `https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1000&page=${i}`,
        width: 800,
        height: 1000
      }));
      setPages(mockPages);
      setCurrentPage(0);
    } catch (error) {
      console.error("Failed to load PDF:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const nextPage = () => {
    if (currentPage < pages.length - 2) {
      setIsFlipping(true);
      setTimeout(() => {
        setCurrentPage(currentPage + 2);
        setIsFlipping(false);
      }, 300);
    }
  };

  const prevPage = () => {
    if (currentPage > 0) {
      setIsFlipping(true);
      setTimeout(() => {
        setCurrentPage(Math.max(0, currentPage - 2));
        setIsFlipping(false);
      }, 300);
    }
  };

  const goToPage = (pageNum: number) => {
    if (pageNum >= 0 && pageNum < pages.length) {
      setIsFlipping(true);
      setTimeout(() => {
        setCurrentPage(pageNum);
        setIsFlipping(false);
      }, 300);
    }
  };

  const handleZoomIn = () => setZoom(Math.min(zoom * 1.2, 3));
  const handleZoomOut = () => setZoom(Math.max(zoom / 1.2, 0.5));
  const handleRotate = () => setRotation((rotation + 90) % 360);

  const handleDownload = () => {
    const link = document.createElement("a");
    link.href = pdfUrl;
    link.download = `${title}.pdf`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: title,
          text: description || "Check out this photography book",
          url: window.location.href,
        });
      } catch (error) {
        console.log("Share cancelled");
      }
    } else {
      navigator.clipboard.writeText(window.location.href);
    }
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;
      
      switch (e.key) {
        case "Escape":
          onClose();
          break;
        case "ArrowLeft":
          prevPage();
          break;
        case "ArrowRight":
          nextPage();
          break;
        case "+":
          handleZoomIn();
          break;
        case "-":
          handleZoomOut();
          break;
      }
    };

    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, currentPage]);

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 bg-black bg-opacity-95 backdrop-blur-sm"
        onClick={onClose}
      >
        {/* Header */}
        <motion.div
          initial={{ y: -50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: -50, opacity: 0 }}
          className="absolute top-0 left-0 right-0 z-10 p-4 bg-gradient-to-b from-black/70 to-transparent"
        >
          <div className="flex justify-between items-center max-w-7xl mx-auto">
            <div className="text-white">
              <h3 className="text-xl font-semibold">{title}</h3>
              <div className="flex items-center space-x-4 text-sm text-gray-300 mt-1">
                <span>Page {currentPage + 1}-{Math.min(currentPage + 2, pages.length)} of {pages.length}</span>
                {publishDate && <span>• {publishDate}</span>}
                {isbn && <span>• ISBN: {isbn}</span>}
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleZoomOut}
                className="text-white hover:bg-white/20"
              >
                <ZoomOut className="w-4 h-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleZoomIn}
                className="text-white hover:bg-white/20"
              >
                <ZoomIn className="w-4 h-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleRotate}
                className="text-white hover:bg-white/20"
              >
                <RotateCw className="w-4 h-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleShare}
                className="text-white hover:bg-white/20"
              >
                <Share2 className="w-4 h-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleDownload}
                className="text-white hover:bg-white/20"
              >
                <Download className="w-4 h-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={onClose}
                className="text-white hover:bg-white/20"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </motion.div>

        {/* Book Container */}
        <div 
          className="flex items-center justify-center min-h-screen p-4 pt-20 pb-20"
          onClick={(e) => e.stopPropagation()}
          ref={containerRef}
        >
          {isLoading ? (
            <div className="text-white text-center">
              <div className="w-16 h-16 border-4 border-white border-t-transparent rounded-full animate-spin mx-auto mb-4" />
              <p>Loading book...</p>
            </div>
          ) : (
            <div className="relative">
              {/* Navigation Arrows */}
              {currentPage > 0 && (
                <Button
                  variant="ghost"
                  size="lg"
                  onClick={prevPage}
                  disabled={isFlipping}
                  className="absolute left-4 top-1/2 -translate-y-1/2 z-10 text-white hover:bg-white/20 rounded-full w-12 h-12"
                >
                  <ChevronLeft className="w-6 h-6" />
                </Button>
              )}
              
              {currentPage < pages.length - 2 && (
                <Button
                  variant="ghost"
                  size="lg"
                  onClick={nextPage}
                  disabled={isFlipping}
                  className="absolute right-4 top-1/2 -translate-y-1/2 z-10 text-white hover:bg-white/20 rounded-full w-12 h-12"
                >
                  <ChevronRight className="w-6 h-6" />
                </Button>
              )}

              {/* Book Pages */}
              <div 
                className="relative perspective-1000"
                style={{ 
                  transform: `scale(${zoom}) rotate(${rotation}deg)`,
                  transition: "transform 0.3s ease"
                }}
              >
                <div className="flex shadow-2xl rounded-lg overflow-hidden">
                  {/* Left Page */}
                  {pages[currentPage] && (
                    <motion.div
                      key={`left-${currentPage}`}
                      initial={isFlipping ? { rotateY: -180, opacity: 0 } : { rotateY: 0, opacity: 1 }}
                      animate={{ rotateY: 0, opacity: 1 }}
                      transition={{ duration: 0.6, ease: "easeInOut" }}
                      className="transform-gpu"
                      style={{ transformOrigin: "right center" }}
                    >
                      <img
                        src={pages[currentPage].imageUrl}
                        alt={`Page ${pages[currentPage].pageNumber}`}
                        className="w-auto h-[70vh] max-w-[45vw] object-contain"
                        style={{ maxHeight: "70vh" }}
                      />
                    </motion.div>
                  )}

                  {/* Right Page */}
                  {pages[currentPage + 1] && (
                    <motion.div
                      key={`right-${currentPage + 1}`}
                      initial={isFlipping ? { rotateY: 180, opacity: 0 } : { rotateY: 0, opacity: 1 }}
                      animate={{ rotateY: 0, opacity: 1 }}
                      transition={{ duration: 0.6, ease: "easeInOut", delay: 0.1 }}
                      className="transform-gpu"
                      style={{ transformOrigin: "left center" }}
                    >
                      <img
                        src={pages[currentPage + 1].imageUrl}
                        alt={`Page ${pages[currentPage + 1].pageNumber}`}
                        className="w-auto h-[70vh] max-w-[45vw] object-contain"
                        style={{ maxHeight: "70vh" }}
                      />
                    </motion.div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Page Navigation */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 50, opacity: 0 }}
          className="absolute bottom-4 left-0 right-0 px-4"
        >
          <div className="flex justify-center">
            <div className="bg-black/50 rounded-full px-6 py-3 backdrop-blur-sm">
              <div className="flex items-center space-x-2">
                {Array.from({ length: Math.ceil(pages.length / 2) }, (_, i) => (
                  <button
                    key={i}
                    onClick={() => goToPage(i * 2)}
                    className={`w-2 h-2 rounded-full transition-all duration-200 ${
                      Math.floor(currentPage / 2) === i 
                        ? "bg-white scale-125" 
                        : "bg-white/40 hover:bg-white/60"
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>
        </motion.div>

        {/* Book Description */}
        {description && (
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 50, opacity: 0 }}
            className="absolute bottom-20 left-0 right-0 px-4"
          >
            <div className="max-w-2xl mx-auto text-center">
              <div className="bg-black/50 rounded-lg p-4 backdrop-blur-sm">
                <p className="text-white text-sm leading-relaxed">
                  {description}
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </motion.div>
    </AnimatePresence>
  );
}
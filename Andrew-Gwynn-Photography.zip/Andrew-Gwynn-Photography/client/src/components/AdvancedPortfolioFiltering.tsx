import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Search, 
  Filter, 
  Calendar, 
  MapPin, 
  Camera, 
  Tag, 
  Palette, 
  Layout,
  Star,
  SortAsc,
  SortDesc,
  Grid,
  List,
  Info,
  X,
  Check
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import LoadingSkeleton from "./LoadingSkeleton";

interface AdvancedPortfolioFilteringProps {
  onFilterChange?: (filters: FilterState) => void;
  onSelectionChange?: (selectedAssets: string[]) => void;
}

interface FilterState {
  search: string;
  category: string;
  dateRange: [number, number];
  location: string;
  camera: string;
  tags: string[];
  colorScheme: string;
  orientation: string;
  featured: boolean | null;
  sortBy: string;
  sortOrder: 'asc' | 'desc';
}

interface PortfolioAsset {
  id: string;
  title: string;
  description: string;
  category: string;
  location: string;
  date: string;
  camera: string;
  tags: string[];
  colorScheme: string;
  orientation: 'landscape' | 'portrait' | 'square';
  featured: boolean;
  imageUrl: string;
  metadata: {
    aperture?: string;
    shutterSpeed?: string;
    iso?: string;
    focalLength?: string;
  };
}

export default function AdvancedPortfolioFiltering({ 
  onFilterChange, 
  onSelectionChange 
}: AdvancedPortfolioFilteringProps) {
  const [isLoading, setIsLoading] = useState(true);
  const [selectedAssets, setSelectedAssets] = useState<string[]>([]);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [showFilters, setShowFilters] = useState(false);
  
  const [filters, setFilters] = useState<FilterState>({
    search: '',
    category: '',
    dateRange: [2020, 2024],
    location: '',
    camera: '',
    tags: [],
    colorScheme: '',
    orientation: '',
    featured: null,
    sortBy: 'date',
    sortOrder: 'desc'
  });

  // Sample portfolio assets with rich metadata
  const portfolioAssets: PortfolioAsset[] = [
    {
      id: '1',
      title: 'Highland Mist at Ben Nevis',
      description: 'Capturing the ethereal beauty of morning mist across Scotland\'s highest peak',
      category: 'Landscape',
      location: 'Ben Nevis, Scotland',
      date: '2024-01-15',
      camera: 'Canon EOS R5',
      tags: ['scotland', 'mountains', 'mist', 'sunrise', 'highland'],
      colorScheme: 'Cool',
      orientation: 'landscape',
      featured: true,
      imageUrl: '',
      metadata: {
        aperture: 'f/8',
        shutterSpeed: '1/125',
        iso: '100',
        focalLength: '24mm'
      }
    },
    {
      id: '2',
      title: 'Edinburgh Castle at Golden Hour',
      description: 'The historic Edinburgh Castle bathed in warm golden light',
      category: 'Architecture',
      location: 'Edinburgh, Scotland',
      date: '2024-01-10',
      camera: 'Sony A7R IV',
      tags: ['edinburgh', 'castle', 'golden hour', 'historic', 'architecture'],
      colorScheme: 'Warm',
      orientation: 'landscape',
      featured: false,
      imageUrl: '',
      metadata: {
        aperture: 'f/11',
        shutterSpeed: '1/60',
        iso: '200',
        focalLength: '35mm'
      }
    },
    {
      id: '3',
      title: 'Portrait Session - Sarah',
      description: 'Natural light portrait session in the Scottish countryside',
      category: 'Portrait',
      location: 'Stirling, Scotland',
      date: '2024-01-05',
      camera: 'Canon EOS R6',
      tags: ['portrait', 'natural light', 'countryside', 'professional'],
      colorScheme: 'Neutral',
      orientation: 'portrait',
      featured: true,
      imageUrl: '',
      metadata: {
        aperture: 'f/2.8',
        shutterSpeed: '1/200',
        iso: '320',
        focalLength: '85mm'
      }
    }
  ];

  const categories = ['All', 'Landscape', 'Portrait', 'Architecture', 'Wildlife', 'Street', 'Wedding'];
  const locations = ['All', 'Edinburgh', 'Glasgow', 'Highlands', 'Isle of Skye', 'Stirling', 'Ben Nevis'];
  const cameras = ['All', 'Canon EOS R5', 'Canon EOS R6', 'Sony A7R IV', 'Nikon D850'];
  const colorSchemes = ['All', 'Warm', 'Cool', 'Neutral', 'Vibrant', 'Monochrome'];
  const orientations = ['All', 'Landscape', 'Portrait', 'Square'];
  const availableTags = ['scotland', 'mountains', 'mist', 'sunrise', 'highland', 'edinburgh', 'castle', 'golden hour', 'historic', 'architecture', 'portrait', 'natural light', 'countryside', 'professional'];

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => setIsLoading(false), 1500);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    onFilterChange?.(filters);
  }, [filters, onFilterChange]);

  useEffect(() => {
    onSelectionChange?.(selectedAssets);
  }, [selectedAssets, onSelectionChange]);

  const filteredAssets = portfolioAssets.filter(asset => {
    const matchesSearch = !filters.search || 
      asset.title.toLowerCase().includes(filters.search.toLowerCase()) ||
      asset.description.toLowerCase().includes(filters.search.toLowerCase()) ||
      asset.tags.some(tag => tag.toLowerCase().includes(filters.search.toLowerCase()));
    
    const matchesCategory = !filters.category || filters.category === 'All' || asset.category === filters.category;
    const matchesLocation = !filters.location || filters.location === 'All' || asset.location.includes(filters.location);
    const matchesCamera = !filters.camera || filters.camera === 'All' || asset.camera === filters.camera;
    const matchesColorScheme = !filters.colorScheme || filters.colorScheme === 'All' || asset.colorScheme === filters.colorScheme;
    const matchesOrientation = !filters.orientation || filters.orientation === 'All' || asset.orientation === filters.orientation.toLowerCase();
    const matchesFeatured = filters.featured === null || asset.featured === filters.featured;
    
    const assetYear = new Date(asset.date).getFullYear();
    const matchesDateRange = assetYear >= filters.dateRange[0] && assetYear <= filters.dateRange[1];
    
    const matchesTags = filters.tags.length === 0 || filters.tags.every(tag => asset.tags.includes(tag));

    return matchesSearch && matchesCategory && matchesLocation && matchesCamera && 
           matchesColorScheme && matchesOrientation && matchesFeatured && matchesDateRange && matchesTags;
  });

  const sortedAssets = [...filteredAssets].sort((a, b) => {
    const multiplier = filters.sortOrder === 'asc' ? 1 : -1;
    
    switch (filters.sortBy) {
      case 'title':
        return a.title.localeCompare(b.title) * multiplier;
      case 'date':
        return (new Date(a.date).getTime() - new Date(b.date).getTime()) * multiplier;
      case 'category':
        return a.category.localeCompare(b.category) * multiplier;
      case 'featured':
        return (Number(a.featured) - Number(b.featured)) * multiplier;
      default:
        return 0;
    }
  });

  const toggleAssetSelection = (assetId: string) => {
    setSelectedAssets(prev => 
      prev.includes(assetId) 
        ? prev.filter(id => id !== assetId)
        : [...prev, assetId]
    );
  };

  const clearFilters = () => {
    setFilters({
      search: '',
      category: '',
      dateRange: [2020, 2024],
      location: '',
      camera: '',
      tags: [],
      colorScheme: '',
      orientation: '',
      featured: null,
      sortBy: 'date',
      sortOrder: 'desc'
    });
  };

  const toggleTag = (tag: string) => {
    setFilters(prev => ({
      ...prev,
      tags: prev.tags.includes(tag) 
        ? prev.tags.filter(t => t !== tag)
        : [...prev.tags, tag]
    }));
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <LoadingSkeleton variant="text" className="h-8" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <LoadingSkeleton variant="card" count={8} />
        </div>
      </div>
    );
  }

  return (
    <TooltipProvider>
      <div className="space-y-6">
        {/* Header with Search and View Controls */}
        <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-center">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Search by title, description, or tags..."
              value={filters.search}
              onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
              className="pl-10"
            />
          </div>

          <div className="flex items-center space-x-2">
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowFilters(!showFilters)}
                >
                  <Filter className="w-4 h-4 mr-2" />
                  Filters
                  {Object.values(filters).some(v => v && v !== '' && (!Array.isArray(v) || v.length > 0)) && (
                    <Badge variant="secondary" className="ml-2">
                      Active
                    </Badge>
                  )}
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Advanced filtering options for precise asset discovery</p>
              </TooltipContent>
            </Tooltip>

            <div className="flex items-center space-x-1 border rounded-md">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('grid')}
              >
                <Grid className="w-4 h-4" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('list')}
              >
                <List className="w-4 h-4" />
              </Button>
            </div>

            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="outline" size="sm" onClick={clearFilters}>
                  Clear
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Reset all filters to default values</p>
              </TooltipContent>
            </Tooltip>
          </div>
        </div>

        {/* Advanced Filters Panel */}
        <AnimatePresence>
          {showFilters && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
            >
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Filter className="w-5 h-5 mr-2" />
                    Advanced Filters
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Info className="w-4 h-4 ml-2 text-gray-400" />
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Use multiple filters to find exactly what you're looking for</p>
                      </TooltipContent>
                    </Tooltip>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    
                    {/* Category Filter */}
                    <div className="space-y-2">
                      <Label className="flex items-center">
                        <Tag className="w-4 h-4 mr-2" />
                        Category
                      </Label>
                      <Select value={filters.category} onValueChange={(value) => setFilters(prev => ({ ...prev, category: value }))}>
                        <SelectTrigger>
                          <SelectValue placeholder="All Categories" />
                        </SelectTrigger>
                        <SelectContent>
                          {categories.map(category => (
                            <SelectItem key={category} value={category === 'All' ? '' : category}>
                              {category}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Location Filter */}
                    <div className="space-y-2">
                      <Label className="flex items-center">
                        <MapPin className="w-4 h-4 mr-2" />
                        Location
                      </Label>
                      <Select value={filters.location} onValueChange={(value) => setFilters(prev => ({ ...prev, location: value }))}>
                        <SelectTrigger>
                          <SelectValue placeholder="All Locations" />
                        </SelectTrigger>
                        <SelectContent>
                          {locations.map(location => (
                            <SelectItem key={location} value={location === 'All' ? '' : location}>
                              {location}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Camera Filter */}
                    <div className="space-y-2">
                      <Label className="flex items-center">
                        <Camera className="w-4 h-4 mr-2" />
                        Camera
                      </Label>
                      <Select value={filters.camera} onValueChange={(value) => setFilters(prev => ({ ...prev, camera: value }))}>
                        <SelectTrigger>
                          <SelectValue placeholder="All Cameras" />
                        </SelectTrigger>
                        <SelectContent>
                          {cameras.map(camera => (
                            <SelectItem key={camera} value={camera === 'All' ? '' : camera}>
                              {camera}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Color Scheme Filter */}
                    <div className="space-y-2">
                      <Label className="flex items-center">
                        <Palette className="w-4 h-4 mr-2" />
                        Color Scheme
                      </Label>
                      <Select value={filters.colorScheme} onValueChange={(value) => setFilters(prev => ({ ...prev, colorScheme: value }))}>
                        <SelectTrigger>
                          <SelectValue placeholder="All Colors" />
                        </SelectTrigger>
                        <SelectContent>
                          {colorSchemes.map(scheme => (
                            <SelectItem key={scheme} value={scheme === 'All' ? '' : scheme}>
                              {scheme}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Orientation Filter */}
                    <div className="space-y-2">
                      <Label className="flex items-center">
                        <Layout className="w-4 h-4 mr-2" />
                        Orientation
                      </Label>
                      <Select value={filters.orientation} onValueChange={(value) => setFilters(prev => ({ ...prev, orientation: value }))}>
                        <SelectTrigger>
                          <SelectValue placeholder="All Orientations" />
                        </SelectTrigger>
                        <SelectContent>
                          {orientations.map(orientation => (
                            <SelectItem key={orientation} value={orientation === 'All' ? '' : orientation}>
                              {orientation}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Featured Toggle */}
                    <div className="space-y-2">
                      <Label className="flex items-center">
                        <Star className="w-4 h-4 mr-2" />
                        Featured Only
                      </Label>
                      <div className="flex items-center space-x-2">
                        <Switch 
                          checked={filters.featured === true}
                          onCheckedChange={(checked) => setFilters(prev => ({ ...prev, featured: checked ? true : null }))}
                        />
                        <span className="text-sm text-gray-600">Show featured images only</span>
                      </div>
                    </div>

                  </div>

                  {/* Date Range Slider */}
                  <div className="mt-6 space-y-2">
                    <Label className="flex items-center">
                      <Calendar className="w-4 h-4 mr-2" />
                      Date Range: {filters.dateRange[0]} - {filters.dateRange[1]}
                    </Label>
                    <Slider
                      value={filters.dateRange}
                      onValueChange={(value) => setFilters(prev => ({ ...prev, dateRange: value as [number, number] }))}
                      min={2015}
                      max={2024}
                      step={1}
                      className="w-full"
                    />
                  </div>

                  {/* Tags Filter */}
                  <div className="mt-6 space-y-2">
                    <Label>Available Tags</Label>
                    <div className="flex flex-wrap gap-2">
                      {availableTags.map(tag => (
                        <Badge
                          key={tag}
                          variant={filters.tags.includes(tag) ? "default" : "outline"}
                          className="cursor-pointer hover:shadow-md transition-shadow"
                          onClick={() => toggleTag(tag)}
                        >
                          {tag}
                          {filters.tags.includes(tag) && <Check className="w-3 h-3 ml-1" />}
                        </Badge>
                      ))}
                    </div>
                  </div>

                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Sort Controls */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <span className="text-sm text-gray-600">
              {sortedAssets.length} asset{sortedAssets.length !== 1 ? 's' : ''} found
              {selectedAssets.length > 0 && ` (${selectedAssets.length} selected)`}
            </span>
          </div>

          <div className="flex items-center space-x-2">
            <Label className="text-sm">Sort by:</Label>
            <Select value={filters.sortBy} onValueChange={(value) => setFilters(prev => ({ ...prev, sortBy: value }))}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="date">Date</SelectItem>
                <SelectItem value="title">Title</SelectItem>
                <SelectItem value="category">Category</SelectItem>
                <SelectItem value="featured">Featured</SelectItem>
              </SelectContent>
            </Select>
            
            <Button
              variant="outline"
              size="sm"
              onClick={() => setFilters(prev => ({ ...prev, sortOrder: prev.sortOrder === 'asc' ? 'desc' : 'asc' }))}
            >
              {filters.sortOrder === 'asc' ? <SortAsc className="w-4 h-4" /> : <SortDesc className="w-4 h-4" />}
            </Button>
          </div>
        </div>

        {/* Assets Grid/List */}
        <div className={
          viewMode === 'grid' 
            ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6' 
            : 'space-y-4'
        }>
          {sortedAssets.map((asset) => (
            <motion.div
              key={asset.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3 }}
            >
              <Card 
                className={`hover:shadow-lg transition-all duration-300 cursor-pointer border-2 ${
                  selectedAssets.includes(asset.id) ? 'border-blue-500 bg-blue-50' : 'border-transparent'
                }`}
                onClick={() => toggleAssetSelection(asset.id)}
              >
                <CardContent className="p-4">
                  {viewMode === 'grid' ? (
                    <div className="space-y-3">
                      <div className="aspect-square bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg flex items-center justify-center relative">
                        <Camera className="w-8 h-8 text-gray-400" />
                        {asset.featured && (
                          <Star className="absolute top-2 right-2 w-4 h-4 text-yellow-500 fill-current" />
                        )}
                        {selectedAssets.includes(asset.id) && (
                          <div className="absolute top-2 left-2 w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center">
                            <Check className="w-3 h-3 text-white" />
                          </div>
                        )}
                      </div>
                      
                      <div>
                        <h3 className="font-semibold text-sm line-clamp-2">{asset.title}</h3>
                        <p className="text-xs text-gray-600 line-clamp-2 mt-1">{asset.description}</p>
                      </div>

                      <div className="flex flex-wrap gap-1">
                        <Badge variant="outline" className="text-xs">{asset.category}</Badge>
                        <Badge variant="secondary" className="text-xs">{asset.colorScheme}</Badge>
                      </div>

                      <div className="text-xs text-gray-500 space-y-1">
                        <div className="flex items-center">
                          <MapPin className="w-3 h-3 mr-1" />
                          {asset.location}
                        </div>
                        <div className="flex items-center">
                          <Calendar className="w-3 h-3 mr-1" />
                          {new Date(asset.date).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center space-x-4">
                      <div className="w-20 h-20 bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg flex items-center justify-center relative flex-shrink-0">
                        <Camera className="w-6 h-6 text-gray-400" />
                        {selectedAssets.includes(asset.id) && (
                          <div className="absolute -top-1 -right-1 w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center">
                            <Check className="w-3 h-3 text-white" />
                          </div>
                        )}
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold truncate">{asset.title}</h3>
                        <p className="text-sm text-gray-600 line-clamp-2">{asset.description}</p>
                        <div className="flex items-center mt-2 space-x-4 text-xs text-gray-500">
                          <span>{asset.category}</span>
                          <span>{asset.location}</span>
                          <span>{new Date(asset.date).toLocaleDateString()}</span>
                        </div>
                      </div>

                      <div className="flex flex-col items-end space-y-2">
                        {asset.featured && <Star className="w-4 h-4 text-yellow-500 fill-current" />}
                        <div className="flex flex-wrap gap-1">
                          {asset.tags.slice(0, 2).map(tag => (
                            <Badge key={tag} variant="secondary" className="text-xs">{tag}</Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {sortedAssets.length === 0 && (
          <div className="text-center py-12">
            <Search className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No assets found</h3>
            <p className="text-gray-600 mb-4">Try adjusting your search terms or filters</p>
            <Button variant="outline" onClick={clearFilters}>
              Clear All Filters
            </Button>
          </div>
        )}

        {/* Selection Actions */}
        {selectedAssets.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="fixed bottom-6 left-1/2 transform -translate-x-1/2 bg-white border rounded-lg shadow-lg p-4"
          >
            <div className="flex items-center space-x-4">
              <span className="text-sm font-medium">
                {selectedAssets.length} asset{selectedAssets.length !== 1 ? 's' : ''} selected
              </span>
              <Button size="sm" variant="outline" onClick={() => setSelectedAssets([])}>
                Clear Selection
              </Button>
              <Button size="sm">
                Add to Collection
              </Button>
            </div>
          </motion.div>
        )}
      </div>
    </TooltipProvider>
  );
}
import { motion } from "framer-motion";

export default function Footer() {
  const footerLinks = [
    { href: "https://afx-store.com/collections/andrew-gwynn-photography", label: "Collection" },
    { href: "https://afx-holdings.com/andrew-gwynn-photography", label: "About AFX" },
    { href: "#portfolio", label: "Portfolio" },
    { href: "#services", label: "Services" },
  ];

  const handleNavClick = (href: string) => {
    if (href.startsWith("#")) {
      const element = document.querySelector(href);
      if (element) {
        element.scrollIntoView({ behavior: "smooth" });
      }
    } else {
      window.open(href, "_blank", "noopener noreferrer");
    }
  };

  return (
    <footer className="bg-apple-dark text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center"
        >
          <motion.h3
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-2xl font-light mb-4"
          >
            Andrew Gwynn Photography
          </motion.h3>
          
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-apple-gray mb-8 italic"
          >
            Where Moments Become Conversations...
          </motion.p>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex justify-center space-x-8 mb-8 flex-wrap gap-4"
          >
            {footerLinks.map((link, index) => (
              <motion.button
                key={link.href}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.7 + index * 0.1 }}
                whileHover={{ scale: 1.05 }}
                onClick={() => handleNavClick(link.href)}
                className="text-apple-gray hover:text-white transition-colors duration-200"
              >
                {link.label}
              </motion.button>
            ))}
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 1 }}
            className="border-t border-gray-700 pt-8"
          >
            <p className="text-apple-gray text-sm">
              © 2024 Andrew Gwynn Photography. Part of AFX Studios. All rights reserved.
            </p>
          </motion.div>
        </motion.div>
      </div>
    </footer>
  );
}

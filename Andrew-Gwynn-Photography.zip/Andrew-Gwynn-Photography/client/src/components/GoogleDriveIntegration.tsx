import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { 
  Cloud, 
  Folder, 
  Image, 
  Download, 
  Eye, 
  RefreshCw,
  Search,
  Grid,
  List,
  Filter,
  Calendar,
  MapPin,
  Camera,
  Plus
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface DriveFile {
  id: string;
  name: string;
  mimeType: string;
  size?: string;
  createdTime: string;
  modifiedTime: string;
  webViewLink: string;
  webContentLink?: string;
  thumbnailLink?: string;
  imageMediaMetadata?: {
    width: number;
    height: number;
    rotation: number;
    location?: {
      latitude: number;
      longitude: number;
    };
    time: string;
    cameraMake?: string;
    cameraModel?: string;
    exposureTime?: number;
    aperture?: number;
    focalLength?: number;
    isoEquivalent?: number;
  };
}

interface GoogleDriveIntegrationProps {
  onFileSelect?: (file: DriveFile) => void;
  onImportToDatabase?: (file: DriveFile) => void;
}

export default function GoogleDriveIntegration({ 
  onFileSelect, 
  onImportToDatabase 
}: GoogleDriveIntegrationProps) {
  const [isConnected, setIsConnected] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedFolder, setSelectedFolder] = useState<string>('root');
  const [selectedFile, setSelectedFile] = useState<DriveFile | null>(null);
  const [showPreview, setShowPreview] = useState(false);
  const [photographyFolders, setPhotographyFolders] = useState<string[]>([]);
  const [currentPath, setCurrentPath] = useState<string[]>(['My Drive']);

  const queryClient = useQueryClient();

  // Check Google Drive connection status
  const { data: connectionStatus } = useQuery({
    queryKey: ['/api/google-drive/status'],
    queryFn: () => apiRequest('/api/google-drive/status'),
    enabled: true
  });

  // Fetch folders
  const { data: driveFolders = [] } = useQuery({
    queryKey: ['/api/google-drive/folders', selectedFolder],
    queryFn: () => apiRequest(`/api/google-drive/folders?parent=${selectedFolder}`),
    enabled: isConnected
  });

  // Fetch Drive files (only images)
  const { data: driveFiles = [], isLoading, refetch } = useQuery({
    queryKey: ['/api/google-drive/files', selectedFolder, searchQuery],
    queryFn: () => apiRequest(`/api/google-drive/files?folderId=${selectedFolder}&query=${searchQuery}`),
    enabled: isConnected && photographyFolders.includes(selectedFolder)
  });

  // Connect to Google Drive
  const connectMutation = useMutation({
    mutationFn: () => apiRequest('/api/google-drive/auth'),
    onSuccess: (data) => {
      if (data.authUrl) {
        window.open(data.authUrl, '_blank');
      }
    }
  });

  // Add folder to photography collection
  const addPhotographyFolder = (folderId: string) => {
    if (!photographyFolders.includes(folderId)) {
      setPhotographyFolders([...photographyFolders, folderId]);
    }
  };

  // Remove folder from photography collection
  const removePhotographyFolder = (folderId: string) => {
    setPhotographyFolders(photographyFolders.filter(id => id !== folderId));
  };

  // Navigate to folder
  const navigateToFolder = (folder: any) => {
    setSelectedFolder(folder.id);
    setCurrentPath([...currentPath, folder.name]);
  };

  // Navigate back
  const navigateBack = () => {
    if (currentPath.length > 1) {
      setCurrentPath(currentPath.slice(0, -1));
      // Logic to go back to parent folder would need folder hierarchy
    }
  };

  // Import file to database
  const importMutation = useMutation({
    mutationFn: (file: DriveFile) => apiRequest('/api/google-drive/import', 'POST', file),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/assets'] });
    }
  });

  useEffect(() => {
    if (connectionStatus?.connected) {
      setIsConnected(true);
    }
  }, [connectionStatus]);

  const handleConnect = () => {
    connectMutation.mutate();
  };

  const handleFilePreview = (file: DriveFile) => {
    setSelectedFile(file);
    setShowPreview(true);
    onFileSelect?.(file);
  };

  const handleImportFile = (file: DriveFile) => {
    importMutation.mutate(file);
    onImportToDatabase?.(file);
  };

  const formatFileSize = (bytes: string) => {
    const size = parseInt(bytes);
    if (size === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(size) / Math.log(k));
    return parseFloat((size / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const isImageFile = (mimeType: string) => {
    return mimeType.startsWith('image/');
  };

  if (!isConnected) {
    return (
      <Card className="border-dashed border-2">
        <CardContent className="flex flex-col items-center justify-center py-12">
          <Cloud className="w-16 h-16 text-gray-400 mb-4" />
          <h3 className="text-lg font-semibold mb-2">Connect to Google Drive</h3>
          {connectionStatus?.error ? (
            <div className="text-center mb-6 max-w-md">
              <p className="text-amber-600 mb-2">API Credentials Required</p>
              <p className="text-sm text-gray-600">
                {connectionStatus.error}
              </p>
            </div>
          ) : (
            <p className="text-gray-600 text-center mb-6 max-w-md">
              Access your photography collection directly from Google Drive. 
              Browse, preview, and import images with automatic metadata extraction.
            </p>
          )}
          <Button 
            onClick={handleConnect} 
            disabled={connectMutation.isPending || connectionStatus?.error}
            className="flex items-center space-x-2"
          >
            <Cloud className="w-4 h-4" />
            <span>
              {connectionStatus?.error 
                ? "Configure API Credentials First" 
                : connectMutation.isPending 
                ? "Connecting..." 
                : "Connect Google Drive"
              }
            </span>
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Folder Navigation */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Select Photography Folders</span>
            <Badge variant="secondary">{photographyFolders.length} folders selected</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {/* Breadcrumb Navigation */}
          <div className="flex items-center space-x-2 mb-4 text-sm text-gray-600">
            {currentPath.map((path, index) => (
              <div key={index} className="flex items-center">
                {index > 0 && <span className="mx-2">/</span>}
                <span>{path}</span>
              </div>
            ))}
          </div>

          {/* Folder Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            {driveFolders.map((folder: any) => (
              <div
                key={folder.id}
                className={`relative p-4 border rounded-lg cursor-pointer transition-all hover:shadow-md ${
                  photographyFolders.includes(folder.id) 
                    ? 'border-blue-500 bg-blue-50' 
                    : 'border-gray-200 hover:border-gray-300'
                }`}
                onClick={() => navigateToFolder(folder)}
              >
                <div className="flex flex-col items-center text-center">
                  <Folder className={`w-8 h-8 mb-2 ${
                    photographyFolders.includes(folder.id) ? 'text-blue-600' : 'text-gray-500'
                  }`} />
                  <span className="text-sm font-medium truncate w-full">{folder.name}</span>
                </div>
                
                {/* Add/Remove from Photography Collection */}
                <div className="absolute top-2 right-2">
                  {photographyFolders.includes(folder.id) ? (
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-6 w-6 p-0"
                      onClick={(e) => {
                        e.stopPropagation();
                        removePhotographyFolder(folder.id);
                      }}
                    >
                      ×
                    </Button>
                  ) : (
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-6 w-6 p-0"
                      onClick={(e) => {
                        e.stopPropagation();
                        addPhotographyFolder(folder.id);
                      }}
                    >
                      <Plus className="w-3 h-3" />
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Selected Photography Folders */}
          {photographyFolders.length > 0 && (
            <div className="border-t pt-4">
              <h4 className="font-medium mb-2">Photography Folders:</h4>
              <div className="flex flex-wrap gap-2">
                {photographyFolders.map((folderId) => {
                  const folder = driveFolders.find((f: any) => f.id === folderId);
                  return (
                    <Badge key={folderId} variant="secondary" className="flex items-center space-x-1">
                      <span>{folder?.name || 'Unknown Folder'}</span>
                      <button
                        onClick={() => removePhotographyFolder(folderId)}
                        className="ml-1 hover:text-red-600"
                      >
                        ×
                      </button>
                    </Badge>
                  );
                })}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Search and Controls (only show when folders are selected) */}
      {photographyFolders.length > 0 && (
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-4 sm:space-y-0">
          <div className="flex items-center space-x-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search photos in selected folders..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 w-64"
              />
            </div>
            <Select value={selectedFolder} onValueChange={setSelectedFolder}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Browse folder" />
              </SelectTrigger>
              <SelectContent>
                {photographyFolders.map((folderId) => {
                  const folder = driveFolders.find((f: any) => f.id === folderId);
                  return (
                    <SelectItem key={folderId} value={folderId}>
                      {folder?.name || 'Unknown Folder'}
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" onClick={() => refetch()}>
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setViewMode(viewMode === 'grid' ? 'list' : 'grid')}
            >
              {viewMode === 'grid' ? <List className="w-4 h-4" /> : <Grid className="w-4 h-4" />}
            </Button>
          </div>
        </div>
      )}

      {/* Connection Status */}
      <div className="flex items-center justify-between bg-green-50 border border-green-200 rounded-lg p-4">
        <div className="flex items-center space-x-3">
          <div className="w-3 h-3 bg-green-500 rounded-full"></div>
          <span className="text-green-800 font-medium">Connected to Google Drive</span>
        </div>
        <Badge variant="secondary">{driveFiles.length} files found</Badge>
      </div>

      {/* Files Display */}
      {isLoading ? (
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading files from Google Drive...</p>
        </div>
      ) : driveFiles.length === 0 ? (
        <div className="text-center py-12">
          <Folder className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600">No files found in this folder</p>
        </div>
      ) : viewMode === 'grid' ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
          {driveFiles.map((file: DriveFile) => (
            <motion.div
              key={file.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white rounded-lg border shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="aspect-square relative overflow-hidden rounded-t-lg">
                {isImageFile(file.mimeType) && file.thumbnailLink ? (
                  <img 
                    src={file.thumbnailLink} 
                    alt={file.name}
                    className="w-full h-full object-cover cursor-pointer"
                    onClick={() => handleFilePreview(file)}
                  />
                ) : (
                  <div className="w-full h-full bg-gray-100 flex items-center justify-center">
                    <Image className="w-8 h-8 text-gray-400" />
                  </div>
                )}
                <div className="absolute top-2 right-2">
                  <Button
                    size="sm"
                    variant="secondary"
                    className="w-8 h-8 p-0"
                    onClick={() => handleImportFile(file)}
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              <div className="p-3">
                <p className="text-sm font-medium truncate" title={file.name}>
                  {file.name}
                </p>
                <div className="flex items-center justify-between mt-2 text-xs text-gray-500">
                  <span>{file.size ? formatFileSize(file.size) : 'Unknown'}</span>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="w-6 h-6 p-0"
                    onClick={() => handleFilePreview(file)}
                  >
                    <Eye className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-lg border">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Size</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Modified</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Camera</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {driveFiles.map((file: DriveFile) => (
                  <tr key={file.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4">
                      <div className="flex items-center space-x-3">
                        {isImageFile(file.mimeType) && file.thumbnailLink ? (
                          <img 
                            src={file.thumbnailLink} 
                            alt={file.name}
                            className="w-10 h-10 rounded object-cover"
                          />
                        ) : (
                          <div className="w-10 h-10 bg-gray-100 rounded flex items-center justify-center">
                            <Image className="w-5 h-5 text-gray-400" />
                          </div>
                        )}
                        <span className="text-sm font-medium">{file.name}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-500">
                      {file.size ? formatFileSize(file.size) : 'Unknown'}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-500">
                      {new Date(file.modifiedTime).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-500">
                      {file.imageMediaMetadata?.cameraMake && file.imageMediaMetadata?.cameraModel ? (
                        <span className="flex items-center">
                          <Camera className="w-3 h-3 mr-1" />
                          {file.imageMediaMetadata.cameraMake} {file.imageMediaMetadata.cameraModel}
                        </span>
                      ) : (
                        '-'
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex space-x-2">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleFilePreview(file)}
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => handleImportFile(file)}
                        >
                          <Plus className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => window.open(file.webContentLink, '_blank')}
                        >
                          <Download className="w-4 h-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* File Preview Dialog */}
      <Dialog open={showPreview} onOpenChange={setShowPreview}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>{selectedFile?.name}</DialogTitle>
          </DialogHeader>
          {selectedFile && (
            <div className="space-y-4">
              {isImageFile(selectedFile.mimeType) && selectedFile.webViewLink && (
                <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden">
                  <iframe 
                    src={selectedFile.webViewLink} 
                    className="w-full h-full"
                    title={selectedFile.name}
                  />
                </div>
              )}
              
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="font-medium">Size:</span> {selectedFile.size ? formatFileSize(selectedFile.size) : 'Unknown'}
                </div>
                <div>
                  <span className="font-medium">Modified:</span> {new Date(selectedFile.modifiedTime).toLocaleDateString()}
                </div>
                
                {selectedFile.imageMediaMetadata && (
                  <>
                    <div>
                      <span className="font-medium">Dimensions:</span> {selectedFile.imageMediaMetadata.width} × {selectedFile.imageMediaMetadata.height}
                    </div>
                    <div>
                      <span className="font-medium">Camera:</span> {selectedFile.imageMediaMetadata.cameraMake} {selectedFile.imageMediaMetadata.cameraModel}
                    </div>
                    {selectedFile.imageMediaMetadata.location && (
                      <div className="col-span-2">
                        <span className="font-medium flex items-center">
                          <MapPin className="w-3 h-3 mr-1" />
                          Location:
                        </span> {selectedFile.imageMediaMetadata.location.latitude.toFixed(6)}, {selectedFile.imageMediaMetadata.location.longitude.toFixed(6)}
                      </div>
                    )}
                  </>
                )}
              </div>
              
              <div className="flex justify-end space-x-2">
                <Button 
                  variant="outline"
                  onClick={() => window.open(selectedFile.webContentLink, '_blank')}
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </Button>
                <Button 
                  onClick={() => handleImportFile(selectedFile)}
                  disabled={importMutation.isPending}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  {importMutation.isPending ? "Importing..." : "Import to Database"}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
import { motion } from "framer-motion";
import { ArrowRight, ExternalLink, ChevronDown } from "lucide-react";
import { useParallax } from "@/hooks/useParallax";

export default function HeroSection() {
  const parallaxY = useParallax(0.5);

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background with parallax */}
      <motion.div
        style={{ y: parallaxY }}
        className="absolute inset-0 parallax-element"
      >
        {/* Soft gradient background */}
        <div className="absolute inset-0 bg-gradient-to-br from-apple-light via-white to-gray-50" />
        
        {/* Floating elements for depth */}
        <motion.div
          animate={{ 
            y: [0, -20, 0],
            rotate: [0, 1, 0] 
          }}
          transition={{ 
            duration: 6, 
            repeat: Infinity,
            ease: "easeInOut" 
          }}
          className="absolute top-1/4 left-1/4 w-64 h-64 bg-blue-500/5 rounded-full blur-3xl"
        />
        <motion.div
          animate={{ 
            y: [0, -10, 0],
            rotate: [0, -1, 0] 
          }}
          transition={{ 
            duration: 8, 
            repeat: Infinity,
            ease: "easeInOut",
            delay: -3 
          }}
          className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-gray-200/30 rounded-full blur-3xl"
        />
      </motion.div>
      
      <div className="relative z-10 text-center px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="space-y-8"
        >
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="text-4xl sm:text-6xl lg:text-7xl font-thin tracking-tight text-gradient"
          >
            Andrew Gwynn Photography
          </motion.h1>
          
          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.4 }}
            className="text-xl sm:text-2xl lg:text-3xl font-light text-apple-gray italic max-w-4xl mx-auto"
          >
            Where Moments Become Conversations...
          </motion.p>
          
          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.6 }}
            className="text-lg sm:text-xl lg:text-2xl font-light text-apple-gray max-w-4xl mx-auto leading-relaxed"
          >
            Here audiences find stills that offer a chance to pause and ponder, escape and wander. 
            These are images that inspire dialogue, whether in a boardroom or in your own room. 
            Our photos allow you to take your design concept and make it a reality.
          </motion.p>
          
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.8 }}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-8"
          >
            <motion.a
              href="https://afx-store.com/collections/andrew-gwynn-photography"
              target="_blank"
              rel="noopener noreferrer"
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.95 }}
              className="inline-flex items-center px-8 py-4 bg-blue-600 text-white font-medium rounded-full hover:bg-blue-700 transition-all duration-300 hover-lift shadow-lg"
            >
              <span>Shop Collection</span>
              <ArrowRight className="ml-2 w-5 h-5" />
            </motion.a>
            
            <motion.a
              href="https://afx-holdings.com/andrew-gwynn-photography"
              target="_blank"
              rel="noopener noreferrer"
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.95 }}
              className="inline-flex items-center px-8 py-4 border-2 border-apple-dark text-apple-dark font-medium rounded-full hover:bg-apple-dark hover:text-white transition-all duration-300 hover-lift"
            >
              <span>Learn More</span>
              <ExternalLink className="ml-2 w-5 h-5" />
            </motion.a>
          </motion.div>
        </motion.div>
      </div>
      
      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5 }}
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
      >
        <motion.button
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          onClick={() => {
            document.getElementById("portfolio")?.scrollIntoView({ behavior: "smooth" });
          }}
          className="text-apple-gray hover:text-apple-blue transition-colors duration-200"
        >
          <ChevronDown className="w-6 h-6" />
        </motion.button>
      </motion.div>
    </section>
  );
}

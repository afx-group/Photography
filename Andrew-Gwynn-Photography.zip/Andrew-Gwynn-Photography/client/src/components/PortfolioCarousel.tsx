import { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence, PanInfo } from "framer-motion";
import { 
  ChevronLeft, 
  ChevronRight, 
  ZoomIn, 
  ZoomOut, 
  RotateCw,
  Download,
  Share2,
  Info,
  X,
  Maximize,
  Heart,
  Star,
  Play,
  Pause,
  SkipForward,
  Copy,
  Timer,
  SplitSquareVertical
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface CarouselImage {
  id: string;
  src: string;
  title: string;
  description: string;
  category: string;
  location: string;
  date: string;
  camera: string;
  lens: string;
  aperture: string;
  shutterSpeed: string;
  iso: string;
  tags: string[];
  featured: boolean;
  likes: number;
  views: number;
}

interface PortfolioCarouselProps {
  images: CarouselImage[];
  initialIndex?: number;
  onClose?: () => void;
  className?: string;
}

export default function PortfolioCarousel({ 
  images, 
  initialIndex = 0, 
  onClose,
  className = ""
}: PortfolioCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [isZoomed, setIsZoomed] = useState(false);
  const [zoomLevel, setZoomLevel] = useState(1);
  const [rotation, setRotation] = useState(0);
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [showInfo, setShowInfo] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const [showHelp, setShowHelp] = useState(false);
  const [isSlideshow, setIsSlideshow] = useState(false);
  const [slideshowInterval, setSlideshowInterval] = useState(3000);
  const [comparisonMode, setComparisonMode] = useState(false);
  const [comparisonImage, setComparisonImage] = useState<number | null>(null);
  const [dragConstraints, setDragConstraints] = useState({ left: 0, right: 0, top: 0, bottom: 0 });
  
  const containerRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);

  const currentImage = images[currentIndex];

  const resetZoom = () => {
    setZoomLevel(1);
    setIsZoomed(false);
    setPosition({ x: 0, y: 0 });
    setRotation(0);
  };



  // Slideshow timer
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isSlideshow && !isZoomed) {
      interval = setInterval(() => {
        goToNext();
      }, slideshowInterval);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isSlideshow, slideshowInterval, isZoomed, goToNext]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      switch (e.key) {
        case 'ArrowLeft':
          if (!isSlideshow) goToPrevious();
          break;
        case 'ArrowRight':
          if (!isSlideshow) goToNext();
          break;
        case 'Escape':
          if (comparisonMode) {
            setComparisonMode(false);
            setComparisonImage(null);
          } else if (isZoomed) {
            resetZoom();
          } else if (onClose) {
            onClose();
          }
          break;
        case '+':
        case '=':
          zoomIn();
          break;
        case '-':
          zoomOut();
          break;
        case 'r':
          rotate();
          break;
        case 'i':
          setShowInfo(!showInfo);
          break;
        case 'f':
          toggleFullscreen();
          break;
        case '?':
        case 'h':
          setShowHelp(!showHelp);
          break;
        case ' ':
          e.preventDefault();
          toggleSlideshow();
          break;
        case 'c':
          toggleComparison();
          break;
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [isZoomed, showInfo, isSlideshow, comparisonMode]);

  // Update drag constraints when zoom level changes
  useEffect(() => {
    if (imageRef.current && containerRef.current) {
      const container = containerRef.current.getBoundingClientRect();
      const image = imageRef.current.getBoundingClientRect();
      
      const scaledWidth = image.width * zoomLevel;
      const scaledHeight = image.height * zoomLevel;
      
      const maxX = Math.max(0, (scaledWidth - container.width) / 2);
      const maxY = Math.max(0, (scaledHeight - container.height) / 2);
      
      setDragConstraints({
        left: -maxX,
        right: maxX,
        top: -maxY,
        bottom: maxY
      });
    }
  }, [zoomLevel]);

  const goToNext = useCallback(() => {
    setCurrentIndex((prev) => (prev + 1) % images.length);
    resetZoom();
  }, [images.length]);

  const goToPrevious = useCallback(() => {
    setCurrentIndex((prev) => (prev - 1 + images.length) % images.length);
    resetZoom();
  }, [images.length]);

  const zoomIn = () => {
    setZoomLevel(prev => Math.min(prev * 1.5, 5));
    setIsZoomed(true);
  };

  const zoomOut = () => {
    setZoomLevel(prev => Math.max(prev / 1.5, 1));
    if (zoomLevel <= 1.5) {
      setIsZoomed(false);
      setPosition({ x: 0, y: 0 });
    }
  };

  const resetZoom = () => {
    setZoomLevel(1);
    setIsZoomed(false);
    setPosition({ x: 0, y: 0 });
    setRotation(0);
  };

  const rotate = () => {
    setRotation(prev => prev + 90);
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      containerRef.current?.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const toggleSlideshow = () => {
    setIsSlideshow(!isSlideshow);
    if (isZoomed) resetZoom();
  };

  const toggleComparison = () => {
    if (comparisonMode) {
      setComparisonMode(false);
      setComparisonImage(null);
    } else {
      setComparisonMode(true);
      setComparisonImage(currentIndex === 0 ? 1 : currentIndex - 1);
    }
    if (isZoomed) resetZoom();
  };

  const setSlideshowSpeed = (speed: number) => {
    setSlideshowInterval(speed * 1000);
  };

  const handleDrag = (event: any, info: PanInfo) => {
    if (isZoomed) {
      setPosition({
        x: info.offset.x,
        y: info.offset.y
      });
    }
  };

  const handleSwipe = (event: any, info: PanInfo) => {
    if (!isZoomed) {
      const threshold = 50;
      const velocity = Math.abs(info.velocity.x);
      
      // Adjust threshold based on velocity for better UX
      const dynamicThreshold = velocity > 500 ? threshold * 0.5 : threshold;
      
      if (info.offset.x > dynamicThreshold) {
        goToPrevious();
      } else if (info.offset.x < -dynamicThreshold) {
        goToNext();
      }
    }
  };

  const handleDoubleClick = (e: React.MouseEvent) => {
    if (isZoomed) {
      resetZoom();
    } else {
      const rect = e.currentTarget.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      
      setZoomLevel(2.5);
      setIsZoomed(true);
      
      // Calculate position to zoom into clicked point
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;
      setPosition({
        x: (centerX - x) * 1.5,
        y: (centerY - y) * 1.5
      });
    }
  };

  if (!currentImage) return null;

  return (
    <TooltipProvider>
      <div 
        ref={containerRef}
        className={`fixed inset-0 bg-black bg-opacity-95 z-50 flex items-center justify-center ${className}`}
      >
        {/* Header Controls */}
        <div className="absolute top-2 sm:top-4 left-2 sm:left-4 right-2 sm:right-4 flex justify-between items-center z-60">
          <div className="flex items-center space-x-1 sm:space-x-2">
            <Badge variant="secondary" className="bg-black/70 text-white border-white/20 backdrop-blur-sm text-xs sm:text-sm">
              {currentIndex + 1} / {images.length}
            </Badge>
            <Badge variant="secondary" className="bg-black/70 text-white border-white/20 backdrop-blur-sm text-xs sm:text-sm hidden sm:block">
              {currentImage.category}
            </Badge>
            {currentImage.featured && (
              <Badge className="bg-yellow-600/80 text-white backdrop-blur-sm text-xs sm:text-sm">
                <Star className="w-2 h-2 sm:w-3 sm:h-3 mr-1" />
                <span className="hidden sm:inline">Featured</span>
              </Badge>
            )}
          </div>
          
          <div className="flex items-center space-x-1 sm:space-x-2">
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowInfo(!showInfo)}
                  className="text-white hover:bg-white/20 h-8 w-8 sm:h-auto sm:w-auto p-1 sm:p-2"
                >
                  <Info className="w-3 h-3 sm:w-4 sm:h-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Toggle image info (I)</p>
              </TooltipContent>
            </Tooltip>

            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={toggleFullscreen}
                  className="text-white hover:bg-white/20"
                >
                  <Maximize className="w-4 h-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Toggle fullscreen (F)</p>
              </TooltipContent>
            </Tooltip>

            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsLiked(!isLiked)}
                  className="text-white hover:bg-white/20"
                >
                  <Heart className={`w-4 h-4 ${isLiked ? 'fill-red-500 text-red-500' : ''}`} />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>Like image</p>
              </TooltipContent>
            </Tooltip>

            {onClose && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={onClose}
                    className="text-white hover:bg-white/20"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Close (Esc)</p>
                </TooltipContent>
              </Tooltip>
            )}
          </div>
        </div>

        {/* Main Image Area */}
        <div className="relative w-full h-full flex items-center justify-center overflow-hidden">
          
          {/* Navigation Arrows */}
          <Button
            variant="ghost"
            size="lg"
            onClick={goToPrevious}
            className="absolute left-4 z-50 text-white hover:bg-white/20 h-12 w-12"
            disabled={images.length <= 1}
          >
            <ChevronLeft className="w-6 h-6" />
          </Button>

          <Button
            variant="ghost"
            size="lg"
            onClick={goToNext}
            className="absolute right-4 z-50 text-white hover:bg-white/20 h-12 w-12"
            disabled={images.length <= 1}
          >
            <ChevronRight className="w-6 h-6" />
          </Button>

          {/* Image Container */}
          <motion.div
            className="relative max-w-full max-h-full cursor-grab active:cursor-grabbing"
            drag={isZoomed}
            dragConstraints={dragConstraints}
            dragElastic={0.1}
            onDrag={handleDrag}
            onDragEnd={handleSwipe}
            animate={{ 
              x: position.x, 
              y: position.y,
              scale: zoomLevel,
              rotate: rotation
            }}
            transition={{ type: "spring", damping: 20, stiffness: 300 }}
            onDoubleClick={handleDoubleClick}
          >
            <AnimatePresence mode="wait">
              <motion.img
                key={currentImage.id}
                ref={imageRef}
                src={currentImage.src || "/api/placeholder/800/600"}
                alt={currentImage.title}
                className="max-w-full max-h-[80vh] object-contain select-none"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.3 }}
                draggable={false}
              />
            </AnimatePresence>
          </motion.div>
        </div>

        {/* Bottom Controls */}
        <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex items-center space-x-2 bg-black/50 backdrop-blur-sm rounded-lg p-2">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                onClick={zoomOut}
                disabled={zoomLevel <= 1}
                className="text-white hover:bg-white/20"
              >
                <ZoomOut className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Zoom out (-)</p>
            </TooltipContent>
          </Tooltip>

          <div className="text-white text-sm px-2 min-w-[60px] text-center">
            {Math.round(zoomLevel * 100)}%
          </div>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                onClick={zoomIn}
                disabled={zoomLevel >= 5}
                className="text-white hover:bg-white/20"
              >
                <ZoomIn className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Zoom in (+)</p>
            </TooltipContent>
          </Tooltip>

          <div className="w-px h-6 bg-white/20" />

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                onClick={rotate}
                className="text-white hover:bg-white/20"
              >
                <RotateCw className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Rotate (R)</p>
            </TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                onClick={resetZoom}
                disabled={zoomLevel === 1 && rotation === 0}
                className="text-white hover:bg-white/20"
              >
                Reset
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Reset view</p>
            </TooltipContent>
          </Tooltip>

          <div className="w-px h-6 bg-white/20" />

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="text-white hover:bg-white/20"
              >
                <Download className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Download image</p>
            </TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                className="text-white hover:bg-white/20"
              >
                <Share2 className="w-4 h-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Share image</p>
            </TooltipContent>
          </Tooltip>
        </div>

        {/* Image Information Panel */}
        <AnimatePresence>
          {showInfo && (
            <motion.div
              initial={{ opacity: 0, x: 300 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 300 }}
              transition={{ type: "spring", damping: 20 }}
              className="absolute top-0 right-0 h-full w-80 bg-black/80 backdrop-blur-sm text-white p-6 overflow-y-auto"
            >
              <Card className="bg-transparent border-white/20">
                <CardContent className="p-4 space-y-4">
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-2">{currentImage.title}</h3>
                    <p className="text-gray-300 text-sm">{currentImage.description}</p>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Location:</span>
                      <span className="text-white">{currentImage.location}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Date:</span>
                      <span className="text-white">{new Date(currentImage.date).toLocaleDateString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Camera:</span>
                      <span className="text-white">{currentImage.camera}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Lens:</span>
                      <span className="text-white">{currentImage.lens}</span>
                    </div>
                  </div>

                  <div className="border-t border-white/20 pt-3">
                    <h4 className="text-sm font-medium text-white mb-2">Camera Settings</h4>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <span className="text-gray-400">Aperture:</span>
                        <div className="text-white">{currentImage.aperture}</div>
                      </div>
                      <div>
                        <span className="text-gray-400">Shutter:</span>
                        <div className="text-white">{currentImage.shutterSpeed}</div>
                      </div>
                      <div>
                        <span className="text-gray-400">ISO:</span>
                        <div className="text-white">{currentImage.iso}</div>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h4 className="text-sm font-medium text-white">Tags</h4>
                    <div className="flex flex-wrap gap-1">
                      {currentImage.tags.map((tag) => (
                        <Badge key={tag} variant="outline" className="text-xs border-white/20 text-gray-300">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="border-t border-white/20 pt-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Views:</span>
                      <span className="text-white">{currentImage.views.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Likes:</span>
                      <span className="text-white">{currentImage.likes.toLocaleString()}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Thumbnail Strip */}
        <div className="absolute bottom-20 left-1/2 transform -translate-x-1/2 flex space-x-2 bg-black/50 backdrop-blur-sm rounded-lg p-2 max-w-[80vw] overflow-x-auto">
          {images.map((image, index) => (
            <button
              key={image.id}
              onClick={() => setCurrentIndex(index)}
              className={`relative flex-shrink-0 w-12 h-12 rounded overflow-hidden transition-all duration-200 ${
                index === currentIndex 
                  ? 'ring-2 ring-white scale-110' 
                  : 'opacity-60 hover:opacity-80'
              }`}
            >
              <img
                src={image.src || "/api/placeholder/50/50"}
                alt={image.title}
                className="w-full h-full object-cover"
              />
            </button>
          ))}
        </div>

        {/* Keyboard Shortcuts Help */}
        <AnimatePresence>
          {showHelp && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ type: "spring", damping: 20 }}
              className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-black/90 backdrop-blur-sm text-white p-6 rounded-lg border border-white/20 z-70"
            >
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold">Keyboard Shortcuts</h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowHelp(false)}
                  className="text-white hover:bg-white/20"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div className="space-y-2">
                  <h4 className="font-medium text-gray-300">Navigation</h4>
                  <div className="space-y-1">
                    <div className="flex justify-between">
                      <span className="text-gray-400">← →</span>
                      <span>Next/Previous image</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Esc</span>
                      <span>Close/Reset zoom</span>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <h4 className="font-medium text-gray-300">View Controls</h4>
                  <div className="space-y-1">
                    <div className="flex justify-between">
                      <span className="text-gray-400">+ -</span>
                      <span>Zoom in/out</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">R</span>
                      <span>Rotate image</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">F</span>
                      <span>Toggle fullscreen</span>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <h4 className="font-medium text-gray-300">Information</h4>
                  <div className="space-y-1">
                    <div className="flex justify-between">
                      <span className="text-gray-400">I</span>
                      <span>Toggle image info</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">? H</span>
                      <span>Show this help</span>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <h4 className="font-medium text-gray-300">Gestures</h4>
                  <div className="space-y-1">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Double-click</span>
                      <span>Zoom to point</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Drag</span>
                      <span>Pan when zoomed</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Swipe</span>
                      <span>Navigate images</span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Help Button */}
        <div className="absolute top-1/2 right-4 transform -translate-y-1/2">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowHelp(!showHelp)}
                className="text-white hover:bg-white/20 bg-black/30 backdrop-blur-sm"
              >
                ?
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Keyboard shortcuts (?)</p>
            </TooltipContent>
          </Tooltip>
        </div>
      </div>
    </TooltipProvider>
  );
}
import { useState } from "react";
import { motion } from "framer-motion";
import { 
  Search, 
  Filter, 
  Grid, 
  List,
  Camera,
  MapPin,
  Calendar,
  Star,
  Heart,
  Eye,
  RefreshCw
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import AdvancedPortfolioCarousel from "./AdvancedPortfolioCarousel";

const sampleImages = [
  {
    id: "1",
    src: "",
    title: "Highland Mist at Ben Nevis",
    description: "Capturing the ethereal beauty of morning mist across Scotland's highest peak during golden hour",
    category: "Landscape",
    location: "Ben Nevis, Scotland",
    date: "2024-01-15",
    camera: "Canon EOS R5",
    lens: "Canon RF 24-70mm f/2.8L",
    aperture: "f/8",
    shutterSpeed: "1/125s",
    iso: "100",
    tags: ["scotland", "mountains", "mist", "sunrise", "highland", "golden hour"],
    featured: true,
    likes: 234,
    views: 1523
  },
  {
    id: "2",
    src: "",
    title: "Edinburgh Castle at Twilight",
    description: "The historic Edinburgh Castle illuminated against a dramatic twilight sky",
    category: "Architecture",
    location: "Edinburgh, Scotland",
    date: "2024-01-10",
    camera: "Sony A7R IV",
    lens: "Sony FE 24-105mm f/4",
    aperture: "f/11",
    shutterSpeed: "1/60s",
    iso: "200",
    tags: ["edinburgh", "castle", "twilight", "historic", "architecture", "blue hour"],
    featured: false,
    likes: 187,
    views: 892
  },
  {
    id: "3",
    src: "",
    title: "Portrait Session - Natural Light",
    description: "Professional portrait session utilizing natural window light in Edinburgh studio",
    category: "Portrait",
    location: "Edinburgh Studio, Scotland",
    date: "2024-01-05",
    camera: "Canon EOS R6",
    lens: "Canon RF 85mm f/1.2L",
    aperture: "f/2.8",
    shutterSpeed: "1/200s",
    iso: "320",
    tags: ["portrait", "natural light", "studio", "professional", "headshot"],
    featured: true,
    likes: 156,
    views: 743
  },
  {
    id: "4",
    src: "",
    title: "Loch Lomond Reflections",
    description: "Perfect mirror reflections on the still waters of Loch Lomond at dawn",
    category: "Landscape",
    location: "Loch Lomond, Scotland",
    date: "2024-01-20",
    camera: "Nikon D850",
    lens: "Nikkor 14-24mm f/2.8",
    aperture: "f/16",
    shutterSpeed: "1/8s",
    iso: "64",
    tags: ["loch lomond", "reflections", "dawn", "water", "tranquil", "mirror"],
    featured: false,
    likes: 203,
    views: 1102
  },
  {
    id: "5",
    src: "",
    title: "Scottish Wedding - First Dance",
    description: "Intimate first dance moment captured during a Highland wedding celebration",
    category: "Wedding",
    location: "Glen Coe, Scotland",
    date: "2024-01-25",
    camera: "Canon EOS R5",
    lens: "Canon RF 70-200mm f/2.8L",
    aperture: "f/4",
    shutterSpeed: "1/160s",
    iso: "800",
    tags: ["wedding", "first dance", "glen coe", "celebration", "couple", "romantic"],
    featured: true,
    likes: 298,
    views: 1876
  },
  {
    id: "6",
    src: "",
    title: "Isle of Skye Cliffs",
    description: "Dramatic coastal cliffs of the Isle of Skye during a stormy afternoon",
    category: "Landscape",
    location: "Isle of Skye, Scotland",
    date: "2024-01-30",
    camera: "Sony A7R IV",
    lens: "Sony FE 16-35mm f/2.8",
    aperture: "f/13",
    shutterSpeed: "1/250s",
    iso: "400",
    tags: ["isle of skye", "cliffs", "storm", "dramatic", "coastal", "weather"],
    featured: false,
    likes: 167,
    views: 934
  }
];

export default function PortfolioGallery() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [carouselOpen, setCarouselOpen] = useState(false);
  const [carouselIndex, setCarouselIndex] = useState(0);

  // Fetch real assets from database
  const { data: assets = [], isLoading, error } = useQuery({
    queryKey: ['/api/assets'],
    queryFn: async () => {
      try {
        const response = await apiRequest('/api/assets', 'GET');
        return Array.isArray(response) ? response : [];
      } catch (error) {
        console.error('Failed to fetch assets:', error);
        return [];
      }
    }
  });

  // Fetch portfolio items from database
  const { data: portfolioItems = [] } = useQuery({
    queryKey: ['/api/portfolio-items'],
    queryFn: async () => {
      try {
        const response = await apiRequest('/api/portfolio-items', 'GET');
        return Array.isArray(response) ? response : [];
      } catch (error) {
        console.error('Failed to fetch portfolio items:', error);
        return [];
      }
    }
  });

  // Transform database assets into carousel format
  const transformedImages = [...assets, ...portfolioItems].map((item: any) => ({
    id: item.id?.toString() || item.afxId || Math.random().toString(),
    src: item.imageUrl || item.fileLocation || "",
    title: item.title || item.fileName || "Untitled",
    description: item.description || "Photography by Andrew Gwynn",
    category: item.category || "Photography",
    location: item.gpsCoordinates || item.location || "Scotland",
    date: item.dateTaken || item.createdAt || new Date().toISOString(),
    camera: item.deviceUsed || item.camera || "Professional Camera",
    lens: item.lens || "Professional Lens",
    aperture: item.aperture || "f/2.8",
    shutterSpeed: item.shutterSpeed || "1/125s",
    iso: item.iso || "100",
    tags: Array.isArray(item.tags) ? item.tags : (item.tags ? item.tags.split(',') : []),
    featured: Boolean(item.featured),
    likes: item.likes || Math.floor(Math.random() * 300) + 50,
    views: item.views || Math.floor(Math.random() * 2000) + 100
  }));

  // Combine real data with sample data for demonstration
  const allImages = transformedImages.length > 0 ? transformedImages : sampleImages;

  const categories = ["All", ...Array.from(new Set(allImages.map(img => img.category)))];

  const filteredImages = allImages.filter(image => {
    const matchesSearch = !searchQuery || 
      image.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      image.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      image.tags.some((tag: string) => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesCategory = !selectedCategory || selectedCategory === "All" || image.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  const openCarousel = (index: number) => {
    setCarouselIndex(index);
    setCarouselOpen(true);
  };

  const closeCarousel = () => {
    setCarouselOpen(false);
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-center py-12">
          <RefreshCw className="w-8 h-8 animate-spin text-blue-600 mr-3" />
          <span className="text-gray-600">Loading portfolio...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header and Controls */}
      <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-center">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Search portfolio..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        <div className="flex items-center space-x-2">
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="All Categories" />
            </SelectTrigger>
            <SelectContent>
              {categories.map(category => (
                <SelectItem key={category} value={category === "All" ? "" : category}>
                  {category}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <div className="flex items-center space-x-1 border rounded-md">
            <Button
              variant={viewMode === 'grid' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('grid')}
            >
              <Grid className="w-4 h-4" />
            </Button>
            <Button
              variant={viewMode === 'list' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setViewMode('list')}
            >
              <List className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Results Count */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-gray-600">
          {filteredImages.length} image{filteredImages.length !== 1 ? 's' : ''} found
        </p>
      </div>

      {/* Gallery Grid */}
      <div className={
        viewMode === 'grid' 
          ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6' 
          : 'space-y-4'
      }>
        {filteredImages.map((image, index) => (
          <motion.div
            key={image.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: index * 0.05 }}
          >
            <Card 
              className="group hover:shadow-xl transition-all duration-300 cursor-pointer overflow-hidden"
              onClick={() => openCarousel(index)}
            >
              <CardContent className="p-0">
                {viewMode === 'grid' ? (
                  <div className="space-y-0">
                    {/* Image */}
                    <div className="aspect-square relative overflow-hidden bg-gradient-to-br from-blue-50 to-purple-50">
                      <div className="absolute inset-0 flex items-center justify-center">
                        <Camera className="w-12 h-12 text-gray-300" />
                      </div>
                      
                      {/* Overlay with info on hover */}
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-all duration-300 flex items-end p-4 opacity-0 group-hover:opacity-100">
                        <div className="text-white space-y-1">
                          <div className="flex items-center space-x-2 text-xs">
                            <Eye className="w-3 h-3" />
                            <span>{image.views}</span>
                            <Heart className="w-3 h-3" />
                            <span>{image.likes}</span>
                          </div>
                          <p className="text-xs opacity-90 line-clamp-2">{image.description}</p>
                        </div>
                      </div>
                      
                      {/* Featured badge */}
                      {image.featured && (
                        <div className="absolute top-2 right-2">
                          <Badge className="bg-yellow-600/90 text-white">
                            <Star className="w-3 h-3 mr-1" />
                            Featured
                          </Badge>
                        </div>
                      )}
                    </div>
                    
                    {/* Content */}
                    <div className="p-4 space-y-3">
                      <div>
                        <h3 className="font-semibold text-sm line-clamp-1 group-hover:text-blue-600 transition-colors">
                          {image.title}
                        </h3>
                        <p className="text-xs text-gray-600 line-clamp-2 mt-1">{image.description}</p>
                      </div>

                      <div className="flex flex-wrap gap-1">
                        <Badge variant="outline" className="text-xs">{image.category}</Badge>
                      </div>

                      <div className="text-xs text-gray-500 space-y-1">
                        <div className="flex items-center">
                          <MapPin className="w-3 h-3 mr-1" />
                          <span className="truncate">{image.location}</span>
                        </div>
                        <div className="flex items-center">
                          <Calendar className="w-3 h-3 mr-1" />
                          {new Date(image.date).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  /* List View */
                  <div className="flex items-center space-x-4 p-4">
                    <div className="w-20 h-20 bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg flex items-center justify-center flex-shrink-0 relative overflow-hidden">
                      <Camera className="w-8 h-8 text-gray-300" />
                      {image.featured && (
                        <div className="absolute top-1 right-1">
                          <Star className="w-3 h-3 text-yellow-500 fill-current" />
                        </div>
                      )}
                    </div>
                    
                    <div className="flex-1 min-w-0 space-y-2">
                      <div>
                        <h3 className="font-semibold truncate group-hover:text-blue-600 transition-colors">
                          {image.title}
                        </h3>
                        <p className="text-sm text-gray-600 line-clamp-2">{image.description}</p>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4 text-xs text-gray-500">
                          <span>{image.category}</span>
                          <span>{image.location}</span>
                          <span>{new Date(image.date).toLocaleDateString()}</span>
                        </div>
                        
                        <div className="flex items-center space-x-3 text-xs text-gray-500">
                          <div className="flex items-center space-x-1">
                            <Eye className="w-3 h-3" />
                            <span>{image.views}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Heart className="w-3 h-3" />
                            <span>{image.likes}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* No Results */}
      {filteredImages.length === 0 && (
        <div className="text-center py-12">
          <Camera className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No images found</h3>
          <p className="text-gray-600 mb-4">Try adjusting your search terms or filters</p>
          <Button 
            variant="outline" 
            onClick={() => {
              setSearchQuery('');
              setSelectedCategory('');
            }}
          >
            Clear Filters
          </Button>
        </div>
      )}

      {/* Advanced Portfolio Carousel */}
      {carouselOpen && (
        <AdvancedPortfolioCarousel
          images={filteredImages}
          initialIndex={carouselIndex}
          onClose={closeCarousel}
        />
      )}
    </div>
  );
}
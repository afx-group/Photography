import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Play, Pause, SkipForward, SkipBack, Maximize2, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";


interface GalleryImage {
  id: string;
  src: string;
  alt: string;
  title: string;
  location: string;
  date: string;
  camera: string;
  description: string;
}

const galleryImages: GalleryImage[] = [
  {
    id: "1",
    src: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=1600&h=1000",
    alt: "Scottish Highland sunrise",
    title: "Highland Dawn",
    location: "Scottish Highlands",
    date: "September 2023",
    camera: "Canon EOS R5",
    description: "The first light of dawn breaks over the misty Scottish Highlands, creating an ethereal landscape."
  },
  {
    id: "2",
    src: "https://images.unsplash.com/photo-1439066615861-d1af74d74000?ixlib=rb-4.0.3&auto=format&fit=crop&w=1600&h=1000",
    alt: "Mountain lake reflection",
    title: "Mirror Lake",
    location: "Lake District",
    date: "August 2023",
    camera: "Canon EOS R5",
    description: "Perfect reflections in a pristine mountain lake, showcasing nature's symmetry."
  },
  {
    id: "3",
    src: "https://images.unsplash.com/photo-1547036967-23d11aacaee0?ixlib=rb-4.0.3&auto=format&fit=crop&w=1600&h=1000",
    alt: "Desert landscape with dramatic clouds",
    title: "Desert Storm",
    location: "Sahara Desert",
    date: "July 2023",
    camera: "Canon EOS R6",
    description: "Vast desert landscape under dramatic cloudy sky."
  },
  {
    id: "4",
    src: "https://images.unsplash.com/photo-1505142468610-359e7d316be0?ixlib=rb-4.0.3&auto=format&fit=crop&w=1600&h=1000",
    alt: "Ocean waves at sunset",
    title: "Coastal Sunset",
    location: "Cornwall Coast",
    date: "June 2023",
    camera: "Canon EOS R5",
    description: "Ocean waves crashing during vibrant sunset along the Cornish coast."
  },
  {
    id: "5",
    src: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?ixlib=rb-4.0.3&auto=format&fit=crop&w=1600&h=1000",
    alt: "Forest path with sunbeams",
    title: "Enchanted Forest",
    location: "Black Forest, Germany",
    date: "May 2023",
    camera: "Canon EOS R6",
    description: "Mystical forest path illuminated by sunbeams filtering through ancient trees."
  }
];

export default function LiveGallerySection() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [showInfo, setShowInfo] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(3000);

  const currentImage = galleryImages[currentIndex];

  useEffect(() => {
    if (!isPlaying) return;

    const interval = setInterval(() => {
      setCurrentIndex(prev => (prev + 1) % galleryImages.length);
    }, playbackSpeed);

    return () => clearInterval(interval);
  }, [isPlaying, playbackSpeed]);

  const nextImage = () => {
    setCurrentIndex(prev => (prev + 1) % galleryImages.length);
  };

  const prevImage = () => {
    setCurrentIndex(prev => (prev - 1 + galleryImages.length) % galleryImages.length);
  };

  const togglePlayback = () => {
    setIsPlaying(!isPlaying);
  };

  const goToImage = (index: number) => {
    setCurrentIndex(index);
  };

  return (
    <section className="py-20 bg-black text-white relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl sm:text-5xl font-thin mb-6 text-white">
            Live Gallery Showcase
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Experience my photography in an immersive slideshow format
          </p>
        </motion.div>

        {/* Main Display */}
        <div className="relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, scale: 1.1 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.8, ease: "easeInOut" }}
              className="relative"
            >
              <div className="aspect-video rounded-2xl overflow-hidden shadow-2xl">
                <img
                  src={currentImage.src}
                  alt={currentImage.alt}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
              </div>

              {/* Image Info Overlay */}
              <AnimatePresence>
                {showInfo && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 20 }}
                    className="absolute bottom-6 left-6 right-6"
                  >
                    <Card className="bg-black/80 backdrop-blur-sm border-white/20">
                      <CardContent className="p-6 text-white">
                        <h3 className="text-2xl font-bold mb-2">{currentImage.title}</h3>
                        <div className="flex flex-wrap gap-4 mb-3 text-sm">
                          <Badge variant="secondary" className="bg-white/20 text-white">
                            {currentImage.location}
                          </Badge>
                          <Badge variant="secondary" className="bg-white/20 text-white">
                            {currentImage.date}
                          </Badge>
                          <Badge variant="secondary" className="bg-white/20 text-white">
                            {currentImage.camera}
                          </Badge>
                        </div>
                        <p className="text-gray-300">{currentImage.description}</p>
                      </CardContent>
                    </Card>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          </AnimatePresence>

          {/* Controls Overlay */}
          <div className="absolute top-6 right-6 flex gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowInfo(!showInfo)}
              className="bg-black/50 backdrop-blur-sm text-white hover:bg-white/20"
            >
              <Info className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="bg-black/50 backdrop-blur-sm text-white hover:bg-white/20"
            >
              <Maximize2 className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Playback Controls */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mt-8"
        >
          <Card className="bg-black/50 backdrop-blur-sm border-white/20">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-4">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={prevImage}
                    className="text-white hover:bg-white/20"
                  >
                    <SkipBack className="w-4 h-4" />
                  </Button>
                  
                  <Button
                    variant="ghost"
                    size="lg"
                    onClick={togglePlayback}
                    className="text-white hover:bg-white/20"
                  >
                    {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
                  </Button>
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={nextImage}
                    className="text-white hover:bg-white/20"
                  >
                    <SkipForward className="w-4 h-4" />
                  </Button>
                </div>

                <div className="flex items-center gap-4">
                  <span className="text-sm text-gray-300">Speed:</span>
                  <Select
                    value={playbackSpeed.toString()}
                    onValueChange={(value) => setPlaybackSpeed(parseInt(value))}
                  >
                    <SelectTrigger className="w-24 bg-white/10 text-white border-white/20">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1000">1s</SelectItem>
                      <SelectItem value="2000">2s</SelectItem>
                      <SelectItem value="3000">3s</SelectItem>
                      <SelectItem value="4000">4s</SelectItem>
                      <SelectItem value="5000">5s</SelectItem>
                      <SelectItem value="8000">8s</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="mb-4">
                <div className="flex justify-between text-sm text-gray-300 mb-2">
                  <span>{currentIndex + 1} of {galleryImages.length}</span>
                  <span>{currentImage.title}</span>
                </div>
                <div className="w-full bg-white/20 rounded-full h-1">
                  <div
                    className="bg-white h-1 rounded-full transition-all duration-300"
                    style={{ width: `${((currentIndex + 1) / galleryImages.length) * 100}%` }}
                  />
                </div>
              </div>

              {/* Thumbnail Navigation */}
              <div className="flex gap-2 overflow-x-auto pb-2">
                {galleryImages.map((image, index) => (
                  <button
                    key={image.id}
                    onClick={() => goToImage(index)}
                    className={`flex-shrink-0 w-16 h-12 rounded overflow-hidden border-2 transition-all duration-200 ${
                      index === currentIndex
                        ? "border-white shadow-lg"
                        : "border-transparent opacity-60 hover:opacity-80"
                    }`}
                  >
                    <img
                      src={image.src}
                      alt={image.alt}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}
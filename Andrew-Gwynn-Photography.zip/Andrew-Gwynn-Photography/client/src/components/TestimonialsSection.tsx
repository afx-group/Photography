import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Quote, Star, Play, ChevronLeft, ChevronRight, Camera, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface Testimonial {
  id: string;
  name: string;
  role?: string;
  company?: string;
  location?: string;
  content: string;
  rating: number;
  image?: string;
  videoUrl?: string;
  projectType: string;
  projectImage?: string;
  featured: boolean;
  date: string;
}

const testimonials: Testimonial[] = [
  {
    id: "1",
    name: "Sarah Johnson",
    role: "Marketing Director",
    company: "Highlands Tourism Board",
    location: "Edinburgh, Scotland",
    content: "Andrew's landscape photography perfectly captured the ethereal beauty of our region. His ability to find unique perspectives in familiar places is remarkable. The images from our collaboration have significantly enhanced our marketing campaigns.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1494790108755-2616c96c3639?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150",
    projectType: "Landscape Photography",
    projectImage: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    featured: true,
    date: "2023-09-15"
  },
  {
    id: "2",
    name: "Michael Chen",
    role: "CEO",
    company: "Chen & Associates",
    location: "London, England",
    content: "The corporate headshots Andrew created for our executive team were exceptional. Professional, yet warm and approachable. He made everyone feel comfortable during the session, and the results speak for themselves.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150",
    projectType: "Corporate Photography",
    projectImage: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    featured: true,
    date: "2023-08-22"
  },
  {
    id: "3",
    name: "Emma & David Wilson",
    role: "Newly Married",
    location: "Glasgow, Scotland",
    content: "Our wedding photos are absolutely stunning! Andrew captured every precious moment with such artistry. We especially love how he documented the candid moments between the formal shots. These photos will be treasured forever.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1581833971358-2c8b550f87b3?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150",
    videoUrl: "https://example.com/video-testimonial-1",
    projectType: "Wedding Photography",
    projectImage: "https://images.unsplash.com/photo-1519741497674-611481863552?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    featured: true,
    date: "2023-07-10"
  },
  {
    id: "4",
    name: "Robert MacLeod",
    role: "Gallery Owner",
    company: "Edinburgh Fine Arts",
    location: "Edinburgh, Scotland",
    content: "Andrew's artistic vision and technical expertise make him one of the finest photographers I've worked with. His exhibition was one of our most successful, with several pieces selling on opening night.",
    rating: 5,
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150",
    projectType: "Fine Art Photography",
    projectImage: "https://images.unsplash.com/photo-1541961017774-22349e4a1262?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    featured: false,
    date: "2023-06-05"
  }
];

export default function TestimonialsSection() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [playingVideo, setPlayingVideo] = useState<string | null>(null);

  const featuredTestimonials = testimonials.filter(t => t.featured);
  const current = featuredTestimonials[currentIndex];

  const nextTestimonial = () => {
    setCurrentIndex((prev) => (prev + 1) % featuredTestimonials.length);
    setPlayingVideo(null);
  };

  const prevTestimonial = () => {
    setCurrentIndex((prev) => (prev - 1 + featuredTestimonials.length) % featuredTestimonials.length);
    setPlayingVideo(null);
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-4 h-4 ${i < rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`}
      />
    ));
  };

  return (
    <section id="testimonials" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl sm:text-5xl font-thin text-gradient mb-6">
            Client Stories
          </h2>
          <p className="text-xl text-apple-gray max-w-3xl mx-auto">
            Hear from clients who have experienced the difference that thoughtful, professional photography makes.
          </p>
        </motion.div>

        {/* Featured Testimonial Carousel */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mb-16"
        >
          <div className="relative">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentIndex}
                initial={{ opacity: 0, x: 100 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -100 }}
                transition={{ duration: 0.5 }}
                className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center"
              >
                {/* Project Image */}
                <div className="relative group">
                  <img
                    src={current.projectImage}
                    alt={`${current.projectType} project`}
                    className="w-full h-96 object-cover rounded-2xl shadow-xl"
                  />
                  <div className="absolute top-4 left-4">
                    <Badge className="bg-blue-600 text-white">
                      <Camera className="w-3 h-3 mr-1" />
                      {current.projectType}
                    </Badge>
                  </div>
                  {current.videoUrl && (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Button
                        onClick={() => setPlayingVideo(playingVideo === current.id ? null : current.id)}
                        size="lg"
                        className="rounded-full w-16 h-16 bg-white/90 hover:bg-white text-black hover:scale-110 transition-all duration-300"
                      >
                        <Play className="w-6 h-6 ml-1" />
                      </Button>
                    </div>
                  )}
                </div>

                {/* Testimonial Content */}
                <div className="space-y-6">
                  <div className="flex items-start space-x-1">
                    {renderStars(current.rating)}
                  </div>
                  
                  <blockquote className="text-xl text-apple-dark leading-relaxed">
                    <Quote className="w-8 h-8 text-blue-600 mb-4" />
                    "{current.content}"
                  </blockquote>

                  <div className="flex items-center space-x-4">
                    {current.image && (
                      <img
                        src={current.image}
                        alt={current.name}
                        className="w-16 h-16 rounded-full object-cover"
                      />
                    )}
                    <div>
                      <div className="font-semibold text-apple-dark text-lg">{current.name}</div>
                      {current.role && (
                        <div className="text-apple-gray">
                          {current.role}
                          {current.company && `, ${current.company}`}
                        </div>
                      )}
                      {current.location && (
                        <div className="flex items-center text-sm text-apple-gray mt-1">
                          <MapPin className="w-3 h-3 mr-1" />
                          {current.location}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Navigation */}
            {featuredTestimonials.length > 1 && (
              <>
                <Button
                  variant="outline"
                  size="lg"
                  onClick={prevTestimonial}
                  className="absolute left-4 top-1/2 -translate-y-1/2 rounded-full w-12 h-12 z-10"
                >
                  <ChevronLeft className="w-5 h-5" />
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  onClick={nextTestimonial}
                  className="absolute right-4 top-1/2 -translate-y-1/2 rounded-full w-12 h-12 z-10"
                >
                  <ChevronRight className="w-5 h-5" />
                </Button>
              </>
            )}
          </div>

          {/* Dots Navigation */}
          {featuredTestimonials.length > 1 && (
            <div className="flex justify-center mt-8 space-x-2">
              {featuredTestimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentIndex(index)}
                  className={`w-3 h-3 rounded-full transition-all duration-200 ${
                    index === currentIndex 
                      ? 'bg-blue-600 scale-125' 
                      : 'bg-gray-300 hover:bg-gray-400'
                  }`}
                />
              ))}
            </div>
          )}
        </motion.div>

        {/* All Testimonials Grid */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h3 className="text-3xl font-light text-apple-dark mb-8 text-center">
            What Clients Say
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={testimonial.id}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
              >
                <Card className="h-full hover:shadow-lg transition-shadow duration-300">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-1">
                        {renderStars(testimonial.rating)}
                      </div>
                      <Badge variant="secondary">{testimonial.projectType}</Badge>
                    </div>
                    
                    <blockquote className="text-apple-dark mb-4 line-clamp-4">
                      "{testimonial.content}"
                    </blockquote>

                    <div className="flex items-center space-x-3 mt-auto">
                      {testimonial.image && (
                        <img
                          src={testimonial.image}
                          alt={testimonial.name}
                          className="w-10 h-10 rounded-full object-cover"
                        />
                      )}
                      <div className="flex-1">
                        <div className="font-medium text-apple-dark">{testimonial.name}</div>
                        {testimonial.role && (
                          <div className="text-sm text-apple-gray">
                            {testimonial.role}
                            {testimonial.company && `, ${testimonial.company}`}
                          </div>
                        )}
                      </div>
                      {testimonial.videoUrl && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setPlayingVideo(playingVideo === testimonial.id ? null : testimonial.id)}
                        >
                          <Play className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
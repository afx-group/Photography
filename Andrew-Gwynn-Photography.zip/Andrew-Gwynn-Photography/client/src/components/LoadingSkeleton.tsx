import { motion } from "framer-motion";

interface LoadingSkeletonProps {
  variant?: 'card' | 'list' | 'grid' | 'text' | 'image';
  count?: number;
  className?: string;
}

export function LoadingSkeleton({ variant = 'card', count = 1, className = '' }: LoadingSkeletonProps) {
  const skeletonAnimation = {
    initial: { opacity: 0.6 },
    animate: { opacity: 1 },
    transition: {
      duration: 0.8,
      repeat: Infinity,
      repeatType: "reverse" as const,
      ease: "easeInOut"
    }
  };

  const renderSkeleton = () => {
    switch (variant) {
      case 'card':
        return (
          <motion.div 
            className={`bg-white rounded-lg border p-6 space-y-4 ${className}`}
            {...skeletonAnimation}
          >
            <div className="h-48 bg-gray-200 rounded-lg animate-pulse" />
            <div className="space-y-2">
              <div className="h-4 bg-gray-200 rounded animate-pulse" />
              <div className="h-4 bg-gray-200 rounded w-3/4 animate-pulse" />
            </div>
            <div className="flex space-x-2">
              <div className="h-6 w-16 bg-gray-200 rounded-full animate-pulse" />
              <div className="h-6 w-20 bg-gray-200 rounded-full animate-pulse" />
            </div>
          </motion.div>
        );

      case 'list':
        return (
          <motion.div 
            className={`bg-white rounded-lg border p-4 flex items-center space-x-4 ${className}`}
            {...skeletonAnimation}
          >
            <div className="w-16 h-16 bg-gray-200 rounded-lg animate-pulse" />
            <div className="flex-1 space-y-2">
              <div className="h-4 bg-gray-200 rounded animate-pulse" />
              <div className="h-3 bg-gray-200 rounded w-2/3 animate-pulse" />
            </div>
            <div className="h-8 w-24 bg-gray-200 rounded animate-pulse" />
          </motion.div>
        );

      case 'grid':
        return (
          <motion.div 
            className={`aspect-square bg-gray-200 rounded-lg animate-pulse ${className}`}
            {...skeletonAnimation}
          />
        );

      case 'text':
        return (
          <motion.div 
            className={`space-y-2 ${className}`}
            {...skeletonAnimation}
          >
            <div className="h-4 bg-gray-200 rounded animate-pulse" />
            <div className="h-4 bg-gray-200 rounded w-5/6 animate-pulse" />
            <div className="h-4 bg-gray-200 rounded w-4/6 animate-pulse" />
          </motion.div>
        );

      case 'image':
        return (
          <motion.div 
            className={`aspect-video bg-gray-200 rounded-lg animate-pulse ${className}`}
            {...skeletonAnimation}
          />
        );

      default:
        return (
          <motion.div 
            className={`h-20 bg-gray-200 rounded animate-pulse ${className}`}
            {...skeletonAnimation}
          />
        );
    }
  };

  return (
    <>
      {Array.from({ length: count }, (_, index) => (
        <div key={index}>
          {renderSkeleton()}
        </div>
      ))}
    </>
  );
}

export default LoadingSkeleton;
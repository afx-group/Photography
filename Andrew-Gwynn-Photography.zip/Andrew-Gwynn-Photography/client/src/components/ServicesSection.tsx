import { motion } from "framer-motion";
import { Heart, User, Calendar, Palette } from "lucide-react";
import { useIntersectionObserver } from "@/hooks/useIntersectionObserver";

const services = [
  {
    icon: Heart,
    title: "Landscape Photography",
    description: "Stunning portrayals of natural and urban scenes, crafted to inspire viewers to pause and ponder, escape and wander.",
    gradient: "from-blue-500 to-blue-600",
  },
  {
    icon: User,
    title: "Portrait Photography",
    description: "Individual and family portraits that emphasize unique personalities and stories, creating timeless keepsakes.",
    gradient: "from-purple-500 to-purple-600",
  },
  {
    icon: Calendar,
    title: "Event Photography",
    description: "Comprehensive event coverage capturing pivotal moments in weddings, corporate gatherings, and cultural events.",
    gradient: "from-green-500 to-green-600",
  },
  {
    icon: Palette,
    title: "Artistic Photography",
    description: "Visual artistry combining photography with digital techniques, producing thought-provoking and conversation-starting images.",
    gradient: "from-orange-500 to-orange-600",
  },
];

export default function ServicesSection() {
  const [ref, isVisible] = useIntersectionObserver({
    threshold: 0.1,
    rootMargin: "0px 0px -50px 0px",
  });

  return (
    <section id="services" className="py-20 bg-apple-light" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl sm:text-5xl font-thin text-gradient mb-6">
            Services
          </h2>
          <p className="text-xl text-apple-gray max-w-3xl mx-auto">
            Professional photography services tailored to capture your unique story and vision.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -5 }}
              className="bg-white rounded-3xl p-8 hover-lift shadow-lg"
            >
              <motion.div
                whileHover={{ scale: 1.1, rotate: 5 }}
                transition={{ duration: 0.3 }}
                className={`w-16 h-16 bg-gradient-to-br ${service.gradient} rounded-2xl flex items-center justify-center mb-6`}
              >
                <service.icon className="w-8 h-8 text-white" />
              </motion.div>
              
              <h3 className="text-2xl font-semibold text-apple-dark mb-4">
                {service.title}
              </h3>
              
              <p className="text-apple-gray leading-relaxed">
                {service.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

import { useState } from "react";
import { motion } from "framer-motion";
import { useIntersectionObserver } from "@/hooks/useIntersectionObserver";
import { PORTFOLIO_IMAGES } from "@/lib/constants";
import ImagePreviewModal from "@/components/ImagePreviewModal";

interface ImageGridProps {
  images: Array<{ src: string; alt: string; className?: string; title?: string; description?: string; category?: string }>;
  onImageClick: (index: number) => void;
  startIndex: number;
}

function ImageGrid({ images, onImageClick, startIndex }: ImageGridProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {images.map((image, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: index * 0.1 }}
          className={`group hover-lift cursor-pointer ${image.className || ""}`}
          onClick={() => onImageClick(startIndex + index)}
        >
          <motion.img
            whileHover={{ scale: 1.02 }}
            transition={{ duration: 0.3 }}
            src={image.src}
            alt={image.alt}
            className="w-full h-80 object-cover rounded-2xl image-blur-load shadow-lg hover:shadow-2xl transition-shadow duration-300"
            loading="lazy"
            onLoad={(e) => {
              e.currentTarget.classList.add("loaded");
            }}
          />
          {/* Hover overlay */}
          <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-300 rounded-2xl flex items-center justify-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              whileHover={{ opacity: 1, scale: 1 }}
              className="text-white text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity duration-300"
            >
              Click to view
            </motion.div>
          </div>
        </motion.div>
      ))}
    </div>
  );
}

export default function PortfolioSection() {
  const [ref, isVisible] = useIntersectionObserver({
    threshold: 0.1,
    rootMargin: "0px 0px -50px 0px",
  });

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  // Combine all portfolio images into a single array for modal navigation
  const allImages = [
    ...PORTFOLIO_IMAGES.landscape.map((img: any) => ({ ...img, category: "Landscape" })),
    ...PORTFOLIO_IMAGES.portrait.map((img: any) => ({ ...img, category: "Portrait" })),
    ...PORTFOLIO_IMAGES.event.map((img: any) => ({ ...img, category: "Events" })),
    ...PORTFOLIO_IMAGES.artistic.map((img: any) => ({ ...img, category: "Artistic" }))
  ];

  const handleImageClick = (index: number) => {
    setCurrentImageIndex(index);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
  };

  const handleIndexChange = (index: number) => {
    setCurrentImageIndex(index);
  };

  return (
    <section id="portfolio" className="py-20 bg-white" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl sm:text-5xl font-thin text-gradient mb-6">
            Portfolio
          </h2>
          <p className="text-xl text-apple-gray max-w-3xl mx-auto">
            Specializing in landscape, portrait, event, and artistic photography, I capture moments that resonate deeply, 
            transforming them into works of art suited for any setting.
          </p>
        </motion.div>

        {/* Landscape Photography */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mb-20"
        >
          <h3 className="text-3xl font-light text-apple-dark mb-8 text-center">
            Landscape Photography
          </h3>
          <ImageGrid 
            images={PORTFOLIO_IMAGES.landscape} 
            onImageClick={handleImageClick}
            startIndex={0}
          />
        </motion.div>

        {/* Portrait Photography */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mb-20"
        >
          <h3 className="text-3xl font-light text-apple-dark mb-8 text-center">
            Portrait Photography
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {PORTFOLIO_IMAGES.portrait.map((image, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className={`group hover-lift cursor-pointer relative ${image.className || ""}`}
                onClick={() => handleImageClick(PORTFOLIO_IMAGES.landscape.length + index)}
              >
                <motion.img
                  whileHover={{ scale: 1.02 }}
                  transition={{ duration: 0.3 }}
                  src={image.src}
                  alt={image.alt}
                  className="w-full h-80 object-cover rounded-2xl image-blur-load shadow-lg hover:shadow-2xl transition-shadow duration-300"
                  loading="lazy"
                  onLoad={(e) => {
                    e.currentTarget.classList.add("loaded");
                  }}
                />
                <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-300 rounded-2xl flex items-center justify-center">
                  <motion.div
                    initial={{ opacity: 0, scale: 0.8 }}
                    whileHover={{ opacity: 1, scale: 1 }}
                    className="text-white text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  >
                    Click to view
                  </motion.div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Event Photography */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mb-20"
        >
          <h3 className="text-3xl font-light text-apple-dark mb-8 text-center">
            Event Photography
          </h3>
          <ImageGrid 
            images={PORTFOLIO_IMAGES.event} 
            onImageClick={handleImageClick}
            startIndex={PORTFOLIO_IMAGES.landscape.length + PORTFOLIO_IMAGES.portrait.length}
          />
        </motion.div>

        {/* Artistic Photography */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="mb-20"
        >
          <h3 className="text-3xl font-light text-apple-dark mb-8 text-center">
            Artistic Photography
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {PORTFOLIO_IMAGES.artistic.map((image, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className={`group hover-lift cursor-pointer relative ${image.className || ""}`}
                onClick={() => handleImageClick(PORTFOLIO_IMAGES.landscape.length + PORTFOLIO_IMAGES.portrait.length + PORTFOLIO_IMAGES.event.length + index)}
              >
                <motion.img
                  whileHover={{ scale: 1.02 }}
                  transition={{ duration: 0.3 }}
                  src={image.src}
                  alt={image.alt}
                  className="w-full h-80 object-cover rounded-2xl image-blur-load shadow-lg hover:shadow-2xl transition-shadow duration-300"
                  loading="lazy"
                  onLoad={(e) => {
                    e.currentTarget.classList.add("loaded");
                  }}
                />
                <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-300 rounded-2xl flex items-center justify-center">
                  <motion.div
                    initial={{ opacity: 0, scale: 0.8 }}
                    whileHover={{ opacity: 1, scale: 1 }}
                    className="text-white text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  >
                    Click to view
                  </motion.div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Image Preview Modal */}
      <ImagePreviewModal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        images={allImages}
        currentIndex={currentImageIndex}
        onIndexChange={handleIndexChange}
      />
    </section>
  );
}

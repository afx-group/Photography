import { useState } from "react";
import { motion } from "framer-motion";
import { Calendar, Clock, MapPin, Camera, Users, Phone, Mail, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";

interface SessionType {
  id: string;
  name: string;
  description: string;
  duration: number; // in hours
  price: number;
  includes: string[];
  category: string;
  maxPeople?: number;
}

interface AvailableSlot {
  date: string;
  time: string;
  available: boolean;
}

const sessionTypes: SessionType[] = [
  {
    id: "portrait",
    name: "Portrait Session",
    description: "Professional portrait photography in studio or outdoor location",
    duration: 2,
    price: 350,
    includes: ["2-hour session", "Professional editing", "10 high-res images", "Online gallery"],
    category: "Portrait",
    maxPeople: 3
  },
  {
    id: "corporate",
    name: "Corporate Headshots",
    description: "Professional business portraits for individuals or teams",
    duration: 1.5,
    price: 250,
    includes: ["1.5-hour session", "Professional editing", "5 high-res images", "Quick turnaround"],
    category: "Corporate",
    maxPeople: 1
  },
  {
    id: "wedding",
    name: "Wedding Photography",
    description: "Complete wedding day coverage from preparation to reception",
    duration: 8,
    price: 2500,
    includes: ["Full day coverage", "Engagement session", "500+ edited images", "Online gallery", "Print release"],
    category: "Wedding"
  },
  {
    id: "event",
    name: "Event Photography",
    description: "Corporate events, parties, and special occasions",
    duration: 4,
    price: 800,
    includes: ["4-hour coverage", "Professional editing", "100+ images", "Online gallery"],
    category: "Event"
  },
  {
    id: "landscape",
    name: "Landscape Workshop",
    description: "One-on-one landscape photography tuition in Scottish locations",
    duration: 6,
    price: 450,
    includes: ["6-hour workshop", "Location scouting", "Technique instruction", "Post-processing tips"],
    category: "Education",
    maxPeople: 4
  }
];

// Mock available slots for the next 30 days
const generateAvailableSlots = (): AvailableSlot[] => {
  const slots: AvailableSlot[] = [];
  const today = new Date();
  
  for (let i = 1; i <= 30; i++) {
    const date = new Date(today);
    date.setDate(today.getDate() + i);
    
    // Skip Sundays (day 0)
    if (date.getDay() === 0) continue;
    
    const dateStr = date.toISOString().split('T')[0];
    
    // Morning slots
    if (Math.random() > 0.3) {
      slots.push({ date: dateStr, time: "09:00", available: Math.random() > 0.4 });
    }
    if (Math.random() > 0.3) {
      slots.push({ date: dateStr, time: "11:00", available: Math.random() > 0.4 });
    }
    
    // Afternoon slots
    if (Math.random() > 0.2) {
      slots.push({ date: dateStr, time: "14:00", available: Math.random() > 0.3 });
    }
    if (Math.random() > 0.2) {
      slots.push({ date: dateStr, time: "16:00", available: Math.random() > 0.3 });
    }
  }
  
  return slots.sort((a, b) => a.date.localeCompare(b.date) || a.time.localeCompare(b.time));
};

export default function BookingSection() {
  const [selectedSession, setSelectedSession] = useState<SessionType | null>(null);
  const [selectedDate, setSelectedDate] = useState("");
  const [selectedTime, setSelectedTime] = useState("");
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
    numberOfPeople: 1,
    location: "",
    specialRequests: ""
  });
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const availableSlots = generateAvailableSlots();

  const getAvailableDates = () => {
    if (!selectedSession) return [];
    
    const uniqueDates = new Set(availableSlots
      .filter(slot => slot.available)
      .map(slot => slot.date)
    );
    
    const dates = Array.from(uniqueDates);
    return dates.sort();
  };

  const getAvailableTimes = (date: string) => {
    return availableSlots
      .filter(slot => slot.date === date && slot.available)
      .map(slot => slot.time);
  };

  const handleInputChange = (field: string, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSession || !selectedDate || !selectedTime || !agreedToTerms) return;

    setIsSubmitting(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIsSubmitted(true);
    setIsSubmitting(false);
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const formatTime = (timeStr: string) => {
    return new Date(`2000-01-01T${timeStr}`).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  if (isSubmitted) {
    return (
      <section className="py-20 bg-gray-50">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
          >
            <div className="bg-white rounded-2xl p-12 shadow-xl">
              <CheckCircle className="w-20 h-20 text-green-600 mx-auto mb-6" />
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Booking Request Received!</h2>
              <p className="text-xl text-gray-600 mb-6">
                Thank you for your booking request. I'll review the details and get back to you within 24 hours to confirm your session.
              </p>
              <div className="bg-gray-50 rounded-lg p-6 mb-6">
                <h3 className="font-semibold mb-4">Booking Summary</h3>
                <div className="text-left space-y-2">
                  <p><strong>Session:</strong> {selectedSession?.name}</p>
                  <p><strong>Date:</strong> {formatDate(selectedDate)}</p>
                  <p><strong>Time:</strong> {formatTime(selectedTime)}</p>
                  <p><strong>Duration:</strong> {selectedSession?.duration} hours</p>
                  <p><strong>Investment:</strong> £{selectedSession?.price}</p>
                </div>
              </div>
              <p className="text-gray-600 mb-8">
                Please check your email for a confirmation message with additional details and preparation guidelines.
              </p>
              <Button onClick={() => window.location.reload()} size="lg">
                Book Another Session
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    );
  }

  return (
    <section id="booking" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl sm:text-5xl font-thin text-gradient mb-6">
            Book a Session
          </h2>
          <p className="text-xl text-apple-gray max-w-3xl mx-auto">
            Ready to create something beautiful together? Choose your session type and let's schedule your photography experience.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Session Types */}
          <div className="lg:col-span-2">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <h3 className="text-2xl font-semibold mb-6">1. Choose Your Session</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                {sessionTypes.map((session) => (
                  <Card
                    key={session.id}
                    className={`cursor-pointer transition-all duration-300 ${
                      selectedSession?.id === session.id
                        ? "ring-2 ring-blue-600 shadow-lg"
                        : "hover:shadow-md"
                    }`}
                    onClick={() => setSelectedSession(session)}
                  >
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="text-lg">{session.name}</CardTitle>
                          <Badge variant="secondary" className="mt-1">{session.category}</Badge>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-blue-600">£{session.price}</div>
                          <div className="text-sm text-gray-600 flex items-center">
                            <Clock className="w-3 h-3 mr-1" />
                            {session.duration}h
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600 mb-4">{session.description}</p>
                      <div className="space-y-1">
                        <h4 className="font-medium text-sm">Includes:</h4>
                        {session.includes.map((item, index) => (
                          <div key={index} className="text-sm text-gray-600 flex items-center">
                            <CheckCircle className="w-3 h-3 mr-2 text-green-600" />
                            {item}
                          </div>
                        ))}
                      </div>
                      {session.maxPeople && (
                        <p className="text-xs text-gray-500 mt-2 flex items-center">
                          <Users className="w-3 h-3 mr-1" />
                          Up to {session.maxPeople} people
                        </p>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Date and Time Selection */}
              {selectedSession && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                >
                  <h3 className="text-2xl font-semibold mb-6">2. Select Date & Time</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                    <div>
                      <label className="block text-sm font-medium mb-2">Preferred Date</label>
                      <Select value={selectedDate} onValueChange={setSelectedDate}>
                        <SelectTrigger>
                          <SelectValue placeholder="Choose a date" />
                        </SelectTrigger>
                        <SelectContent>
                          {getAvailableDates().map(date => (
                            <SelectItem key={date} value={date}>
                              {formatDate(date)}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {selectedDate && (
                      <div>
                        <label className="block text-sm font-medium mb-2">Preferred Time</label>
                        <Select value={selectedTime} onValueChange={setSelectedTime}>
                          <SelectTrigger>
                            <SelectValue placeholder="Choose a time" />
                          </SelectTrigger>
                          <SelectContent>
                            {getAvailableTimes(selectedDate).map(time => (
                              <SelectItem key={time} value={time}>
                                {formatTime(time)}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}

              {/* Contact Form */}
              {selectedSession && selectedDate && selectedTime && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                >
                  <h3 className="text-2xl font-semibold mb-6">3. Your Details</h3>
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-1">Full Name *</label>
                        <Input
                          value={formData.name}
                          onChange={(e) => handleInputChange("name", e.target.value)}
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1">Email Address *</label>
                        <Input
                          type="email"
                          value={formData.email}
                          onChange={(e) => handleInputChange("email", e.target.value)}
                          required
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium mb-1">Phone Number</label>
                        <Input
                          type="tel"
                          value={formData.phone}
                          onChange={(e) => handleInputChange("phone", e.target.value)}
                        />
                      </div>
                      {selectedSession.maxPeople && selectedSession.maxPeople > 1 && (
                        <div>
                          <label className="block text-sm font-medium mb-1">Number of People</label>
                          <Select
                            value={formData.numberOfPeople.toString()}
                            onValueChange={(value) => handleInputChange("numberOfPeople", parseInt(value))}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {Array.from({ length: selectedSession.maxPeople }, (_, i) => i + 1).map(num => (
                                <SelectItem key={num} value={num.toString()}>{num}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      )}
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-1">Preferred Location</label>
                      <Input
                        value={formData.location}
                        onChange={(e) => handleInputChange("location", e.target.value)}
                        placeholder="Studio, outdoor location, or your venue"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-1">Tell me about your vision</label>
                      <Textarea
                        value={formData.message}
                        onChange={(e) => handleInputChange("message", e.target.value)}
                        placeholder="Describe what you're looking for, any special requirements, or questions you have..."
                        rows={4}
                      />
                    </div>

                    <div className="flex items-start space-x-2">
                      <Checkbox
                        id="terms"
                        checked={agreedToTerms}
                        onCheckedChange={(checked) => setAgreedToTerms(checked === true)}
                      />
                      <label htmlFor="terms" className="text-sm text-gray-600">
                        I agree to the booking terms and conditions, including the 48-hour cancellation policy and 50% deposit requirement.
                      </label>
                    </div>

                    <Button
                      type="submit"
                      size="lg"
                      className="w-full"
                      disabled={!agreedToTerms || isSubmitting}
                    >
                      {isSubmitting ? "Submitting..." : "Request Booking"}
                    </Button>
                  </form>
                </motion.div>
              )}
            </motion.div>
          </div>

          {/* Booking Summary */}
          <div className="lg:col-span-1">
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="sticky top-8"
            >
              <Card>
                <CardHeader>
                  <CardTitle>Booking Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {selectedSession ? (
                    <>
                      <div>
                        <h4 className="font-medium">{selectedSession.name}</h4>
                        <p className="text-sm text-gray-600">{selectedSession.description}</p>
                        <div className="mt-2 space-y-1">
                          <div className="flex items-center text-sm">
                            <Clock className="w-4 h-4 mr-2" />
                            {selectedSession.duration} hours
                          </div>
                          {selectedSession.maxPeople && (
                            <div className="flex items-center text-sm">
                              <Users className="w-4 h-4 mr-2" />
                              Up to {selectedSession.maxPeople} people
                            </div>
                          )}
                        </div>
                      </div>

                      {selectedDate && (
                        <div>
                          <div className="flex items-center text-sm">
                            <Calendar className="w-4 h-4 mr-2" />
                            {formatDate(selectedDate)}
                          </div>
                          {selectedTime && (
                            <div className="flex items-center text-sm mt-1">
                              <Clock className="w-4 h-4 mr-2" />
                              {formatTime(selectedTime)}
                            </div>
                          )}
                        </div>
                      )}

                      <div className="border-t pt-4">
                        <div className="flex justify-between items-center">
                          <span className="font-medium">Session Fee:</span>
                          <span className="text-xl font-bold">£{selectedSession.price}</span>
                        </div>
                        <p className="text-xs text-gray-600 mt-1">
                          50% deposit required to secure booking
                        </p>
                      </div>
                    </>
                  ) : (
                    <p className="text-gray-600">Select a session type to see pricing and details.</p>
                  )}
                </CardContent>
              </Card>

              <Card className="mt-6">
                <CardHeader>
                  <CardTitle className="text-lg">Contact Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center">
                    <Phone className="w-4 h-4 mr-3" />
                    <span className="text-sm">+44 123 456 7890</span>
                  </div>
                  <div className="flex items-center">
                    <Mail className="w-4 h-4 mr-3" />
                    <span className="text-sm">hello@andrewgwynn.com</span>
                  </div>
                  <div className="flex items-start">
                    <MapPin className="w-4 h-4 mr-3 mt-0.5" />
                    <span className="text-sm">Based in Edinburgh, Scotland<br />Available throughout UK</span>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
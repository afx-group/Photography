import { useState } from "react";
import { motion } from "framer-motion";
import { 
  PenTool, 
  Calendar, 
  Clock, 
  Eye, 
  Heart, 
  Share2, 
  Tag,
  Plus,
  Search,
  Filter,
  BookOpen,
  Camera,
  Lightbulb,
  Users
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  coverImage: string;
  category: string;
  tags: string[];
  publishDate: string;
  readTime: number;
  featured: boolean;
  views: number;
  likes: number;
  author: string;
  slug: string;
  status: 'draft' | 'published' | 'scheduled';
}

export default function BlogSection() {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [showAddDialog, setShowAddDialog] = useState(false);

  const [blogForm, setBlogForm] = useState<{
    title: string;
    excerpt: string;
    content: string;
    category: string;
    tags: string;
    coverImage: string;
    featured: boolean;
    status: "draft" | "published" | "scheduled";
  }>({
    title: "",
    excerpt: "",
    content: "",
    category: "",
    tags: "",
    coverImage: "",
    featured: false,
    status: "draft"
  });

  // Sample blog posts for photography insights
  const blogPosts: BlogPost[] = [
    {
      id: "1",
      title: "Mastering Golden Hour Photography in Scottish Highlands",
      excerpt: "Discover the secrets to capturing breathtaking landscape photos during the golden hour across Scotland's dramatic terrain.",
      content: "The golden hour in the Scottish Highlands offers photographers a magical window of opportunity...",
      coverImage: "",
      category: "Landscape Photography",
      tags: ["golden hour", "scotland", "highlands", "landscape", "tips"],
      publishDate: "2024-01-15",
      readTime: 8,
      featured: true,
      views: 1250,
      likes: 89,
      author: "Andrew Gwynn",
      slug: "mastering-golden-hour-scottish-highlands",
      status: "published"
    },
    {
      id: "2",
      title: "Portrait Photography: Connecting with Your Subject",
      excerpt: "Learn how to create authentic portraits by building rapport and trust with your subjects.",
      content: "Great portrait photography goes beyond technical skill...",
      coverImage: "",
      category: "Portrait Photography",
      tags: ["portraits", "people", "connection", "techniques"],
      publishDate: "2024-01-10",
      readTime: 6,
      featured: false,
      views: 892,
      likes: 64,
      author: "Andrew Gwynn",
      slug: "portrait-photography-connecting-subjects",
      status: "published"
    },
    {
      id: "3",
      title: "Equipment Review: Best Lenses for Wedding Photography",
      excerpt: "A comprehensive review of the essential lenses every wedding photographer should consider.",
      content: "Wedding photography demands versatility and reliability...",
      coverImage: "",
      category: "Equipment Reviews",
      tags: ["equipment", "lenses", "wedding", "gear", "review"],
      publishDate: "2024-01-05",
      readTime: 12,
      featured: false,
      views: 756,
      likes: 45,
      author: "Andrew Gwynn",
      slug: "best-lenses-wedding-photography",
      status: "published"
    },
    {
      id: "4",
      title: "Building Your Photography Business: Lessons Learned",
      excerpt: "Five years of professional photography: insights, challenges, and advice for aspiring photographers.",
      content: "Starting a photography business in Scotland has been an incredible journey...",
      coverImage: "",
      category: "Business Insights",
      tags: ["business", "entrepreneurship", "photography", "tips", "career"],
      publishDate: "2024-01-01",
      readTime: 10,
      featured: true,
      views: 1450,
      likes: 156,
      author: "Andrew Gwynn",
      slug: "building-photography-business-lessons",
      status: "published"
    }
  ];

  const categories = ["All", "Landscape Photography", "Portrait Photography", "Equipment Reviews", "Business Insights", "Tutorials"];

  const filteredPosts = blogPosts.filter(post => {
    const matchesSearch = post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         post.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         post.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesCategory = selectedCategory === "" || selectedCategory === "All" || post.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  const featuredPosts = blogPosts.filter(post => post.featured);

  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Creating blog post:', blogForm);
    setShowAddDialog(false);
    setBlogForm({
      title: "",
      excerpt: "",
      content: "",
      category: "",
      tags: "",
      coverImage: "",
      featured: false,
      status: "draft"
    });
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center space-y-4 lg:space-y-0">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 flex items-center">
            <PenTool className="w-8 h-8 mr-3 text-blue-600" />
            Photography Journal
          </h2>
          <p className="text-gray-600 mt-1">Insights, tutorials, and stories from behind the lens</p>
        </div>

        <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              New Post
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create New Blog Post</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleCreatePost} className="space-y-6">
              <div>
                <Label htmlFor="title">Post Title *</Label>
                <Input
                  id="title"
                  value={blogForm.title}
                  onChange={(e) => setBlogForm(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="Enter compelling post title..."
                  required
                />
              </div>

              <div>
                <Label htmlFor="excerpt">Excerpt *</Label>
                <Textarea
                  id="excerpt"
                  value={blogForm.excerpt}
                  onChange={(e) => setBlogForm(prev => ({ ...prev, excerpt: e.target.value }))}
                  placeholder="Brief description that appears in post previews..."
                  rows={3}
                  required
                />
              </div>

              <div>
                <Label htmlFor="content">Content *</Label>
                <Textarea
                  id="content"
                  value={blogForm.content}
                  onChange={(e) => setBlogForm(prev => ({ ...prev, content: e.target.value }))}
                  placeholder="Write your photography insights, tips, or story..."
                  rows={8}
                  required
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="category">Category</Label>
                  <Select value={blogForm.category} onValueChange={(value) => setBlogForm(prev => ({ ...prev, category: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Landscape Photography">Landscape Photography</SelectItem>
                      <SelectItem value="Portrait Photography">Portrait Photography</SelectItem>
                      <SelectItem value="Equipment Reviews">Equipment Reviews</SelectItem>
                      <SelectItem value="Business Insights">Business Insights</SelectItem>
                      <SelectItem value="Tutorials">Tutorials</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="tags">Tags</Label>
                  <Input
                    id="tags"
                    value={blogForm.tags}
                    onChange={(e) => setBlogForm(prev => ({ ...prev, tags: e.target.value }))}
                    placeholder="landscape, tips, scotland (comma separated)"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="coverImage">Cover Image URL</Label>
                <Input
                  id="coverImage"
                  value={blogForm.coverImage}
                  onChange={(e) => setBlogForm(prev => ({ ...prev, coverImage: e.target.value }))}
                  placeholder="https://..."
                />
              </div>

              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="featured"
                    checked={blogForm.featured}
                    onChange={(e) => setBlogForm(prev => ({ ...prev, featured: e.target.checked }))}
                    className="rounded"
                  />
                  <Label htmlFor="featured">Featured post</Label>
                </div>

                <div>
                  <Label htmlFor="status">Status</Label>
                  <Select value={blogForm.status} onValueChange={(value: "draft" | "published" | "scheduled") => setBlogForm(prev => ({ ...prev, status: value }))}>
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="draft">Draft</SelectItem>
                      <SelectItem value="published">Published</SelectItem>
                      <SelectItem value="scheduled">Scheduled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex justify-end space-x-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setShowAddDialog(false)}>
                  Cancel
                </Button>
                <Button type="submit">
                  Create Post
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Search posts by title, content, or tags..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        <Select value={selectedCategory} onValueChange={setSelectedCategory}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="All Categories" />
          </SelectTrigger>
          <SelectContent>
            {categories.map(category => (
              <SelectItem key={category} value={category === "All" ? "" : category}>
                {category}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Button
          variant="outline"
          size="sm"
          onClick={() => setViewMode(viewMode === 'grid' ? 'list' : 'grid')}
        >
          {viewMode === 'grid' ? <BookOpen className="w-4 h-4" /> : <Camera className="w-4 h-4" />}
        </Button>
      </div>

      {/* Featured Posts */}
      {featuredPosts.length > 0 && (
        <div>
          <h3 className="text-xl font-semibold mb-4 flex items-center">
            <Lightbulb className="w-5 h-5 mr-2 text-yellow-500" />
            Featured Insights
          </h3>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {featuredPosts.map((post) => (
              <motion.div
                key={post.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <Card className="h-full border-yellow-200 bg-gradient-to-br from-yellow-50 to-orange-50 hover:shadow-lg transition-shadow cursor-pointer">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
                        Featured
                      </Badge>
                      <Badge variant="outline">{post.category}</Badge>
                    </div>

                    <h3 className="text-xl font-bold text-gray-900 mb-3 line-clamp-2">
                      {post.title}
                    </h3>
                    
                    <p className="text-gray-700 mb-4 line-clamp-3">
                      {post.excerpt}
                    </p>

                    <div className="flex flex-wrap gap-2 mb-4">
                      {post.tags.slice(0, 3).map((tag) => (
                        <Badge key={tag} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex items-center justify-between text-sm text-gray-500">
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center">
                          <Calendar className="w-3 h-3 mr-1" />
                          {new Date(post.publishDate).toLocaleDateString()}
                        </div>
                        <div className="flex items-center">
                          <Clock className="w-3 h-3 mr-1" />
                          {post.readTime} min read
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <div className="flex items-center">
                          <Eye className="w-3 h-3 mr-1" />
                          {post.views}
                        </div>
                        <div className="flex items-center">
                          <Heart className="w-3 h-3 mr-1" />
                          {post.likes}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* All Posts */}
      <div>
        <h3 className="text-xl font-semibold mb-4">Latest Posts</h3>
        <div className={`${
          viewMode === 'grid' 
            ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6' 
            : 'space-y-4'
        }`}>
          {filteredPosts.map((post) => (
            <motion.div
              key={post.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <Badge variant="outline">{post.category}</Badge>
                    <div className="flex items-center space-x-1">
                      <Button variant="ghost" size="sm">
                        <Share2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>

                  <h3 className="text-lg font-bold text-gray-900 mb-3 line-clamp-2">
                    {post.title}
                  </h3>
                  
                  <p className="text-gray-700 mb-4 line-clamp-3">
                    {post.excerpt}
                  </p>

                  <div className="flex flex-wrap gap-2 mb-4">
                    {post.tags.slice(0, 4).map((tag) => (
                      <Badge key={tag} variant="secondary" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>

                  <div className="flex items-center justify-between text-sm text-gray-500">
                    <div className="flex items-center space-x-3">
                      <div className="flex items-center">
                        <Calendar className="w-3 h-3 mr-1" />
                        {new Date(post.publishDate).toLocaleDateString()}
                      </div>
                      <div className="flex items-center">
                        <Clock className="w-3 h-3 mr-1" />
                        {post.readTime} min
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="flex items-center">
                        <Eye className="w-3 h-3 mr-1" />
                        {post.views}
                      </div>
                      <div className="flex items-center">
                        <Heart className="w-3 h-3 mr-1" />
                        {post.likes}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      {filteredPosts.length === 0 && (
        <div className="text-center py-12">
          <PenTool className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No posts found</h3>
          <p className="text-gray-600 mb-4">
            {searchQuery || selectedCategory ? 'Try adjusting your search or filter' : 'Start by creating your first blog post'}
          </p>
          <Button variant="outline" onClick={() => {
            setSearchQuery('');
            setSelectedCategory('');
          }}>
            Clear Filters
          </Button>
        </div>
      )}
    </div>
  );
}
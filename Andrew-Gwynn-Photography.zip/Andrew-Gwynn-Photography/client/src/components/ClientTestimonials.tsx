import { useState } from "react";
import { motion } from "framer-motion";
import { 
  Star, 
  Quote, 
  Plus, 
  Edit, 
  Trash2, 
  Eye, 
  Calendar,
  MapPin,
  Camera,
  User,
  Heart,
  Award,
  MessageSquare
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

interface Testimonial {
  id: number;
  clientName: string;
  clientTitle?: string;
  clientCompany?: string;
  testimonialText: string;
  rating: number;
  projectType?: string;
  projectDate?: string;
  location?: string;
  featured: boolean;
  imageUrl?: string;
  websiteUrl?: string;
  createdAt: string;
}

interface CaseStudy {
  id: string;
  title: string;
  client: string;
  projectType: string;
  challenge: string;
  solution: string;
  results: string;
  images: string[];
  testimonial?: Testimonial;
  location: string;
  date: string;
  equipment: string[];
  tags: string[];
}

export default function ClientTestimonials() {
  const [activeTab, setActiveTab] = useState<'testimonials' | 'case-studies'>('testimonials');
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingItem, setEditingItem] = useState<Testimonial | CaseStudy | null>(null);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const [testimonialForm, setTestimonialForm] = useState({
    clientName: "",
    clientTitle: "",
    clientCompany: "",
    testimonialText: "",
    rating: 5,
    projectType: "",
    projectDate: "",
    location: "",
    featured: false,
    imageUrl: "",
    websiteUrl: ""
  });

  const [caseStudyForm, setCaseStudyForm] = useState({
    title: "",
    client: "",
    projectType: "",
    challenge: "",
    solution: "",
    results: "",
    location: "",
    date: "",
    equipment: [],
    tags: []
  });

  const queryClient = useQueryClient();

  // Fetch testimonials
  const { data: testimonials = [], isLoading: testimonialsLoading } = useQuery({
    queryKey: ['/api/testimonials'],
    queryFn: () => apiRequest('/api/testimonials')
  });

  // Create testimonial mutation
  const createTestimonialMutation = useMutation({
    mutationFn: (data: any) => apiRequest('/api/testimonials', 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/testimonials'] });
      setShowAddDialog(false);
      resetTestimonialForm();
    }
  });

  // Update testimonial mutation
  const updateTestimonialMutation = useMutation({
    mutationFn: ({ id, data }: { id: number, data: any }) => 
      apiRequest(`/api/testimonials/${id}`, 'PUT', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/testimonials'] });
      setEditingItem(null);
    }
  });

  // Delete testimonial mutation
  const deleteTestimonialMutation = useMutation({
    mutationFn: (id: number) => apiRequest(`/api/testimonials/${id}`, 'DELETE'),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/testimonials'] });
    }
  });

  const resetTestimonialForm = () => {
    setTestimonialForm({
      clientName: "",
      clientTitle: "",
      clientCompany: "",
      testimonialText: "",
      rating: 5,
      projectType: "",
      projectDate: "",
      location: "",
      featured: false,
      imageUrl: "",
      websiteUrl: ""
    });
  };

  const handleCreateTestimonial = (e: React.FormEvent) => {
    e.preventDefault();
    createTestimonialMutation.mutate({
      ...testimonialForm,
      featured: testimonialForm.featured ? 1 : 0
    });
  };

  const handleUpdateTestimonial = (testimonial: Testimonial) => {
    updateTestimonialMutation.mutate({
      id: testimonial.id,
      data: {
        ...testimonial,
        featured: testimonial.featured ? 1 : 0
      }
    });
  };

  const handleDeleteTestimonial = (id: number) => {
    if (confirm('Are you sure you want to delete this testimonial?')) {
      deleteTestimonialMutation.mutate(id);
    }
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-4 h-4 ${
          i < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'
        }`}
      />
    ));
  };

  const featuredTestimonials = testimonials.filter((t: Testimonial) => t.featured);
  const regularTestimonials = testimonials.filter((t: Testimonial) => !t.featured);

  const mockCaseStudies: CaseStudy[] = [
    {
      id: "1",
      title: "Highland Wedding Photography",
      client: "Sarah & James McKenzie",
      projectType: "Wedding Photography",
      challenge: "Capturing an intimate Highland wedding in challenging weather conditions while maintaining the romantic atmosphere.",
      solution: "Used weather-resistant equipment and creative indoor/outdoor shots, focusing on natural lighting and candid moments.",
      results: "Delivered 200+ stunning photos that perfectly captured the couple's special day, resulting in referrals for 3 additional weddings.",
      images: [],
      location: "Scottish Highlands",
      date: "2023-09-15",
      equipment: ["Canon EOS R5", "RF 85mm f/1.2L", "RF 24-70mm f/2.8L"],
      tags: ["wedding", "highlands", "outdoor", "intimate"]
    },
    {
      id: "2",
      title: "Edinburgh Corporate Portraits",
      client: "TechStart Edinburgh",
      projectType: "Corporate Photography",
      challenge: "Creating professional yet approachable headshots for a tech startup's entire team of 25 people.",
      solution: "Set up a mobile studio in their office space, used consistent lighting setup, and guided each person through poses that reflected their personality.",
      results: "Enhanced company's professional image, leading to improved client trust and a 40% increase in website engagement.",
      images: [],
      location: "Edinburgh",
      date: "2023-11-22",
      equipment: ["Canon EOS R6", "RF 85mm f/1.2L", "Professional lighting kit"],
      tags: ["corporate", "headshots", "professional", "team"]
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-4 sm:space-y-0">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Client Success Stories</h2>
          <p className="text-gray-600 mt-1">Showcase testimonials and case studies from your photography work</p>
        </div>
        
        <div className="flex items-center space-x-3">
          <div className="flex rounded-lg border p-1">
            <Button
              variant={activeTab === 'testimonials' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setActiveTab('testimonials')}
            >
              <MessageSquare className="w-4 h-4 mr-2" />
              Testimonials
            </Button>
            <Button
              variant={activeTab === 'case-studies' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setActiveTab('case-studies')}
            >
              <Award className="w-4 h-4 mr-2" />
              Case Studies
            </Button>
          </div>
          
          <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                Add {activeTab === 'testimonials' ? 'Testimonial' : 'Case Study'}
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  Add New {activeTab === 'testimonials' ? 'Testimonial' : 'Case Study'}
                </DialogTitle>
              </DialogHeader>
              
              {activeTab === 'testimonials' ? (
                <form onSubmit={handleCreateTestimonial} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="clientName">Client Name *</Label>
                      <Input
                        id="clientName"
                        value={testimonialForm.clientName}
                        onChange={(e) => setTestimonialForm(prev => ({ ...prev, clientName: e.target.value }))}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="clientTitle">Client Title</Label>
                      <Input
                        id="clientTitle"
                        value={testimonialForm.clientTitle}
                        onChange={(e) => setTestimonialForm(prev => ({ ...prev, clientTitle: e.target.value }))}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="clientCompany">Company</Label>
                      <Input
                        id="clientCompany"
                        value={testimonialForm.clientCompany}
                        onChange={(e) => setTestimonialForm(prev => ({ ...prev, clientCompany: e.target.value }))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="projectType">Project Type</Label>
                      <Select 
                        value={testimonialForm.projectType} 
                        onValueChange={(value) => setTestimonialForm(prev => ({ ...prev, projectType: value }))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select project type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Wedding">Wedding Photography</SelectItem>
                          <SelectItem value="Portrait">Portrait Session</SelectItem>
                          <SelectItem value="Corporate">Corporate Photography</SelectItem>
                          <SelectItem value="Event">Event Photography</SelectItem>
                          <SelectItem value="Landscape">Landscape Photography</SelectItem>
                          <SelectItem value="Commercial">Commercial Work</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="testimonialText">Testimonial *</Label>
                    <Textarea
                      id="testimonialText"
                      value={testimonialForm.testimonialText}
                      onChange={(e) => setTestimonialForm(prev => ({ ...prev, testimonialText: e.target.value }))}
                      placeholder="Share what the client said about your work..."
                      rows={4}
                      required
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="rating">Rating</Label>
                      <Select 
                        value={testimonialForm.rating.toString()} 
                        onValueChange={(value) => setTestimonialForm(prev => ({ ...prev, rating: parseInt(value) }))}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="5">5 Stars</SelectItem>
                          <SelectItem value="4">4 Stars</SelectItem>
                          <SelectItem value="3">3 Stars</SelectItem>
                          <SelectItem value="2">2 Stars</SelectItem>
                          <SelectItem value="1">1 Star</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="projectDate">Project Date</Label>
                      <Input
                        id="projectDate"
                        type="date"
                        value={testimonialForm.projectDate}
                        onChange={(e) => setTestimonialForm(prev => ({ ...prev, projectDate: e.target.value }))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="location">Location</Label>
                      <Input
                        id="location"
                        value={testimonialForm.location}
                        onChange={(e) => setTestimonialForm(prev => ({ ...prev, location: e.target.value }))}
                        placeholder="Edinburgh, Scotland"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="imageUrl">Client Photo URL</Label>
                      <Input
                        id="imageUrl"
                        value={testimonialForm.imageUrl}
                        onChange={(e) => setTestimonialForm(prev => ({ ...prev, imageUrl: e.target.value }))}
                        placeholder="https://..."
                      />
                    </div>
                    <div>
                      <Label htmlFor="websiteUrl">Client Website</Label>
                      <Input
                        id="websiteUrl"
                        value={testimonialForm.websiteUrl}
                        onChange={(e) => setTestimonialForm(prev => ({ ...prev, websiteUrl: e.target.value }))}
                        placeholder="https://..."
                      />
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="featured"
                      checked={testimonialForm.featured}
                      onChange={(e) => setTestimonialForm(prev => ({ ...prev, featured: e.target.checked }))}
                      className="rounded"
                    />
                    <Label htmlFor="featured">Feature this testimonial</Label>
                  </div>

                  <div className="flex justify-end space-x-2 pt-4">
                    <Button type="button" variant="outline" onClick={() => setShowAddDialog(false)}>
                      Cancel
                    </Button>
                    <Button type="submit" disabled={createTestimonialMutation.isPending}>
                      {createTestimonialMutation.isPending ? "Creating..." : "Create Testimonial"}
                    </Button>
                  </div>
                </form>
              ) : (
                <div className="space-y-4">
                  <p className="text-gray-600">Case study creation form would go here...</p>
                  <Button variant="outline" onClick={() => setShowAddDialog(false)}>
                    Close
                  </Button>
                </div>
              )}
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Testimonials Tab */}
      {activeTab === 'testimonials' && (
        <div className="space-y-8">
          {/* Featured Testimonials */}
          {featuredTestimonials.length > 0 && (
            <div>
              <h3 className="text-xl font-semibold mb-4 flex items-center">
                <Star className="w-5 h-5 text-yellow-400 mr-2" />
                Featured Testimonials
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {featuredTestimonials.map((testimonial: Testimonial) => (
                  <motion.div
                    key={testimonial.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <Card className="h-full border-yellow-200 bg-yellow-50">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between mb-4">
                          <div className="flex items-center space-x-1">
                            {renderStars(testimonial.rating)}
                          </div>
                          <div className="flex space-x-1">
                            <Button variant="ghost" size="sm" onClick={() => setEditingItem(testimonial)}>
                              <Edit className="w-3 h-3" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => handleDeleteTestimonial(testimonial.id)}
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                        
                        <Quote className="w-8 h-8 text-yellow-400 mb-3" />
                        <p className="text-gray-700 mb-4 italic">"{testimonial.testimonialText}"</p>
                        
                        <div className="border-t pt-4">
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                              <User className="w-5 h-5 text-gray-500" />
                            </div>
                            <div>
                              <p className="font-semibold text-gray-900">{testimonial.clientName}</p>
                              {testimonial.clientTitle && (
                                <p className="text-sm text-gray-600">
                                  {testimonial.clientTitle}
                                  {testimonial.clientCompany && ` at ${testimonial.clientCompany}`}
                                </p>
                              )}
                            </div>
                          </div>
                          
                          <div className="flex items-center space-x-4 mt-3 text-sm text-gray-500">
                            {testimonial.projectType && (
                              <div className="flex items-center">
                                <Camera className="w-3 h-3 mr-1" />
                                <span>{testimonial.projectType}</span>
                              </div>
                            )}
                            {testimonial.location && (
                              <div className="flex items-center">
                                <MapPin className="w-3 h-3 mr-1" />
                                <span>{testimonial.location}</span>
                              </div>
                            )}
                            {testimonial.projectDate && (
                              <div className="flex items-center">
                                <Calendar className="w-3 h-3 mr-1" />
                                <span>{new Date(testimonial.projectDate).getFullYear()}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </div>
          )}

          {/* Regular Testimonials */}
          <div>
            <h3 className="text-xl font-semibold mb-4">All Testimonials</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {regularTestimonials.map((testimonial: Testimonial) => (
                <motion.div
                  key={testimonial.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <Card className="h-full">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center space-x-1">
                          {renderStars(testimonial.rating)}
                        </div>
                        <div className="flex space-x-1">
                          <Button variant="ghost" size="sm" onClick={() => setEditingItem(testimonial)}>
                            <Edit className="w-3 h-3" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            onClick={() => handleDeleteTestimonial(testimonial.id)}
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                      
                      <p className="text-gray-700 mb-4 line-clamp-4">"{testimonial.testimonialText}"</p>
                      
                      <div className="border-t pt-4">
                        <p className="font-semibold text-gray-900">{testimonial.clientName}</p>
                        {testimonial.clientTitle && (
                          <p className="text-sm text-gray-600">{testimonial.clientTitle}</p>
                        )}
                        {testimonial.projectType && (
                          <Badge variant="secondary" className="mt-2">
                            {testimonial.projectType}
                          </Badge>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>

          {testimonialsLoading && (
            <div className="text-center py-12">
              <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
              <p className="text-gray-600">Loading testimonials...</p>
            </div>
          )}

          {!testimonialsLoading && testimonials.length === 0 && (
            <div className="text-center py-12">
              <MessageSquare className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No testimonials yet</h3>
              <p className="text-gray-600 mb-4">Start building trust by adding client testimonials</p>
              <Button onClick={() => setShowAddDialog(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Add First Testimonial
              </Button>
            </div>
          )}
        </div>
      )}

      {/* Case Studies Tab */}
      {activeTab === 'case-studies' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {mockCaseStudies.map((caseStudy) => (
              <motion.div
                key={caseStudy.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <Card className="h-full">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-xl mb-2">{caseStudy.title}</CardTitle>
                        <p className="text-gray-600">{caseStudy.client}</p>
                      </div>
                      <Badge variant="outline">{caseStudy.projectType}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="font-semibold text-sm text-gray-900 mb-2">Challenge</h4>
                      <p className="text-sm text-gray-700">{caseStudy.challenge}</p>
                    </div>
                    
                    <div>
                      <h4 className="font-semibold text-sm text-gray-900 mb-2">Solution</h4>
                      <p className="text-sm text-gray-700">{caseStudy.solution}</p>
                    </div>
                    
                    <div>
                      <h4 className="font-semibold text-sm text-gray-900 mb-2">Results</h4>
                      <p className="text-sm text-gray-700">{caseStudy.results}</p>
                    </div>
                    
                    <div className="flex items-center space-x-4 text-xs text-gray-500 pt-4 border-t">
                      <div className="flex items-center">
                        <MapPin className="w-3 h-3 mr-1" />
                        <span>{caseStudy.location}</span>
                      </div>
                      <div className="flex items-center">
                        <Calendar className="w-3 h-3 mr-1" />
                        <span>{new Date(caseStudy.date).getFullYear()}</span>
                      </div>
                    </div>
                    
                    <div className="flex flex-wrap gap-1 pt-2">
                      {caseStudy.tags.map((tag) => (
                        <Badge key={tag} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          <div className="text-center py-8 border-2 border-dashed border-gray-300 rounded-lg">
            <Award className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">Case Studies Coming Soon</h3>
            <p className="text-gray-600 mb-4">Detailed project breakdowns and success stories</p>
            <Button variant="outline">
              <Plus className="w-4 h-4 mr-2" />
              Create Case Study
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
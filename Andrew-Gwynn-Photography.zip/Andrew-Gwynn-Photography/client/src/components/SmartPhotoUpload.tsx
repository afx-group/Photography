import { useState, useCallback } from "react";
import { motion } from "framer-motion";
import { Upload, Camera, CheckCircle, AlertCircle, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";

interface ExtractedMetadata {
  fileName: string;
  filePath: string;
  title: string;
  description: string;
  photographer: string;
  deviceUsed: string;
  lens: string;
  dateTaken: string;
  gpsCoordinates: string;
  copyrightStatus: string;
  settings: string;
  width: number;
  height: number;
  tags: string[];
  fileSize: number;
  mimeType: string;
}

interface SmartPhotoUploadProps {
  onMetadataExtracted: (metadata: ExtractedMetadata) => void;
  onClose: () => void;
}

export default function SmartPhotoUpload({ onMetadataExtracted, onClose }: SmartPhotoUploadProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [extractedData, setExtractedData] = useState<ExtractedMetadata | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = Array.from(e.dataTransfer.files);
    const imageFiles = files.filter(file => file.type.startsWith('image/'));
    
    if (imageFiles.length > 0) {
      uploadPhoto(imageFiles[0]);
    }
  }, []);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      uploadPhoto(file);
    }
  };

  const uploadPhoto = async (file: File) => {
    setIsProcessing(true);
    setProgress(0);
    setError(null);
    setExtractedData(null);

    try {
      const formData = new FormData();
      formData.append('photo', file);

      // Simulate progress
      const progressInterval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return prev;
          }
          return prev + 10;
        });
      }, 200);

      const response = await fetch('/api/upload-photo', {
        method: 'POST',
        body: formData
      });

      clearInterval(progressInterval);
      setProgress(100);

      if (!response.ok) {
        throw new Error('Upload failed');
      }

      const metadata = await response.json();
      setExtractedData(metadata);
      
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Upload failed');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleUseData = () => {
    if (extractedData) {
      onMetadataExtracted(extractedData);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Smart Photo Upload</h3>
        <Button variant="ghost" size="sm" onClick={onClose}>
          <X className="w-4 h-4" />
        </Button>
      </div>

      {!extractedData && !isProcessing && (
        <div
          className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
            isDragging 
              ? 'border-blue-500 bg-blue-50' 
              : 'border-gray-300 hover:border-gray-400'
          }`}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-lg font-medium text-gray-900 mb-2">
            Drop your photo here or click to browse
          </p>
          <p className="text-sm text-gray-600 mb-4">
            Supports JPEG, PNG, TIFF, and RAW formats
          </p>
          <input
            type="file"
            accept="image/*"
            onChange={handleFileSelect}
            className="hidden"
            id="photo-upload"
          />
          <label htmlFor="photo-upload">
            <Button className="cursor-pointer">
              <Camera className="w-4 h-4 mr-2" />
              Select Photo
            </Button>
          </label>
        </div>
      )}

      {isProcessing && (
        <Card>
          <CardContent className="p-6">
            <div className="text-center">
              <div className="w-16 h-16 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mx-auto mb-4" />
              <h4 className="text-lg font-medium mb-2">Processing Photo</h4>
              <p className="text-sm text-gray-600 mb-4">
                Extracting EXIF metadata and analyzing image...
              </p>
              <Progress value={progress} className="w-full" />
              <p className="text-xs text-gray-500 mt-2">{progress}% complete</p>
            </div>
          </CardContent>
        </Card>
      )}

      {error && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-6">
            <div className="flex items-center">
              <AlertCircle className="w-5 h-5 text-red-600 mr-2" />
              <p className="text-red-800">{error}</p>
            </div>
          </CardContent>
        </Card>
      )}

      {extractedData && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-4"
        >
          <Card className="border-green-200 bg-green-50">
            <CardHeader className="pb-3">
              <div className="flex items-center">
                <CheckCircle className="w-5 h-5 text-green-600 mr-2" />
                <CardTitle className="text-green-800">Metadata Extracted Successfully</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="font-medium">File:</span> {extractedData.fileName}
                </div>
                <div>
                  <span className="font-medium">Size:</span> {formatFileSize(extractedData.fileSize)}
                </div>
                <div>
                  <span className="font-medium">Dimensions:</span> {extractedData.width} × {extractedData.height}
                </div>
                <div>
                  <span className="font-medium">Date Taken:</span> {extractedData.dateTaken || 'Not available'}
                </div>
                {extractedData.deviceUsed && (
                  <div>
                    <span className="font-medium">Camera:</span> {extractedData.deviceUsed}
                  </div>
                )}
                {extractedData.lens && (
                  <div>
                    <span className="font-medium">Lens:</span> {extractedData.lens}
                  </div>
                )}
                {extractedData.settings && (
                  <div>
                    <span className="font-medium">Settings:</span> {extractedData.settings}
                  </div>
                )}
                {extractedData.gpsCoordinates && (
                  <div>
                    <span className="font-medium">Location:</span> {extractedData.gpsCoordinates}
                  </div>
                )}
                <div>
                  <span className="font-medium">Photographer:</span> {extractedData.photographer}
                </div>
                <div>
                  <span className="font-medium">Copyright:</span> {extractedData.copyrightStatus}
                </div>
              </div>

              {extractedData.description && (
                <div>
                  <span className="font-medium">Description:</span> {extractedData.description}
                </div>
              )}

              {extractedData.tags.length > 0 && (
                <div>
                  <span className="font-medium">Tags:</span>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {extractedData.tags.map((tag, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex justify-end space-x-2 pt-4">
                <Button variant="outline" onClick={() => setExtractedData(null)}>
                  Upload Another
                </Button>
                <Button onClick={handleUseData}>
                  Use This Data
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </div>
  );
}
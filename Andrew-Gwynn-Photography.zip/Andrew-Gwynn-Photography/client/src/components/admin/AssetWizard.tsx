import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  X, 
  ChevronLeft, 
  ChevronRight, 
  Upload, 
  Camera, 
  MapPin, 
  Calendar,
  FileText,
  Tag,
  Check,
  AlertCircle
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";

interface AssetWizardProps {
  open: boolean;
  onClose: () => void;
}

interface AssetFormData {
  // Basic Info
  fileName: string;
  title: string;
  description: string;
  category: string;
  
  // Technical Details
  dateTaken: string;
  photographer: string;
  deviceUsed: string;
  gpsCoordinates: string;
  
  // Rights & Licensing
  copyrightStatus: string;
  licenseType: string;
  
  // Organization
  tags: string[];
  collections: string[];
  featured: boolean;
  
  // File Management
  fileLocation: string;
  notes: string;
}

const steps = [
  {
    id: "basic",
    title: "Basic Information",
    description: "Essential details about your asset",
    icon: FileText,
  },
  {
    id: "technical", 
    title: "Technical Details",
    description: "Camera settings and capture information",
    icon: Camera,
  },
  {
    id: "location",
    title: "Location & Date",
    description: "When and where was this taken",
    icon: MapPin,
  },
  {
    id: "rights",
    title: "Rights & Licensing", 
    description: "Copyright and usage permissions",
    icon: AlertCircle,
  },
  {
    id: "organization",
    title: "Organization",
    description: "Tags, collections, and categorization",
    icon: Tag,
  },
];

const categories = [
  "landscape",
  "portrait", 
  "event",
  "artistic",
  "architectural",
  "wildlife",
  "street",
  "abstract",
];

const copyrightStatuses = [
  "Not Started",
  "In Progress", 
  "Completed",
  "Published",
];

const licenseTypes = [
  "All Rights Reserved",
  "Creative Commons Attribution 4.0",
  "Creative Commons Attribution-ShareAlike 4.0", 
  "Creative Commons Attribution-NonCommercial 4.0",
  "Public Domain",
  "Custom License",
];

export default function AssetWizard({ open, onClose }: AssetWizardProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState<AssetFormData>({
    fileName: "",
    title: "",
    description: "",
    category: "",
    dateTaken: "",
    photographer: "Andrew Gwynn",
    deviceUsed: "",
    gpsCoordinates: "",
    copyrightStatus: "Not Started",
    licenseType: "",
    tags: [],
    collections: [],
    featured: false,
    fileLocation: "",
    notes: "",
  });

  const [newTag, setNewTag] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createAssetMutation = useMutation({
    mutationFn: async (data: AssetFormData) => {
      // Generate AFX ID
      const date = new Date(data.dateTaken || Date.now());
      const dateStr = date.toISOString().split('T')[0].replace(/-/g, '_');
      const fileNum = String(Math.floor(Math.random() * 99999) + 1).padStart(5, '0');
      const afxId = `AFX_Studios_${dateStr}_${fileNum}`;

      const assetData = {
        afxId,
        dateTaken: data.dateTaken ? new Date(data.dateTaken).toISOString() : null,
        fileNumber: fileNum,
        fileName: data.fileName,
        title: data.title,
        description: data.description,
        gpsCoordinates: data.gpsCoordinates,
        photographer: data.photographer,
        deviceUsed: data.deviceUsed,
        copyrightStatus: data.copyrightStatus,
        licenseType: data.licenseType,
        fileLocation: data.fileLocation,
        notes: data.notes,
        category: data.category,
        featured: data.featured ? 1 : 0,
        displayOrder: 0,
      };

      const response = await fetch("/api/assets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(assetData),
      });

      if (!response.ok) {
        throw new Error("Failed to create asset");
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Asset Created!",
        description: "Your photography asset has been successfully added to the database.",
      });
      queryClient.invalidateQueries({ queryKey: ["assets"] });
      handleClose();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create asset. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleClose = () => {
    setCurrentStep(0);
    setFormData({
      fileName: "",
      title: "",
      description: "",
      category: "",
      dateTaken: "",
      photographer: "Andrew Gwynn",
      deviceUsed: "",
      gpsCoordinates: "",
      copyrightStatus: "Not Started",
      licenseType: "",
      tags: [],
      collections: [],
      featured: false,
      fileLocation: "",
      notes: "",
    });
    onClose();
  };

  const updateFormData = (field: keyof AssetFormData, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const addTag = () => {
    if (newTag.trim() && !formData.tags.includes(newTag.trim())) {
      updateFormData("tags", [...formData.tags, newTag.trim()]);
      setNewTag("");
    }
  };

  const removeTag = (tagToRemove: string) => {
    updateFormData("tags", formData.tags.filter(tag => tag !== tagToRemove));
  };

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = () => {
    createAssetMutation.mutate(formData);
  };

  const progress = ((currentStep + 1) / steps.length) * 100;

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>Add New Asset</span>
            <Button variant="ghost" size="sm" onClick={handleClose}>
              <X className="w-4 h-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>

        {/* Progress Bar */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm text-gray-500">
            <span>Step {currentStep + 1} of {steps.length}</span>
            <span>{Math.round(progress)}% Complete</span>
          </div>
          <Progress value={progress} className="w-full" />
        </div>

        {/* Step Indicators */}
        <div className="flex justify-between items-center py-4">
          {steps.map((step, index) => (
            <div
              key={step.id}
              className={`flex items-center space-x-2 ${
                index <= currentStep ? "text-blue-600" : "text-gray-400"
              }`}
            >
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center border-2 ${
                  index < currentStep
                    ? "bg-blue-600 border-blue-600 text-white"
                    : index === currentStep
                    ? "border-blue-600 text-blue-600"
                    : "border-gray-300 text-gray-400"
                }`}
              >
                {index < currentStep ? (
                  <Check className="w-4 h-4" />
                ) : (
                  <step.icon className="w-4 h-4" />
                )}
              </div>
              <div className="hidden md:block">
                <p className="text-sm font-medium">{step.title}</p>
                <p className="text-xs">{step.description}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Form Content */}
        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
            className="space-y-6 py-6"
          >
            {/* Step 1: Basic Information */}
            {currentStep === 0 && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Basic Information</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="fileName">File Name *</Label>
                    <Input
                      id="fileName"
                      value={formData.fileName}
                      onChange={(e) => updateFormData("fileName", e.target.value)}
                      placeholder="IMG_2024_001.jpg"
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="category">Category *</Label>
                    <Select
                      value={formData.category}
                      onValueChange={(value) => updateFormData("category", value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((category) => (
                          <SelectItem key={category} value={category}>
                            {category.charAt(0).toUpperCase() + category.slice(1)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="title">Title</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => updateFormData("title", e.target.value)}
                    placeholder="Sunset over the mountains"
                  />
                </div>

                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => updateFormData("description", e.target.value)}
                    placeholder="Detailed description of the image..."
                    rows={4}
                  />
                </div>
              </div>
            )}

            {/* Step 2: Technical Details */}
            {currentStep === 1 && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Technical Details</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="photographer">Photographer *</Label>
                    <Input
                      id="photographer"
                      value={formData.photographer}
                      onChange={(e) => updateFormData("photographer", e.target.value)}
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="deviceUsed">Device Used</Label>
                    <Input
                      id="deviceUsed"
                      value={formData.deviceUsed}
                      onChange={(e) => updateFormData("deviceUsed", e.target.value)}
                      placeholder="Nikon D5200"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="fileLocation">File Location</Label>
                  <Input
                    id="fileLocation"
                    value={formData.fileLocation}
                    onChange={(e) => updateFormData("fileLocation", e.target.value)}
                    placeholder="/path/to/photo/file.jpg"
                  />
                </div>
              </div>
            )}

            {/* Step 3: Location & Date */}
            {currentStep === 2 && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Location & Date</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="dateTaken">Date Taken</Label>
                    <Input
                      id="dateTaken"
                      type="datetime-local"
                      value={formData.dateTaken}
                      onChange={(e) => updateFormData("dateTaken", e.target.value)}
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="gpsCoordinates">GPS Coordinates</Label>
                    <Input
                      id="gpsCoordinates"
                      value={formData.gpsCoordinates}
                      onChange={(e) => updateFormData("gpsCoordinates", e.target.value)}
                      placeholder="32.709, -117.172"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Step 4: Rights & Licensing */}
            {currentStep === 3 && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Rights & Licensing</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="copyrightStatus">Copyright Status</Label>
                    <Select
                      value={formData.copyrightStatus}
                      onValueChange={(value) => updateFormData("copyrightStatus", value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {copyrightStatuses.map((status) => (
                          <SelectItem key={status} value={status}>
                            {status}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="licenseType">License Type</Label>
                    <Select
                      value={formData.licenseType}
                      onValueChange={(value) => updateFormData("licenseType", value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select license" />
                      </SelectTrigger>
                      <SelectContent>
                        {licenseTypes.map((license) => (
                          <SelectItem key={license} value={license}>
                            {license}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            )}

            {/* Step 5: Organization */}
            {currentStep === 4 && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Organization</h3>
                
                <div>
                  <Label htmlFor="tags">Tags</Label>
                  <div className="flex space-x-2 mb-2">
                    <Input
                      value={newTag}
                      onChange={(e) => setNewTag(e.target.value)}
                      placeholder="Add a tag..."
                      onKeyPress={(e) => e.key === 'Enter' && addTag()}
                    />
                    <Button type="button" onClick={addTag} variant="outline">
                      Add
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {formData.tags.map((tag) => (
                      <Badge
                        key={tag}
                        variant="secondary"
                        className="cursor-pointer"
                        onClick={() => removeTag(tag)}
                      >
                        {tag} <X className="w-3 h-3 ml-1" />
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <Label htmlFor="notes">Notes</Label>
                  <Textarea
                    id="notes"
                    value={formData.notes}
                    onChange={(e) => updateFormData("notes", e.target.value)}
                    placeholder="Additional notes or metadata..."
                    rows={3}
                  />
                </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>

        {/* Navigation */}
        <div className="flex justify-between pt-6 border-t">
          <Button
            variant="outline"
            onClick={prevStep}
            disabled={currentStep === 0}
          >
            <ChevronLeft className="w-4 h-4 mr-2" />
            Previous
          </Button>
          
          <div className="flex space-x-2">
            <Button variant="outline" onClick={handleClose}>
              Cancel
            </Button>
            
            {currentStep === steps.length - 1 ? (
              <Button
                onClick={handleSubmit}
                disabled={createAssetMutation.isPending || !formData.fileName || !formData.category}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {createAssetMutation.isPending ? "Creating..." : "Create Asset"}
              </Button>
            ) : (
              <Button
                onClick={nextStep}
                disabled={
                  (currentStep === 0 && (!formData.fileName || !formData.category))
                }
                className="bg-blue-600 hover:bg-blue-700"
              >
                Next
                <ChevronRight className="w-4 h-4 ml-2" />
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
import { useState } from "react";
import PortfolioGallery from "@/components/PortfolioGallery";

export default function SimpleDatabase() {
  const [activeTab, setActiveTab] = useState("assets");

  const tabs = [
    { id: "assets", label: "Assets" },
    { id: "portfolio", label: "Portfolio" },
    { id: "drive", label: "Google Drive" },
    { id: "blog", label: "Blog" },
    { id: "ecommerce", label: "Shop" },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <h1 className="text-2xl font-semibold text-gray-900">
            Photography Database Management
          </h1>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="bg-white rounded-lg shadow">
          <div className="border-b border-gray-200">
            <nav className="-mb-px flex space-x-8">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </nav>
          </div>

          <div className="p-6">
            {activeTab === "assets" && (
              <div>
                <h2 className="text-lg font-medium mb-4">Photography Assets</h2>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                  <p className="text-gray-600">Asset management interface</p>
                  <p className="text-sm text-gray-500 mt-2">Connect to database to view assets</p>
                </div>
              </div>
            )}

            {activeTab === "portfolio" && (
              <div>
                <h2 className="text-lg font-medium mb-4">Interactive Portfolio Gallery</h2>
                <PortfolioGallery />
              </div>
            )}

            {activeTab === "drive" && (
              <div>
                <h2 className="text-lg font-medium mb-4">Google Drive Integration</h2>
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h3 className="font-medium mb-2">Configuration Required</h3>
                  <p className="text-sm text-gray-600 mb-3">
                    To enable Google Drive integration, add these environment variables:
                  </p>
                  <ul className="text-sm text-gray-700 space-y-1">
                    <li>• GOOGLE_DRIVE_SERVICE_ACCOUNT_KEY (JSON credentials)</li>
                    <li>• GOOGLE_DRIVE_PHOTO_FOLDERS (comma-separated folder IDs)</li>
                  </ul>
                </div>
              </div>
            )}

            {activeTab === "blog" && (
              <div>
                <h2 className="text-lg font-medium mb-4">Photography Blog</h2>
                <div className="text-center py-8">
                  <p className="text-gray-600">Blog management system</p>
                  <button className="mt-4 bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">
                    Create Post
                  </button>
                </div>
              </div>
            )}

            {activeTab === "ecommerce" && (
              <div>
                <h2 className="text-lg font-medium mb-4">Print Sales</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div className="bg-gray-50 p-4 rounded-lg text-center">
                    <div className="text-2xl font-bold text-gray-900">0</div>
                    <div className="text-sm text-gray-600">Print Orders</div>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg text-center">
                    <div className="text-2xl font-bold text-gray-900">£0</div>
                    <div className="text-sm text-gray-600">Revenue</div>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg text-center">
                    <div className="text-2xl font-bold text-gray-900">0</div>
                    <div className="text-sm text-gray-600">Products</div>
                  </div>
                </div>
                <div className="text-center py-4">
                  <button className="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700">
                    Configure Shop
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
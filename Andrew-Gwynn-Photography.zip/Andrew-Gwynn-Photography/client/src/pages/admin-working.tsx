import { useState } from "react";
import { motion } from "framer-motion";
import { 
  Camera, 
  Image, 
  Book, 
  Users, 
  FolderOpen, 
  Settings, 
  Plus,
  Search,
  Upload,
  Cloud,
  RefreshCw,
  PenTool,
  ShoppingCart
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import AssetSpreadsheet from "@/components/AssetSpreadsheet";
import BlogSection from "@/components/BlogSection";
import AdvancedPortfolioFiltering from "@/components/AdvancedPortfolioFiltering";
import ClientTestimonials from "@/components/ClientTestimonials";

const adminTabs = [
  { id: "assets", label: "Assets", icon: Image, description: "Manage photos and media" },
  { id: "portfolio", label: "Portfolio", icon: Camera, description: "Advanced filtering & search" },
  { id: "drive", label: "Google Drive", icon: Cloud, description: "Import from Drive" },
  { id: "blog", label: "Blog", icon: PenTool, description: "Photography insights & tutorials" },
  { id: "testimonials", label: "Testimonials", icon: Users, description: "Client testimonials & case studies" },
  { id: "ecommerce", label: "Shop", icon: ShoppingCart, description: "Print sales & products" },
  { id: "publications", label: "Publications", icon: Book, description: "Photo books and prints" },
  { id: "collections", label: "Collections", icon: FolderOpen, description: "Organize content" },
  { id: "settings", label: "Settings", icon: Settings, description: "System configuration" },
];

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState("assets");
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch assets
  const { data: assets = [], isLoading: assetsLoading } = useQuery({
    queryKey: ['/api/assets'],
    queryFn: async () => {
      const response = await apiRequest('/api/assets', 'GET');
      return Array.isArray(response) ? response : [];
    }
  });

  // Fetch publications
  const { data: publications = [] } = useQuery({
    queryKey: ['/api/publications'],
    queryFn: async () => {
      const response = await apiRequest('/api/publications', 'GET');
      return Array.isArray(response) ? response : [];
    }
  });

  // Fetch clients
  const { data: clients = [] } = useQuery({
    queryKey: ['/api/clients'],
    queryFn: async () => {
      const response = await apiRequest('/api/clients', 'GET');
      return Array.isArray(response) ? response : [];
    }
  });

  // Fetch collections
  const { data: collections = [] } = useQuery({
    queryKey: ['/api/collections'],
    queryFn: async () => {
      const response = await apiRequest('/api/collections', 'GET');
      return Array.isArray(response) ? response : [];
    }
  });

  // Check Google Drive status
  const { data: driveStatus } = useQuery({
    queryKey: ['/api/google-drive/status'],
    queryFn: () => apiRequest('/api/google-drive/status')
  });

  const stats = [
    { label: "Total Assets", value: assets.length.toString(), change: "+12", color: "blue" },
    { label: "Publications", value: publications.length.toString(), change: "+1", color: "green" },
    { label: "Active Clients", value: clients.length.toString(), change: "0", color: "yellow" },
    { label: "Collections", value: collections.length.toString(), change: "+3", color: "purple" },
  ];

  if (assetsLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-4 text-blue-600" />
          <p className="text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <h1 className="text-2xl font-semibold text-gray-900">
                Photography Database Management
              </h1>
              <Badge variant="secondary" className="hidden sm:inline-flex">
                AFX Studios
              </Badge>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="relative hidden md:block">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search assets..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 w-64"
                />
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Stats */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">
                        {stat.label}
                      </p>
                      <p className="text-2xl font-bold text-gray-900">
                        {stat.value}
                      </p>
                    </div>
                    <div className="flex items-center space-x-1">
                      <span className={`text-sm font-medium text-${stat.color}-600`}>
                        {stat.change}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Main Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 lg:grid-cols-9">
            {adminTabs.map((tab) => (
              <TabsTrigger key={tab.id} value={tab.id} className="flex items-center space-x-2">
                <tab.icon className="w-4 h-4" />
                <span className="hidden sm:inline">{tab.label}</span>
              </TabsTrigger>
            ))}
          </TabsList>

          <TabsContent value="assets" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Photography Assets</CardTitle>
              </CardHeader>
              <CardContent>
                <AssetSpreadsheet />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="portfolio" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Advanced Portfolio Management</CardTitle>
              </CardHeader>
              <CardContent>
                <AdvancedPortfolioFiltering 
                  onFilterChange={(filters) => {
                    console.log('Portfolio filters applied:', filters);
                  }}
                  onSelectionChange={(selectedAssets) => {
                    console.log('Assets selected:', selectedAssets.length);
                  }}
                />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="drive" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Google Drive Integration</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                  <Cloud className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Direct Google Drive Access</h3>
                  <p className="text-gray-600 mb-4">
                    Configure Google Drive service account credentials in project settings for automatic photo import
                  </p>
                  <div className="space-y-3">
                    <p className="text-sm text-gray-500">
                      Status: {driveStatus?.connected ? 'Connected' : 'Not Configured'}
                    </p>
                    {!driveStatus?.connected && (
                      <div className="text-sm text-gray-600 bg-blue-50 p-4 rounded-lg">
                        <p className="font-medium mb-2">To configure Google Drive:</p>
                        <ol className="list-decimal list-inside space-y-1">
                          <li>Add GOOGLE_DRIVE_SERVICE_ACCOUNT_KEY to environment variables</li>
                          <li>Include your photography folder IDs in GOOGLE_DRIVE_PHOTO_FOLDERS</li>
                          <li>System will automatically sync photos with metadata</li>
                        </ol>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="blog" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Photography Journal</CardTitle>
              </CardHeader>
              <CardContent>
                <BlogSection />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="testimonials" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Client Testimonials & Case Studies</CardTitle>
              </CardHeader>
              <CardContent>
                <ClientTestimonials />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="ecommerce" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>E-commerce & Print Sales</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <Card className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6 text-center">
                      <ShoppingCart className="w-12 h-12 text-blue-500 mx-auto mb-4" />
                      <h3 className="font-semibold mb-2">Print Orders</h3>
                      <p className="text-2xl font-bold text-gray-900">0</p>
                      <p className="text-sm text-gray-600">Active orders</p>
                    </CardContent>
                  </Card>
                  
                  <Card className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6 text-center">
                      <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <span className="text-green-600 font-bold">£</span>
                      </div>
                      <h3 className="font-semibold mb-2">Revenue</h3>
                      <p className="text-2xl font-bold text-gray-900">£0</p>
                      <p className="text-sm text-gray-600">This month</p>
                    </CardContent>
                  </Card>
                  
                  <Card className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6 text-center">
                      <Image className="w-12 h-12 text-purple-500 mx-auto mb-4" />
                      <h3 className="font-semibold mb-2">Products</h3>
                      <p className="text-2xl font-bold text-gray-900">0</p>
                      <p className="text-sm text-gray-600">Available prints</p>
                    </CardContent>
                  </Card>
                </div>

                <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                  <ShoppingCart className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Set Up Print Sales</h3>
                  <p className="text-gray-600 mb-4">
                    Configure your photography prints for direct sales through your website
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600">
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h4 className="font-medium mb-2">Print Products</h4>
                      <ul className="list-disc list-inside space-y-1">
                        <li>Fine Art Prints</li>
                        <li>Canvas Prints</li>
                        <li>Metal Prints</li>
                        <li>Photo Books</li>
                      </ul>
                    </div>
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <h4 className="font-medium mb-2">Features</h4>
                      <ul className="list-disc list-inside space-y-1">
                        <li>Automated ordering</li>
                        <li>Size & format options</li>
                        <li>Secure payments</li>
                        <li>Shipping integration</li>
                      </ul>
                    </div>
                  </div>
                  <Button className="mt-4">
                    <Plus className="w-4 h-4 mr-2" />
                    Configure Shop
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="publications" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Publications</CardTitle>
                  <Button size="sm">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Publication
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {publications.length === 0 ? (
                    <div className="text-center py-8">
                      <Book className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600">No publications found. Create your first photo book.</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {publications.map((publication: any) => (
                        <Card key={publication.id} className="hover:shadow-md transition-shadow cursor-pointer">
                          <CardContent className="p-4">
                            <div className="aspect-[3/4] bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg mb-3 flex items-center justify-center">
                              <Book className="w-8 h-8 text-gray-400" />
                            </div>
                            <h4 className="font-semibold mb-2">{publication.title}</h4>
                            <p className="text-sm text-gray-600 mb-3">{publication.description}</p>
                            <div className="flex items-center justify-between">
                              <Badge variant="outline">{publication.type}</Badge>
                              <span className="text-sm text-gray-500">#{publication.number}</span>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="clients" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Client Management</CardTitle>
                  <Button size="sm">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Client
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {clients.length === 0 ? (
                    <div className="text-center py-8">
                      <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600">No clients found. Start by adding your first client.</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {clients.map((client: any) => (
                        <Card key={client.id} className="p-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <h4 className="font-semibold">{client.name}</h4>
                              <p className="text-sm text-gray-600">{client.email}</p>
                            </div>
                            <Badge variant="outline">{client.status}</Badge>
                          </div>
                        </Card>
                      ))}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="collections" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Collections</CardTitle>
                  <Button size="sm">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Collection
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {collections.length === 0 ? (
                    <div className="text-center py-8">
                      <FolderOpen className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600">No collections found. Create collections to organize your work.</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {collections.map((collection: any) => (
                        <Card key={collection.id} className="hover:shadow-md transition-shadow cursor-pointer">
                          <CardContent className="p-4">
                            <div className="aspect-video bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg mb-3 flex items-center justify-center">
                              <FolderOpen className="w-8 h-8 text-gray-400" />
                            </div>
                            <h4 className="font-semibold mb-2">{collection.name}</h4>
                            <p className="text-sm text-gray-600">{collection.description}</p>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>System Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium">Total Assets:</span>
                    <p className="text-gray-600">{assets.length} files</p>
                  </div>
                  <div>
                    <span className="font-medium">Publications:</span>
                    <p className="text-gray-600">{publications.length} books</p>
                  </div>
                  <div>
                    <span className="font-medium">Collections:</span>
                    <p className="text-gray-600">{collections.length} collections</p>
                  </div>
                  <div>
                    <span className="font-medium">Clients:</span>
                    <p className="text-gray-600">{clients.length} active</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
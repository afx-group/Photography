import { useState } from "react";
import { motion } from "framer-motion";
import { 
  Camera, 
  Image, 
  Book, 
  Users, 
  FolderOpen, 
  Settings, 
  Plus,
  Search,
  Filter,
  MoreVertical,
  Eye,
  Edit,
  Trash2,
  Download,
  Upload,
  FileText,
  Calendar,
  MapPin,
  Tag,
  RefreshCw
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import AssetSpreadsheet from "@/components/AssetSpreadsheet";
import GoogleDriveIntegration from "@/components/GoogleDriveIntegration";

interface Asset {
  id: number;
  afxId: string;
  fileName: string;
  title?: string;
  description?: string;
  category?: string;
  photographer: string;
  deviceUsed?: string;
  dateTaken?: string;
  gpsCoordinates?: string;
  copyrightStatus: string;
  licenseType?: string;
  featured: number;
  createdAt: string;
}

const adminTabs = [
  { id: "assets", label: "Assets", icon: Image, description: "Manage photos and media" },
  { id: "drive", label: "Google Drive", icon: Upload, description: "Import from Drive" },
  { id: "publications", label: "Publications", icon: Book, description: "Photo books and prints" },
  { id: "clients", label: "Clients", icon: Users, description: "Client relationships" },
  { id: "collections", label: "Collections", icon: FolderOpen, description: "Organize content" },
  { id: "settings", label: "Settings", icon: Settings, description: "System configuration" },
];

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState("assets");
  const [searchQuery, setSearchQuery] = useState("");
  const [showAssetDialog, setShowAssetDialog] = useState(false);
  const [assetForm, setAssetForm] = useState({
    fileName: "",
    title: "",
    description: "",
    category: "",
    photographer: "Andrew Gwynn",
    deviceUsed: "",
    dateTaken: "",
    gpsCoordinates: "",
    copyrightStatus: "© Andrew Gwynn Photography",
    licenseType: "",
    featured: false
  });

  const queryClient = useQueryClient();

  // Fetch Google Drive connection status
  const { data: connectionStatus } = useQuery({
    queryKey: ['/api/google-drive/status'],
    queryFn: () => apiRequest('/api/google-drive/status'),
    enabled: true
  });

  // Fetch assets
  const { data: assets = [], isLoading: assetsLoading } = useQuery({
    queryKey: ['/api/assets'],
    queryFn: async () => {
      const response = await apiRequest('/api/assets', 'GET');
      return Array.isArray(response) ? response : [];
    }
  });

  // Fetch publications
  const { data: publications = [] } = useQuery({
    queryKey: ['/api/publications'],
    queryFn: async () => {
      const response = await apiRequest('/api/publications', 'GET');
      return Array.isArray(response) ? response : [];
    }
  });

  // Fetch clients
  const { data: clients = [] } = useQuery({
    queryKey: ['/api/clients'],
    queryFn: async () => {
      const response = await apiRequest('/api/clients', 'GET');
      return Array.isArray(response) ? response : [];
    }
  });

  // Fetch collections
  const { data: collections = [] } = useQuery({
    queryKey: ['/api/collections'],
    queryFn: async () => {
      const response = await apiRequest('/api/collections', 'GET');
      return Array.isArray(response) ? response : [];
    }
  });

  // Create asset mutation
  const createAssetMutation = useMutation({
    mutationFn: (data: any) => apiRequest('/api/assets', 'POST', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/assets'] });
      setShowAssetDialog(false);
      setAssetForm({
        fileName: "",
        title: "",
        description: "",
        category: "",
        photographer: "Andrew Gwynn",
        deviceUsed: "",
        dateTaken: "",
        gpsCoordinates: "",
        copyrightStatus: "© Andrew Gwynn Photography",
        licenseType: "",
        featured: false
      });
    }
  });

  const handleCreateAsset = (e: React.FormEvent) => {
    e.preventDefault();
    createAssetMutation.mutate({
      ...assetForm,
      afxId: `AFX-${Date.now()}`,
      featured: assetForm.featured ? 1 : 0
    });
  };

  const stats = [
    { label: "Total Assets", value: assets.length.toString(), change: "+12", color: "blue" },
    { label: "Publications", value: publications.length.toString(), change: "+1", color: "green" },
    { label: "Active Clients", value: clients.length.toString(), change: "0", color: "yellow" },
    { label: "Collections", value: collections.length.toString(), change: "+3", color: "purple" },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <h1 className="text-2xl font-semibold text-gray-900">
                Asset Management Dashboard
              </h1>
              <Badge variant="secondary" className="hidden sm:inline-flex">
                AFX Studios
              </Badge>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="relative hidden md:block">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search assets..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 w-64"
                />
              </div>
              
              <Dialog open={showAssetDialog} onOpenChange={setShowAssetDialog}>
                <DialogTrigger asChild>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Asset
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Add New Photography Asset</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleCreateAsset} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="fileName">File Name *</Label>
                        <Input
                          id="fileName"
                          value={assetForm.fileName}
                          onChange={(e) => setAssetForm(prev => ({ ...prev, fileName: e.target.value }))}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="title">Title</Label>
                        <Input
                          id="title"
                          value={assetForm.title}
                          onChange={(e) => setAssetForm(prev => ({ ...prev, title: e.target.value }))}
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="description">Description</Label>
                      <Textarea
                        id="description"
                        value={assetForm.description}
                        onChange={(e) => setAssetForm(prev => ({ ...prev, description: e.target.value }))}
                        rows={3}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="category">Category</Label>
                        <Select value={assetForm.category} onValueChange={(value) => setAssetForm(prev => ({ ...prev, category: value }))}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select category" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Landscape">Landscape</SelectItem>
                            <SelectItem value="Portrait">Portrait</SelectItem>
                            <SelectItem value="Wedding">Wedding</SelectItem>
                            <SelectItem value="Event">Event</SelectItem>
                            <SelectItem value="Commercial">Commercial</SelectItem>
                            <SelectItem value="Fine Art">Fine Art</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="photographer">Photographer</Label>
                        <Input
                          id="photographer"
                          value={assetForm.photographer}
                          onChange={(e) => setAssetForm(prev => ({ ...prev, photographer: e.target.value }))}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="deviceUsed">Camera/Device</Label>
                        <Input
                          id="deviceUsed"
                          value={assetForm.deviceUsed}
                          onChange={(e) => setAssetForm(prev => ({ ...prev, deviceUsed: e.target.value }))}
                          placeholder="e.g., Canon EOS R5"
                        />
                      </div>
                      <div>
                        <Label htmlFor="dateTaken">Date Taken</Label>
                        <Input
                          id="dateTaken"
                          type="date"
                          value={assetForm.dateTaken}
                          onChange={(e) => setAssetForm(prev => ({ ...prev, dateTaken: e.target.value }))}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="gpsCoordinates">GPS Coordinates</Label>
                        <Input
                          id="gpsCoordinates"
                          value={assetForm.gpsCoordinates}
                          onChange={(e) => setAssetForm(prev => ({ ...prev, gpsCoordinates: e.target.value }))}
                          placeholder="e.g., 55.9533,-3.1883"
                        />
                      </div>
                      <div>
                        <Label htmlFor="licenseType">License Type</Label>
                        <Select value={assetForm.licenseType} onValueChange={(value) => setAssetForm(prev => ({ ...prev, licenseType: value }))}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select license" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="All Rights Reserved">All Rights Reserved</SelectItem>
                            <SelectItem value="Limited License">Limited License</SelectItem>
                            <SelectItem value="Commercial License">Commercial License</SelectItem>
                            <SelectItem value="Editorial License">Editorial License</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="copyrightStatus">Copyright Status</Label>
                      <Input
                        id="copyrightStatus"
                        value={assetForm.copyrightStatus}
                        onChange={(e) => setAssetForm(prev => ({ ...prev, copyrightStatus: e.target.value }))}
                      />
                    </div>

                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="featured"
                        checked={assetForm.featured}
                        onChange={(e) => setAssetForm(prev => ({ ...prev, featured: e.target.checked }))}
                        className="rounded"
                      />
                      <Label htmlFor="featured">Featured Asset</Label>
                    </div>

                    <div className="flex justify-end space-x-2 pt-4">
                      <Button type="button" variant="outline" onClick={() => setShowAssetDialog(false)}>
                        Cancel
                      </Button>
                      <Button type="submit" disabled={createAssetMutation.isPending}>
                        {createAssetMutation.isPending ? "Creating..." : "Create Asset"}
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>
      </header>

      {/* Stats */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">
                        {stat.label}
                      </p>
                      <p className="text-2xl font-bold text-gray-900">
                        {stat.value}
                      </p>
                    </div>
                    <div className="flex items-center space-x-1">
                      <span className={`text-sm font-medium text-${stat.color}-600`}>
                        {stat.change}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Main Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            {adminTabs.map((tab) => (
              <TabsTrigger key={tab.id} value={tab.id} className="flex items-center space-x-2">
                <tab.icon className="w-4 h-4" />
                <span className="hidden sm:inline">{tab.label}</span>
              </TabsTrigger>
            ))}
          </TabsList>

          <TabsContent value="assets" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Photography Assets</CardTitle>
              </CardHeader>
              <CardContent>
                <AssetSpreadsheet />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="drive" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Google Drive Integration</CardTitle>
              </CardHeader>
              <CardContent>
                <GoogleDriveIntegration 
                  onImportToDatabase={(file) => {
                    // Refresh assets when file is imported
                    queryClient.invalidateQueries({ queryKey: ['/api/assets'] });
                  }}
                />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="publications" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Publications</CardTitle>
                  <Button size="sm">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Publication
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {publications.length === 0 ? (
                    <div className="text-center py-8">
                      <Book className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600">No publications found. Start by adding your first publication.</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {publications.map((publication: any) => (
                        <Card key={publication.id} className="hover:shadow-md transition-shadow">
                          <CardContent className="p-4">
                            <div className="aspect-[3/4] bg-gray-100 rounded-lg mb-3 flex items-center justify-center">
                              <Book className="w-8 h-8 text-gray-400" />
                            </div>
                            <h4 className="font-semibold mb-2">{publication.title}</h4>
                            <div className="space-y-1 text-sm text-gray-600">
                              <p><span className="font-medium">Type:</span> {publication.type}</p>
                              <p><span className="font-medium">ISBN:</span> {publication.isbn}</p>
                              <p><span className="font-medium">Published:</span> {new Date(publication.publication_date).toLocaleDateString()}</p>
                              <p><span className="font-medium">Status:</span> 
                                <Badge variant={publication.status === 'Published' ? 'default' : 'secondary'} className="ml-2">
                                  {publication.status}
                                </Badge>
                              </p>
                            </div>
                            <div className="flex justify-between mt-4">
                              <Button variant="ghost" size="sm">
                                <Eye className="w-4 h-4" />
                              </Button>
                              <Button variant="ghost" size="sm">
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button variant="ghost" size="sm">
                                <Download className="w-4 h-4" />
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="clients" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Client Management</CardTitle>
                  <Button size="sm">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Client
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {clients.length === 0 ? (
                    <div className="text-center py-8">
                      <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600">No clients found. Start by adding your first client.</p>
                      <Button className="mt-4" size="sm">
                        <Plus className="w-4 h-4 mr-2" />
                        Add Your First Client
                      </Button>
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Client
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Contact
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Projects
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Status
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Actions
                            </th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          {clients.map((client: any) => (
                            <tr key={client.id} className="hover:bg-gray-50">
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="flex items-center">
                                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                                    <span className="text-blue-600 font-medium text-sm">
                                      {client.name?.charAt(0) || 'C'}
                                    </span>
                                  </div>
                                  <div className="ml-4">
                                    <div className="text-sm font-medium text-gray-900">{client.name}</div>
                                    <div className="text-sm text-gray-500">{client.company}</div>
                                  </div>
                                </div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm text-gray-900">{client.email}</div>
                                <div className="text-sm text-gray-500">{client.phone}</div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {client.projects || 0} projects
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <Badge variant={client.status === 'Active' ? 'default' : 'secondary'}>
                                  {client.status || 'Active'}
                                </Badge>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <div className="flex space-x-2">
                                  <Button variant="ghost" size="sm">
                                    <Eye className="w-4 h-4" />
                                  </Button>
                                  <Button variant="ghost" size="sm">
                                    <Edit className="w-4 h-4" />
                                  </Button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="collections" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle>Collections</CardTitle>
                  <Button size="sm">
                    <Plus className="w-4 h-4 mr-2" />
                    Create Collection
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {collections.length === 0 ? (
                    <div className="text-center py-8">
                      <FolderOpen className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600">No collections found. Create collections to organize your photography work.</p>
                      <Button className="mt-4" size="sm">
                        <Plus className="w-4 h-4 mr-2" />
                        Create Your First Collection
                      </Button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {collections.map((collection: any) => (
                        <Card key={collection.id} className="hover:shadow-md transition-shadow cursor-pointer">
                          <CardContent className="p-4">
                            <div className="aspect-video bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg mb-3 flex items-center justify-center">
                              <FolderOpen className="w-8 h-8 text-gray-400" />
                            </div>
                            <h4 className="font-semibold mb-2">{collection.name}</h4>
                            <p className="text-sm text-gray-600 mb-3 line-clamp-2">{collection.description}</p>
                            <div className="flex items-center justify-between">
                              <div className="text-sm text-gray-500">
                                {collection.asset_count || 0} photos
                              </div>
                              <div className="flex space-x-1">
                                <Button variant="ghost" size="sm">
                                  <Eye className="w-3 h-3" />
                                </Button>
                                <Button variant="ghost" size="sm">
                                  <Edit className="w-3 h-3" />
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="equipment" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Equipment Management</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">Equipment management interface coming soon...</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>API Integrations</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <h4 className="font-medium">Google Drive</h4>
                        <p className="text-sm text-gray-600">Connect your photography storage</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        {connectionStatus?.connected ? (
                          <Badge variant="default">Connected</Badge>
                        ) : connectionStatus?.error ? (
                          <Badge variant="destructive">Not Configured</Badge>
                        ) : (
                          <Badge variant="secondary">Disconnected</Badge>
                        )}
                        <Button variant="outline" size="sm">Configure</Button>
                      </div>
                    </div>
                    <div className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <h4 className="font-medium">Database</h4>
                        <p className="text-sm text-gray-600">PostgreSQL connection</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant="default">Connected</Badge>
                        <Button variant="outline" size="sm">View Status</Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>System Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="font-medium">Total Assets:</span>
                      <p className="text-gray-600">{assets.length} files</p>
                    </div>
                    <div>
                      <span className="font-medium">Publications:</span>
                      <p className="text-gray-600">{publications.length} books</p>
                    </div>
                    <div>
                      <span className="font-medium">Collections:</span>
                      <p className="text-gray-600">{collections.length} collections</p>
                    </div>
                    <div>
                      <span className="font-medium">Clients:</span>
                      <p className="text-gray-600">{clients.length} active</p>
                    </div>
                  </div>
                  <div className="pt-4 border-t">
                    <Button variant="outline" size="sm" className="w-full">
                      <Download className="w-4 h-4 mr-2" />
                      Export Data
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>User Preferences</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="text-sm font-medium">Default Copyright</label>
                      <Input 
                        defaultValue="© Andrew Gwynn Photography" 
                        className="w-48 text-sm"
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <label className="text-sm font-medium">Default License</label>
                      <Select defaultValue="all-rights">
                        <SelectTrigger className="w-48">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all-rights">All Rights Reserved</SelectItem>
                          <SelectItem value="commercial">Commercial License</SelectItem>
                          <SelectItem value="editorial">Editorial License</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex items-center justify-between">
                      <label className="text-sm font-medium">Auto-generate AFX IDs</label>
                      <Button variant="outline" size="sm">Enabled</Button>
                    </div>
                  </div>
                  <div className="pt-4 border-t">
                    <Button size="sm" className="w-full">
                      Save Preferences
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Data Management</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <Button variant="outline" size="sm" className="w-full justify-start">
                      <Upload className="w-4 h-4 mr-2" />
                      Import Assets from CSV
                    </Button>
                    <Button variant="outline" size="sm" className="w-full justify-start">
                      <Download className="w-4 h-4 mr-2" />
                      Export Assets to CSV
                    </Button>
                    <Button variant="outline" size="sm" className="w-full justify-start">
                      <RefreshCw className="w-4 h-4 mr-2" />
                      Sync with Google Drive
                    </Button>
                  </div>
                  <div className="pt-4 border-t">
                    <p className="text-xs text-gray-500 mb-2">Danger Zone</p>
                    <Button variant="destructive" size="sm" className="w-full">
                      Reset All Data
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
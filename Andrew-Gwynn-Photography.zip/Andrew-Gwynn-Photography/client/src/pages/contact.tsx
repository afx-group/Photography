import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { motion } from "framer-motion";
import { useState } from "react";
import { MapPin, Phone, Mail, Clock, Send, Camera } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    service: "",
    location: "",
    date: "",
    message: ""
  });

  const contactMutation = useMutation({
    mutationFn: (data: any) => apiRequest('/api/contact', 'POST', data),
    onSuccess: () => {
      setFormData({
        name: "",
        email: "",
        phone: "",
        service: "",
        location: "",
        date: "",
        message: ""
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    contactMutation.mutate(formData);
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="overflow-x-hidden">
      <Navigation />

      <main className="pt-20">
        {/* Hero Section */}
        <section className="py-24 bg-gradient-to-br from-gray-900 to-gray-800 text-white">
          <div className="max-w-4xl mx-auto px-6 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="text-5xl md:text-6xl font-light mb-6">Get In Touch</h1>
              <div className="w-16 h-px bg-white mx-auto mb-6" />
              <p className="text-xl text-gray-300 leading-relaxed">
                Ready to discuss your photography project? Let's create something beautiful together.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Contact Form and Info */}
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
              {/* Contact Form */}
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8 }}
              >
                <Card className="h-full">
                  <CardHeader>
                    <CardTitle className="text-2xl">Project Inquiry</CardTitle>
                    <p className="text-gray-600">Tell me about your photography needs and I'll get back to you within 24 hours.</p>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleSubmit} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium mb-2">Name *</label>
                          <Input
                            required
                            value={formData.name}
                            onChange={(e) => handleInputChange('name', e.target.value)}
                            placeholder="Your full name"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium mb-2">Email *</label>
                          <Input
                            type="email"
                            required
                            value={formData.email}
                            onChange={(e) => handleInputChange('email', e.target.value)}
                            placeholder="your@email.com"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium mb-2">Phone</label>
                          <Input
                            value={formData.phone}
                            onChange={(e) => handleInputChange('phone', e.target.value)}
                            placeholder="Your phone number"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium mb-2">Service Type *</label>
                          <Select value={formData.service} onValueChange={(value) => handleInputChange('service', value)}>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a service" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="landscape">Landscape Photography</SelectItem>
                              <SelectItem value="portrait">Portrait Session</SelectItem>
                              <SelectItem value="wedding">Wedding Photography</SelectItem>
                              <SelectItem value="commercial">Commercial Work</SelectItem>
                              <SelectItem value="other">Other</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium mb-2">Location</label>
                          <Input
                            value={formData.location}
                            onChange={(e) => handleInputChange('location', e.target.value)}
                            placeholder="Where will the shoot take place?"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium mb-2">Preferred Date</label>
                          <Input
                            type="date"
                            value={formData.date}
                            onChange={(e) => handleInputChange('date', e.target.value)}
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-2">Project Details *</label>
                        <Textarea
                          required
                          rows={4}
                          value={formData.message}
                          onChange={(e) => handleInputChange('message', e.target.value)}
                          placeholder="Please describe your project, vision, and any specific requirements..."
                        />
                      </div>

                      <Button 
                        type="submit" 
                        className="w-full"
                        disabled={contactMutation.isPending}
                      >
                        {contactMutation.isPending ? (
                          "Sending..."
                        ) : (
                          <>
                            Send Inquiry
                            <Send className="ml-2 w-4 h-4" />
                          </>
                        )}
                      </Button>

                      {contactMutation.isSuccess && (
                        <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                          <p className="text-green-800">Thank you! Your inquiry has been sent. I'll get back to you within 24 hours.</p>
                        </div>
                      )}

                      {contactMutation.isError && (
                        <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                          <p className="text-red-800">There was an error sending your message. Please try again or contact me directly.</p>
                        </div>
                      )}
                    </form>
                  </CardContent>
                </Card>
              </motion.div>

              {/* Contact Information */}
              <motion.div
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="space-y-8"
              >
                <div>
                  <h2 className="text-3xl font-light mb-8 text-gray-900">Contact Information</h2>
                  
                  <div className="space-y-6">
                    <div className="flex items-start space-x-4">
                      <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                        <MapPin className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="font-semibold mb-1">Location</h3>
                        <p className="text-gray-600">Based in Scotland</p>
                        <p className="text-gray-600">Serving Edinburgh, Glasgow, Highlands & beyond</p>
                      </div>
                    </div>

                    <div className="flex items-start space-x-4">
                      <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center flex-shrink-0">
                        <Phone className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="font-semibold mb-1">Phone</h3>
                        <p className="text-gray-600">Available for inquiries</p>
                        <p className="text-sm text-gray-500">Response within 24 hours</p>
                      </div>
                    </div>

                    <div className="flex items-start space-x-4">
                      <div className="w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center flex-shrink-0">
                        <Mail className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="font-semibold mb-1">Email</h3>
                        <p className="text-gray-600">Professional correspondence</p>
                        <p className="text-sm text-gray-500">Quick response guaranteed</p>
                      </div>
                    </div>

                    <div className="flex items-start space-x-4">
                      <div className="w-12 h-12 bg-orange-600 rounded-full flex items-center justify-center flex-shrink-0">
                        <Clock className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="font-semibold mb-1">Availability</h3>
                        <p className="text-gray-600">Flexible scheduling</p>
                        <p className="text-sm text-gray-500">Including weekends and evenings</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* FAQ Section */}
                <Card>
                  <CardHeader>
                    <CardTitle>Frequently Asked Questions</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="font-semibold mb-2">How far do you travel?</h4>
                      <p className="text-sm text-gray-600">I'm based in Scotland and regularly work throughout the UK. International destination projects are also welcome.</p>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">What's included in the session?</h4>
                      <p className="text-sm text-gray-600">All sessions include professional editing, high-resolution digital files, and usage rights for personal use.</p>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">How long until I receive my photos?</h4>
                      <p className="text-sm text-gray-600">Typical turnaround is 1-2 weeks for most projects, with rush delivery available when needed.</p>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Do you offer payment plans?</h4>
                      <p className="text-sm text-gray-600">Yes, flexible payment options are available for larger projects and wedding photography.</p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="py-20 bg-gray-50">
          <div className="max-w-4xl mx-auto px-6 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <Camera className="w-16 h-16 text-blue-600 mx-auto mb-6" />
              <h2 className="text-4xl font-light mb-6 text-gray-900">Ready to Create Something Beautiful?</h2>
              <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                Every project is unique, and I'd love to hear about your vision. 
                Let's discuss how we can bring your ideas to life through photography.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button size="lg" className="px-8 py-4">
                  Start a Project
                </Button>
                <Button size="lg" variant="outline" className="px-8 py-4">
                  View Portfolio
                </Button>
              </div>
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
import { useState } from "react";
import { motion } from "framer-motion";
import { 
  Camera, 
  Image, 
  Book, 
  Users, 
  FolderOpen, 
  Settings, 
  Plus,
  Search,
  Cloud,
  RefreshCw,
  PenTool,
  ShoppingCart
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

const databaseTabs = [
  { id: "assets", label: "Assets", icon: Image, description: "Manage photos and media" },
  { id: "portfolio", label: "Portfolio", icon: Camera, description: "Advanced filtering & search" },
  { id: "drive", label: "Google Drive", icon: Cloud, description: "Import from Drive" },
  { id: "blog", label: "Blog", icon: PenTool, description: "Photography insights & tutorials" },
  { id: "testimonials", label: "Testimonials", icon: Users, description: "Client testimonials & case studies" },
  { id: "ecommerce", label: "Shop", icon: ShoppingCart, description: "Print sales & products" },
  { id: "publications", label: "Publications", icon: Book, description: "Photo books and prints" },
  { id: "collections", label: "Collections", icon: FolderOpen, description: "Organize content" },
  { id: "settings", label: "Settings", icon: Settings, description: "System configuration" },
];

export default function DatabaseDashboard() {
  const [activeTab, setActiveTab] = useState("assets");
  const [searchQuery, setSearchQuery] = useState("");

  // Fetch assets
  const { data: assets = [], isLoading: assetsLoading } = useQuery({
    queryKey: ['/api/assets'],
    queryFn: async () => {
      try {
        const response = await apiRequest('/api/assets', 'GET');
        return Array.isArray(response) ? response : [];
      } catch (error) {
        console.error('Failed to fetch assets:', error);
        return [];
      }
    }
  });

  // Fetch publications
  const { data: publications = [] } = useQuery({
    queryKey: ['/api/publications'],
    queryFn: async () => {
      try {
        const response = await apiRequest('/api/publications', 'GET');
        return Array.isArray(response) ? response : [];
      } catch (error) {
        console.error('Failed to fetch publications:', error);
        return [];
      }
    }
  });

  // Fetch clients
  const { data: clients = [] } = useQuery({
    queryKey: ['/api/clients'],
    queryFn: async () => {
      try {
        const response = await apiRequest('/api/clients', 'GET');
        return Array.isArray(response) ? response : [];
      } catch (error) {
        console.error('Failed to fetch clients:', error);
        return [];
      }
    }
  });

  // Fetch collections
  const { data: collections = [] } = useQuery({
    queryKey: ['/api/collections'],
    queryFn: async () => {
      try {
        const response = await apiRequest('/api/collections', 'GET');
        return Array.isArray(response) ? response : [];
      } catch (error) {
        console.error('Failed to fetch collections:', error);
        return [];
      }
    }
  });

  // Check Google Drive status
  const { data: driveStatus } = useQuery({
    queryKey: ['/api/google-drive/status'],
    queryFn: async () => {
      try {
        return await apiRequest('/api/google-drive/status');
      } catch (error) {
        return { connected: false };
      }
    }
  });

  const stats = [
    { label: "Total Assets", value: assets.length.toString(), change: "+12", color: "blue" },
    { label: "Publications", value: publications.length.toString(), change: "+1", color: "green" },
    { label: "Active Clients", value: clients.length.toString(), change: "0", color: "yellow" },
    { label: "Collections", value: collections.length.toString(), change: "+3", color: "purple" },
  ];

  if (assetsLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-4 text-blue-600" />
          <p className="text-gray-600">Loading database...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <h1 className="text-2xl font-semibold text-gray-900">
                Photography Database Management
              </h1>
              <Badge variant="secondary" className="hidden sm:inline-flex">
                AFX Studios
              </Badge>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="relative hidden md:block">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search assets..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 w-64"
                />
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Stats */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">
                        {stat.label}
                      </p>
                      <p className="text-2xl font-bold text-gray-900">
                        {stat.value}
                      </p>
                    </div>
                    <div className="flex items-center space-x-1">
                      <span className={`text-sm font-medium text-${stat.color}-600`}>
                        {stat.change}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Main Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 lg:grid-cols-9">
            {databaseTabs.map((tab) => (
              <TabsTrigger key={tab.id} value={tab.id} className="flex items-center space-x-2">
                <tab.icon className="w-4 h-4" />
                <span className="hidden sm:inline">{tab.label}</span>
              </TabsTrigger>
            ))}
          </TabsList>

          <TabsContent value="assets" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Photography Assets Database</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {assets.length === 0 ? (
                    <div className="text-center py-8">
                      <Image className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600">No assets found. Connect Google Drive to import your photography collection.</p>
                      <Button className="mt-4">
                        <Plus className="w-4 h-4 mr-2" />
                        Import Assets
                      </Button>
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Asset
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Category
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Date
                            </th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Status
                            </th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          {assets.map((asset: any) => (
                            <tr key={asset.id} className="hover:bg-gray-50">
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="flex items-center">
                                  <div className="w-10 h-10 bg-gray-200 rounded-lg flex items-center justify-center">
                                    <Camera className="w-5 h-5 text-gray-400" />
                                  </div>
                                  <div className="ml-4">
                                    <div className="text-sm font-medium text-gray-900">
                                      {asset.title || asset.fileName}
                                    </div>
                                    <div className="text-sm text-gray-500">
                                      {asset.afxId}
                                    </div>
                                  </div>
                                </div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                                  {asset.category || 'Uncategorized'}
                                </span>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {asset.dateTaken ? new Date(asset.dateTaken).toLocaleDateString() : 'Unknown'}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                                  asset.featured ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                                }`}>
                                  {asset.featured ? 'Featured' : 'Standard'}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="drive" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Google Drive Integration</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                  <Cloud className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Direct Google Drive Access</h3>
                  <p className="text-gray-600 mb-4">
                    Configure Google Drive service account credentials for automatic photo import
                  </p>
                  <div className="space-y-3">
                    <p className="text-sm text-gray-500">
                      Status: {driveStatus?.connected ? 'Connected' : 'Not Configured'}
                    </p>
                    {!driveStatus?.connected && (
                      <div className="text-sm text-gray-600 bg-blue-50 p-4 rounded-lg">
                        <p className="font-medium mb-2">To configure Google Drive:</p>
                        <ol className="list-decimal list-inside space-y-1">
                          <li>Add GOOGLE_DRIVE_SERVICE_ACCOUNT_KEY to environment variables</li>
                          <li>Include your photography folder IDs in GOOGLE_DRIVE_PHOTO_FOLDERS</li>
                          <li>System will automatically sync photos with metadata</li>
                        </ol>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="blog" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Photography Journal</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <PenTool className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">Blog management system ready for implementation.</p>
                  <Button className="mt-4">
                    <Plus className="w-4 h-4 mr-2" />
                    Create First Post
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="ecommerce" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>E-commerce & Print Sales</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <Card className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6 text-center">
                      <ShoppingCart className="w-12 h-12 text-blue-500 mx-auto mb-4" />
                      <h3 className="font-semibold mb-2">Print Orders</h3>
                      <p className="text-2xl font-bold text-gray-900">0</p>
                      <p className="text-sm text-gray-600">Active orders</p>
                    </CardContent>
                  </Card>
                  
                  <Card className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6 text-center">
                      <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <span className="text-green-600 font-bold">£</span>
                      </div>
                      <h3 className="font-semibold mb-2">Revenue</h3>
                      <p className="text-2xl font-bold text-gray-900">£0</p>
                      <p className="text-sm text-gray-600">This month</p>
                    </CardContent>
                  </Card>
                  
                  <Card className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6 text-center">
                      <Image className="w-12 h-12 text-purple-500 mx-auto mb-4" />
                      <h3 className="font-semibold mb-2">Products</h3>
                      <p className="text-2xl font-bold text-gray-900">0</p>
                      <p className="text-sm text-gray-600">Available prints</p>
                    </CardContent>
                  </Card>
                </div>

                <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                  <ShoppingCart className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Set Up Print Sales</h3>
                  <p className="text-gray-600 mb-4">
                    Configure your photography prints for direct sales through your website
                  </p>
                  <Button className="mt-4">
                    <Plus className="w-4 h-4 mr-2" />
                    Configure Shop
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Other tabs - simplified placeholder content */}
          {['portfolio', 'testimonials', 'publications', 'collections', 'settings'].map((tabId) => (
            <TabsContent key={tabId} value={tabId} className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>{databaseTabs.find(t => t.id === tabId)?.label} Management</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8">
                    <div className="w-12 h-12 bg-gray-200 rounded-lg flex items-center justify-center mx-auto mb-4">
                      {(() => {
                        const tab = databaseTabs.find(t => t.id === tabId);
                        const IconComponent = tab?.icon;
                        return IconComponent ? <IconComponent className="w-6 h-6 text-gray-400" /> : null;
                      })()}
                    </div>
                    <p className="text-gray-600">{databaseTabs.find(t => t.id === tabId)?.description}</p>
                    <Button className="mt-4">
                      <Plus className="w-4 h-4 mr-2" />
                      Configure
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </div>
  );
}
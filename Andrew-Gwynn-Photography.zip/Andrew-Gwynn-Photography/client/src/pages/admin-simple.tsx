import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export default function AdminSimple() {
  const [isConnecting, setIsConnecting] = useState(false);

  // Check Google Drive connection status
  const { data: connectionStatus, refetch } = useQuery({
    queryKey: ['/api/google-drive/status'],
    queryFn: () => apiRequest('/api/google-drive/status')
  });

  const handleConnectDrive = async () => {
    setIsConnecting(true);
    try {
      const response = await apiRequest('/api/google-drive/auth');
      if (response?.authUrl) {
        window.open(response.authUrl, '_blank');
      }
    } catch (error) {
      console.error('Failed to connect to Google Drive:', error);
    } finally {
      setIsConnecting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-4xl mx-auto space-y-8">
        <h1 className="text-3xl font-bold">Photography Admin Dashboard</h1>
        
        <Card>
          <CardHeader>
            <CardTitle>Google Drive Integration</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div>
                <h3 className="font-medium">Google Drive Connection</h3>
                <p className="text-sm text-gray-600">
                  Status: {connectionStatus?.connected ? 'Connected' : 'Not Connected'}
                </p>
              </div>
              <Button 
                onClick={handleConnectDrive}
                disabled={isConnecting || connectionStatus?.connected}
              >
                {isConnecting ? 'Connecting...' : connectionStatus?.connected ? 'Connected' : 'Connect Drive'}
              </Button>
            </div>
            
            <div className="text-sm text-gray-600">
              <p><strong>To connect Google Drive:</strong></p>
              <ol className="list-decimal ml-4 mt-2 space-y-1">
                <li>Click "Connect Drive" button above</li>
                <li>Authorize access to your Google Drive in the popup window</li>
                <li>Return here to browse and import your photography folders</li>
              </ol>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Next Steps</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm">
              <p>1. Connect Google Drive (above)</p>
              <p>2. Select photography folders from your Drive</p>
              <p>3. Import photos with automatic EXIF metadata extraction</p>
              <p>4. Manage your photography collection in the asset database</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { motion, useScroll, useTransform, useSpring } from "framer-motion";
import { useState, useEffect, useRef } from "react";
import { ArrowRight, Camera, Award, Users, MapPin, Phone, Mail, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export default function Home() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isLoaded, setIsLoaded] = useState(false);
  const heroRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Fetch real portfolio data
  const { data: assets = [] } = useQuery({
    queryKey: ['/api/assets'],
    queryFn: () => apiRequest('/api/assets')
  });

  const featuredAssets = assets.filter((asset: any) => asset.featured).slice(0, 3);

  // Smooth scroll setup
  const { scrollY } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"]
  });

  // Parallax transforms with spring physics
  const heroY = useSpring(useTransform(scrollY, [0, 1000], [0, -500]), {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  const heroOpacity = useSpring(useTransform(scrollY, [0, 600], [1, 0]), {
    stiffness: 100,
    damping: 30
  });

  const heroScale = useSpring(useTransform(scrollY, [0, 1000], [1, 1.1]), {
    stiffness: 100,
    damping: 30
  });

  const textY = useSpring(useTransform(scrollY, [0, 800], [0, -200]), {
    stiffness: 100,
    damping: 30
  });

  // Mouse parallax effect
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (window.innerWidth > 768) { // Only on desktop
        setMousePosition({
          x: (e.clientX - window.innerWidth / 2) * 0.01,
          y: (e.clientY - window.innerHeight / 2) * 0.01
        });
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  // Loading animation
  useEffect(() => {
    setIsLoaded(true);
  }, []);

  // Smooth scroll behavior
  useEffect(() => {
    document.documentElement.style.scrollBehavior = 'smooth';
    return () => {
      document.documentElement.style.scrollBehavior = 'auto';
    };
  }, []);

  return (
    <div ref={containerRef} className="overflow-x-hidden">
      <Navigation />

      <main>
        {/* Hero Section with Advanced Parallax */}
        <motion.section 
          ref={heroRef}
          className="relative h-screen flex items-center justify-center overflow-hidden"
          initial={{ opacity: 0 }}
          animate={{ opacity: isLoaded ? 1 : 0 }}
          transition={{ duration: 1.2, ease: "easeOut" }}
        >
          {/* Parallax Background Layers */}
          <motion.div 
            className="absolute inset-0 bg-gradient-to-br from-black/80 via-black/60 to-black/80 z-10"
            style={{ opacity: heroOpacity }}
          />
          
          {/* Dynamic Background with Mouse Parallax */}
          <motion.div 
            className="absolute inset-0 bg-cover bg-center will-change-transform"
            style={{
              y: heroY,
              scale: heroScale,
              x: mousePosition.x,
              rotateY: mousePosition.x * 0.1,
              backgroundImage: `url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 800"><defs><linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" style="stop-color:%23111827;stop-opacity:1" /><stop offset="30%" style="stop-color:%23374151;stop-opacity:1" /><stop offset="70%" style="stop-color:%231f2937;stop-opacity:1" /><stop offset="100%" style="stop-color:%23111827;stop-opacity:1" /></linearGradient><radialGradient id="radial" cx="50%" cy="50%" r="50%"><stop offset="0%" style="stop-color:%23ffffff;stop-opacity:0.1" /><stop offset="100%" style="stop-color:%23000000;stop-opacity:0.3" /></radialGradient></defs><rect width="1200" height="800" fill="url(%23grad)"/><rect width="1200" height="800" fill="url(%23radial)"/><circle cx="200" cy="150" r="3" fill="%23ffffff" opacity="0.4"/><circle cx="800" cy="200" r="2" fill="%23ffffff" opacity="0.3"/><circle cx="600" cy="400" r="4" fill="%23ffffff" opacity="0.2"/><circle cx="1000" cy="300" r="2" fill="%23ffffff" opacity="0.4"/><circle cx="300" cy="600" r="1" fill="%23ffffff" opacity="0.5"/><circle cx="900" cy="500" r="3" fill="%23ffffff" opacity="0.2"/></svg>')`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              filter: 'brightness(0.9) contrast(1.1)'
            }}
          />

          {/* Floating Elements */}
          <motion.div 
            className="absolute inset-0 z-5"
            style={{
              x: mousePosition.x * 0.5,
              y: mousePosition.y * 0.3
            }}
          >
            {[...Array(6)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-2 h-2 bg-white/20 rounded-full"
                style={{
                  top: `${20 + i * 15}%`,
                  left: `${10 + i * 15}%`,
                }}
                animate={{
                  y: [0, -20, 0],
                  opacity: [0.2, 0.6, 0.2],
                }}
                transition={{
                  duration: 3 + i * 0.5,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
              />
            ))}
          </motion.div>
          
          {/* Hero Content with Enhanced Animations */}
          <motion.div 
            className="relative z-20 text-center text-white max-w-6xl mx-auto px-4 sm:px-6 lg:px-8"
            style={{ 
              y: textY,
              x: mousePosition.x * 0.2
            }}
          >
            <motion.h1 
              className="text-4xl sm:text-6xl lg:text-8xl xl:text-9xl font-light mb-6 sm:mb-8 tracking-wide leading-tight"
              initial={{ opacity: 0, y: 60, scale: 0.8 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ 
                delay: 0.3, 
                duration: 1.2, 
                ease: [0.215, 0.610, 0.355, 1.000]
              }}
              style={{
                textShadow: '0 4px 20px rgba(0,0,0,0.3)',
                background: 'linear-gradient(180deg, #ffffff 0%, #e5e7eb 100%)',
                backgroundClip: 'text',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent'
              }}
            >
              Andrew Gwynn
            </motion.h1>
            
            <motion.div 
              className="w-16 sm:w-24 lg:w-32 h-px bg-gradient-to-r from-transparent via-white to-transparent mx-auto mb-6 sm:mb-8"
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: window.innerWidth > 1024 ? 128 : window.innerWidth > 640 ? 96 : 64, opacity: 1 }}
              transition={{ delay: 0.8, duration: 1.2, ease: "easeOut" }}
            />
            
            <motion.p 
              className="text-xl sm:text-2xl lg:text-3xl xl:text-4xl font-light mb-8 sm:mb-12 text-gray-200"
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ 
                delay: 1.1, 
                duration: 1, 
                ease: [0.215, 0.610, 0.355, 1.000]
              }}
              style={{
                textShadow: '0 2px 10px rgba(0,0,0,0.2)'
              }}
            >
              Photography
            </motion.p>
            
            <motion.p 
              className="text-base sm:text-lg lg:text-xl xl:text-2xl mb-12 sm:mb-16 text-gray-300 max-w-4xl mx-auto leading-relaxed px-4"
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ 
                delay: 1.4, 
                duration: 1, 
                ease: [0.215, 0.610, 0.355, 1.000]
              }}
              style={{
                textShadow: '0 2px 8px rgba(0,0,0,0.3)'
              }}
            >
              Capturing Scotland's dramatic landscapes and authentic human moments through 
              professional photography services across Edinburgh, the Highlands, and beyond.
            </motion.p>
            
            <motion.div 
              className="flex flex-col sm:flex-row gap-4 sm:gap-6 justify-center items-center px-4"
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ 
                delay: 1.7, 
                duration: 1, 
                ease: [0.215, 0.610, 0.355, 1.000]
              }}
            >
              <Link href="/portfolio">
                <motion.div
                  whileHover={{ 
                    scale: 1.05, 
                    boxShadow: "0 10px 30px rgba(255,255,255,0.2)" 
                  }}
                  whileTap={{ scale: 0.95 }}
                  transition={{ type: "spring", stiffness: 400, damping: 10 }}
                >
                  <Button 
                    size="lg" 
                    className="bg-white text-black hover:bg-gray-100 px-6 sm:px-8 py-3 sm:py-4 text-base sm:text-lg font-medium shadow-lg backdrop-blur-sm border border-white/20"
                  >
                    View Portfolio
                    <ArrowRight className="ml-2 w-4 h-4 sm:w-5 sm:h-5" />
                  </Button>
                </motion.div>
              </Link>
              <Link href="/contact">
                <motion.div
                  whileHover={{ 
                    scale: 1.05,
                    backgroundColor: "rgba(255,255,255,0.1)"
                  }}
                  whileTap={{ scale: 0.95 }}
                  transition={{ type: "spring", stiffness: 400, damping: 10 }}
                >
                  <Button 
                    size="lg" 
                    variant="outline" 
                    className="border-white/50 text-white hover:bg-white/10 hover:text-white px-6 sm:px-8 py-3 sm:py-4 text-base sm:text-lg font-medium backdrop-blur-sm"
                  >
                    Book Session
                    <Camera className="ml-2 w-4 h-4 sm:w-5 sm:h-5" />
                  </Button>
                </motion.div>
              </Link>
            </motion.div>
          </motion.div>
          
          {/* Enhanced Scroll Indicator */}
          <motion.div 
            className="absolute bottom-8 sm:bottom-12 left-1/2 transform -translate-x-1/2 text-white z-30"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 2.2, duration: 1 }}
            style={{ opacity: heroOpacity }}
          >
            <motion.div 
              className="w-6 h-10 sm:h-12 border-2 border-white/60 rounded-full flex justify-center p-2 backdrop-blur-sm"
              whileHover={{ borderColor: "rgba(255,255,255,1)" }}
            >
              <motion.div 
                className="w-1 h-2 sm:h-3 bg-white rounded-full"
                animate={{ y: [0, 12, 0], opacity: [0.5, 1, 0.5] }}
                transition={{ 
                  duration: 2.5, 
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              />
            </motion.div>
            <motion.p 
              className="text-xs sm:text-sm mt-3 sm:mt-4 opacity-70 font-light tracking-wide"
              animate={{ opacity: [0.5, 1, 0.5] }}
              transition={{ duration: 3, repeat: Infinity }}
            >
              Scroll to explore
            </motion.p>
          </motion.div>
        </motion.section>

        {/* Services Overview */}
        <section className="py-24 bg-white">
          <div className="max-w-7xl mx-auto px-6">
            <motion.div 
              className="text-center mb-20"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <h2 className="text-5xl font-light mb-6 text-gray-900">Photography Services</h2>
              <div className="w-16 h-px bg-gray-400 mx-auto mb-6" />
              <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
                Professional photography services across Scotland, specializing in landscapes, 
                portraits, weddings, and commercial work with a focus on natural beauty and authentic moments.
              </p>
            </motion.div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
              <motion.div 
                className="text-center group"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: 0.1 }}
                whileHover={{ y: -5 }}
              >
                <div className="w-20 h-20 bg-gradient-to-br from-blue-600 to-blue-700 rounded-full flex items-center justify-center mx-auto mb-8 group-hover:shadow-lg transition-all duration-300">
                  <Camera className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-2xl font-semibold mb-4 text-gray-900">Landscape Photography</h3>
                <p className="text-gray-600 leading-relaxed mb-6">
                  Capturing Scotland's dramatic landscapes, from the mysterious Highlands to rugged coastal scenes, 
                  showcasing the natural beauty that defines our homeland.
                </p>
                <Link href="/services#landscape">
                  <Button variant="ghost" className="text-blue-600 hover:text-blue-700">
                    Learn More <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </Link>
              </motion.div>
              
              <motion.div 
                className="text-center group"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: 0.2 }}
                whileHover={{ y: -5 }}
              >
                <div className="w-20 h-20 bg-gradient-to-br from-green-600 to-green-700 rounded-full flex items-center justify-center mx-auto mb-8 group-hover:shadow-lg transition-all duration-300">
                  <Users className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-2xl font-semibold mb-4 text-gray-900">Portrait Sessions</h3>
                <p className="text-gray-600 leading-relaxed mb-6">
                  Professional portraits and lifestyle photography with natural lighting, 
                  creating timeless images that capture your authentic self and special moments.
                </p>
                <Link href="/services#portraits">
                  <Button variant="ghost" className="text-green-600 hover:text-green-700">
                    Learn More <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </Link>
              </motion.div>
              
              <motion.div 
                className="text-center group"
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: 0.3 }}
                whileHover={{ y: -5 }}
              >
                <div className="w-20 h-20 bg-gradient-to-br from-purple-600 to-purple-700 rounded-full flex items-center justify-center mx-auto mb-8 group-hover:shadow-lg transition-all duration-300">
                  <Award className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-2xl font-semibold mb-4 text-gray-900">Commercial Work</h3>
                <p className="text-gray-600 leading-relaxed mb-6">
                  Professional photography for businesses, events, and commercial projects, 
                  delivering high-quality images that tell your brand's story effectively.
                </p>
                <Link href="/services#commercial">
                  <Button variant="ghost" className="text-purple-600 hover:text-purple-700">
                    Learn More <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </Link>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Featured Work */}
        <section className="py-24 bg-gray-50">
          <div className="max-w-7xl mx-auto px-6">
            <motion.div 
              className="text-center mb-20"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <h2 className="text-5xl font-light mb-6 text-gray-900">Featured Work</h2>
              <div className="w-16 h-px bg-gray-400 mx-auto mb-6" />
              <p className="text-xl text-gray-600">Recent projects and highlights from my portfolio</p>
            </motion.div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredAssets.length > 0 ? featuredAssets.map((asset: any, index: number) => (
                <motion.div 
                  key={asset.id}
                  className="group cursor-pointer"
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.8, delay: index * 0.1 }}
                  whileHover={{ y: -10 }}
                >
                  <div className="aspect-square bg-gradient-to-br from-gray-200 to-gray-300 rounded-lg overflow-hidden mb-6 group-hover:shadow-xl transition-all duration-300">
                    <div className="w-full h-full bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center">
                      <Camera className="w-16 h-16 text-gray-400" />
                    </div>
                  </div>
                  <h3 className="text-xl font-semibold mb-2 text-gray-900">{asset.title || asset.file_name}</h3>
                  <p className="text-gray-600 text-sm mb-3">{asset.category}</p>
                  <p className="text-gray-500 text-sm">{asset.description}</p>
                </motion.div>
              )) : (
                // Show sample work when no featured assets
                [
                  { title: "Edinburgh Castle Sunset", category: "Landscape", description: "Dramatic sunset over Scotland's iconic castle" },
                  { title: "Highland Mist", category: "Landscape", description: "Morning mist rolling through Scottish Highlands" },
                  { title: "Portrait Session", category: "Portrait", description: "Natural light portrait session in Edinburgh" }
                ].map((item, index) => (
                  <motion.div 
                    key={index}
                    className="group cursor-pointer"
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.8, delay: index * 0.1 }}
                    whileHover={{ y: -10 }}
                  >
                    <div className="aspect-square bg-gradient-to-br from-gray-200 to-gray-300 rounded-lg overflow-hidden mb-6 group-hover:shadow-xl transition-all duration-300">
                      <div className="w-full h-full bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center">
                        <Camera className="w-16 h-16 text-gray-400" />
                      </div>
                    </div>
                    <h3 className="text-xl font-semibold mb-2 text-gray-900">{item.title}</h3>
                    <p className="text-gray-600 text-sm mb-3">{item.category}</p>
                    <p className="text-gray-500 text-sm">{item.description}</p>
                  </motion.div>
                ))
              )}
            </div>
            
            <motion.div 
              className="text-center mt-16"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <Link href="/portfolio">
                <Button size="lg" variant="outline" className="px-8 py-4 text-lg">
                  View Full Portfolio
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
            </motion.div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="py-24 bg-gray-900 text-white">
          <div className="max-w-5xl mx-auto px-6 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <h2 className="text-5xl font-light mb-8">Ready to Create Something Beautiful?</h2>
              <p className="text-xl text-gray-300 mb-12 leading-relaxed max-w-3xl mx-auto">
                Whether you're looking for stunning landscape prints, professional portraits, 
                or commercial photography services, let's discuss your vision and bring it to life.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-8 justify-center items-center mb-12">
                <div className="flex items-center text-gray-300">
                  <MapPin className="w-6 h-6 mr-3 text-blue-400" />
                  <span className="text-lg">Scotland, UK</span>
                </div>
                <div className="flex items-center text-gray-300">
                  <Phone className="w-6 h-6 mr-3 text-blue-400" />
                  <span className="text-lg">Professional Service</span>
                </div>
                <div className="flex items-center text-gray-300">
                  <Mail className="w-6 h-6 mr-3 text-blue-400" />
                  <span className="text-lg">Quick Response</span>
                </div>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-6 justify-center">
                <Link href="/contact">
                  <Button size="lg" className="bg-blue-600 hover:bg-blue-700 px-8 py-4 text-lg">
                    Start Your Project
                    <ArrowRight className="ml-2 w-5 h-5" />
                  </Button>
                </Link>
                <Link href="/portfolio">
                  <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-black px-8 py-4 text-lg">
                    View My Work
                    <Play className="ml-2 w-5 h-5" />
                  </Button>
                </Link>
              </div>
            </motion.div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
}
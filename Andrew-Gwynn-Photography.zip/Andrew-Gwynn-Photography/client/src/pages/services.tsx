import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { motion } from "framer-motion";
import { Camera, Users, Building, Heart, MapPin, Clock, Check, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "wouter";

export default function Services() {
  const services = [
    {
      id: "landscape",
      title: "Landscape Photography",
      icon: MapPin,
      price: "From £300",
      duration: "Half/Full Day",
      description: "Capturing Scotland's dramatic landscapes, from the mysterious Highlands to rugged coastal scenes.",
      features: [
        "Professional landscape photography",
        "Golden hour and blue hour sessions",
        "Weather-appropriate scheduling",
        "High-resolution digital files",
        "Location scouting included",
        "Print-ready file formats"
      ],
      includes: [
        "Pre-session consultation",
        "Professional equipment",
        "Basic editing and color correction",
        "Online gallery delivery",
        "Usage rights for personal use"
      ]
    },
    {
      id: "portraits",
      title: "Portrait Sessions",
      icon: Users,
      price: "From £250",
      duration: "1-2 Hours",
      description: "Professional portraits and lifestyle photography with natural lighting and contemporary styling.",
      features: [
        "Individual and family portraits",
        "Professional headshots",
        "Lifestyle photography",
        "Natural light and studio options",
        "Wardrobe consultation",
        "Retouching included"
      ],
      includes: [
        "Pre-session consultation",
        "1-2 hour photo session",
        "Professional editing",
        "15-20 high-resolution images",
        "Online gallery for 30 days",
        "Print release for personal use"
      ]
    },
    {
      id: "commercial",
      title: "Commercial Photography",
      icon: Building,
      price: "From £500",
      duration: "Custom",
      description: "Professional photography for businesses, events, and commercial projects.",
      features: [
        "Corporate photography",
        "Event documentation",
        "Product photography",
        "Business headshots",
        "Marketing materials",
        "Brand photography"
      ],
      includes: [
        "Project consultation",
        "Professional equipment",
        "Advanced editing and retouching",
        "High-resolution digital files",
        "Commercial usage rights",
        "Rush delivery available"
      ]
    },
    {
      id: "weddings",
      title: "Wedding Photography",
      icon: Heart,
      price: "From £1200",
      duration: "Full Day",
      description: "Capturing your special day with a documentary approach and attention to authentic moments.",
      features: [
        "Full day coverage",
        "Documentary style photography",
        "Engagement sessions available",
        "Second photographer option",
        "Online gallery for guests",
        "Wedding album design"
      ],
      includes: [
        "Pre-wedding consultation",
        "8-10 hours coverage",
        "Professional editing",
        "300+ high-resolution images",
        "Online gallery for 90 days",
        "USB drive with all images"
      ]
    }
  ];

  return (
    <div className="overflow-x-hidden">
      <Navigation />

      <main className="pt-20">
        {/* Hero Section */}
        <section className="py-24 bg-gradient-to-br from-gray-900 to-gray-800 text-white">
          <div className="max-w-4xl mx-auto px-6 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="text-5xl md:text-6xl font-light mb-6">Photography Services</h1>
              <div className="w-16 h-px bg-white mx-auto mb-6" />
              <p className="text-xl text-gray-300 leading-relaxed">
                Professional photography services across Scotland, tailored to capture 
                your vision with artistic excellence and technical precision.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Services Grid */}
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              {services.map((service, index) => (
                <motion.div
                  key={service.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.8, delay: index * 0.2 }}
                >
                  <Card className="h-full hover:shadow-xl transition-all duration-300">
                    <CardHeader className="pb-6">
                      <div className="flex items-center justify-between mb-4">
                        <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-blue-700 rounded-full flex items-center justify-center">
                          <service.icon className="w-8 h-8 text-white" />
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-blue-600">{service.price}</div>
                          <div className="text-sm text-gray-600 flex items-center">
                            <Clock className="w-4 h-4 mr-1" />
                            {service.duration}
                          </div>
                        </div>
                      </div>
                      <CardTitle className="text-2xl mb-3">{service.title}</CardTitle>
                      <p className="text-gray-600 leading-relaxed">{service.description}</p>
                    </CardHeader>

                    <CardContent className="space-y-6">
                      <div>
                        <h4 className="font-semibold mb-3 text-gray-900">What's Included:</h4>
                        <ul className="space-y-2">
                          {service.includes.map((item, idx) => (
                            <li key={idx} className="flex items-center text-sm text-gray-700">
                              <Check className="w-4 h-4 text-green-600 mr-3 flex-shrink-0" />
                              {item}
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div>
                        <h4 className="font-semibold mb-3 text-gray-900">Service Features:</h4>
                        <div className="grid grid-cols-1 gap-2">
                          {service.features.map((feature, idx) => (
                            <div key={idx} className="flex items-center text-sm text-gray-600">
                              <div className="w-2 h-2 bg-blue-600 rounded-full mr-3 flex-shrink-0" />
                              {feature}
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="pt-4 border-t">
                        <Link href="/contact">
                          <Button className="w-full">
                            Book This Service
                            <ArrowRight className="ml-2 w-4 h-4" />
                          </Button>
                        </Link>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Process Section */}
        <section className="py-20 bg-gray-50">
          <div className="max-w-6xl mx-auto px-6">
            <motion.div 
              className="text-center mb-16"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <h2 className="text-4xl font-light mb-6 text-gray-900">How We Work Together</h2>
              <div className="w-16 h-px bg-gray-400 mx-auto mb-6" />
              <p className="text-xl text-gray-600">A collaborative approach to creating exceptional photography</p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                {
                  step: "01",
                  title: "Initial Consultation",
                  description: "We discuss your vision, requirements, and expectations to ensure we're perfectly aligned on the project goals."
                },
                {
                  step: "02",
                  title: "Planning & Preparation",
                  description: "Detailed planning including location scouting, timing, equipment preparation, and any special requirements."
                },
                {
                  step: "03",
                  title: "Photography Session",
                  description: "Professional photography session with attention to detail, creativity, and capturing the perfect moments."
                },
                {
                  step: "04",
                  title: "Post-Production",
                  description: "Professional editing, color correction, and retouching to deliver images that exceed your expectations."
                },
                {
                  step: "05",
                  title: "Delivery & Review",
                  description: "Final images delivered through a professional online gallery with download options and print recommendations."
                }
              ].map((item, index) => (
                <motion.div
                  key={index}
                  className="text-center"
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.8, delay: index * 0.1 }}
                >
                  <div className="w-16 h-16 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto mb-6 text-xl font-bold">
                    {item.step}
                  </div>
                  <h3 className="text-xl font-semibold mb-4 text-gray-900">{item.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{item.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Coverage Area */}
        <section className="py-20">
          <div className="max-w-4xl mx-auto px-6 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <h2 className="text-4xl font-light mb-6 text-gray-900">Coverage Area</h2>
              <div className="w-16 h-px bg-gray-400 mx-auto mb-8" />
              <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                Based in Scotland, I provide photography services across Edinburgh, Glasgow, 
                the Highlands, and throughout the UK. Travel to international locations available.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
                <div className="text-center">
                  <MapPin className="w-8 h-8 text-blue-600 mx-auto mb-3" />
                  <h4 className="font-semibold mb-2">Local Coverage</h4>
                  <p className="text-gray-600">Edinburgh & Glasgow areas</p>
                </div>
                <div className="text-center">
                  <MapPin className="w-8 h-8 text-blue-600 mx-auto mb-3" />
                  <h4 className="font-semibold mb-2">Regional</h4>
                  <p className="text-gray-600">Scotland & Northern England</p>
                </div>
                <div className="text-center">
                  <MapPin className="w-8 h-8 text-blue-600 mx-auto mb-3" />
                  <h4 className="font-semibold mb-2">Destination</h4>
                  <p className="text-gray-600">UK & International</p>
                </div>
              </div>

              <Link href="/contact">
                <Button size="lg" className="px-8 py-4">
                  Discuss Your Project
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
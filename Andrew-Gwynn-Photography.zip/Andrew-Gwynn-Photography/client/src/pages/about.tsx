import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { motion } from "framer-motion";
import { Camera, Award, MapPin, Clock, Heart, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function About() {
  const achievements = [
    { year: "2018", title: "Started Professional Photography", description: "Began focusing on Scottish landscape and portrait photography" },
    { year: "2019", title: "First Exhibition", description: "Solo exhibition featuring Highland landscapes in Edinburgh" },
    { year: "2020", title: "Commercial Recognition", description: "Began working with local businesses and tourism boards" },
    { year: "2021", title: "Publication Launch", description: "Released first photography book showcasing Scotland's beauty" },
    { year: "2022", title: "Award Recognition", description: "Received local photography awards for landscape work" },
    { year: "2023", title: "Expanded Services", description: "Added wedding and commercial photography to offerings" }
  ];

  const values = [
    {
      icon: Heart,
      title: "Authenticity",
      description: "Capturing genuine moments and natural beauty without artificiality."
    },
    {
      icon: Camera,
      title: "Technical Excellence",
      description: "Using professional equipment and techniques to deliver exceptional quality."
    },
    {
      icon: Users,
      title: "Client Focus",
      description: "Understanding your vision and exceeding your expectations."
    },
    {
      icon: MapPin,
      title: "Local Expertise",
      description: "Deep knowledge of Scotland's landscapes and best photography locations."
    }
  ];

  return (
    <div className="overflow-x-hidden">
      <Navigation />

      <main className="pt-20">
        {/* Hero Section */}
        <section className="py-24 bg-gradient-to-br from-gray-900 to-gray-800 text-white">
          <div className="max-w-4xl mx-auto px-6 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="text-5xl md:text-6xl font-light mb-6">About Andrew</h1>
              <div className="w-16 h-px bg-white mx-auto mb-6" />
              <p className="text-xl text-gray-300 leading-relaxed">
                Scottish photographer passionate about capturing the natural beauty 
                of our homeland and the authentic moments that define us.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Main Story */}
        <section className="py-20">
          <div className="max-w-6xl mx-auto px-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
              >
                <div className="aspect-square bg-gradient-to-br from-gray-200 to-gray-300 rounded-lg overflow-hidden">
                  <div className="w-full h-full bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center">
                    <Camera className="w-24 h-24 text-gray-400" />
                  </div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="space-y-6"
              >
                <h2 className="text-4xl font-light text-gray-900">My Journey</h2>
                <div className="w-16 h-px bg-gray-400" />
                <p className="text-lg text-gray-700 leading-relaxed">
                  Growing up in Scotland, I've always been surrounded by some of the world's most 
                  dramatic landscapes. What started as a hobby during university became a passion, 
                  and eventually evolved into a profession dedicated to showcasing the beauty 
                  that defines our homeland.
                </p>
                <p className="text-lg text-gray-700 leading-relaxed">
                  My work focuses on capturing authentic moments - whether it's the play of light 
                  across Highland peaks at dawn, the genuine emotion in a portrait session, or 
                  the quiet intimacy of a wedding ceremony. Each photograph tells a story, 
                  and I'm honored to help preserve these moments for generations to come.
                </p>
                <p className="text-lg text-gray-700 leading-relaxed">
                  When I'm not behind the camera, you'll find me exploring Scotland's hidden corners, 
                  planning the next adventure, or working with clients to bring their photographic 
                  visions to life. Photography isn't just my profession - it's my way of celebrating 
                  the extraordinary in the everyday.
                </p>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Values Section */}
        <section className="py-20 bg-gray-50">
          <div className="max-w-6xl mx-auto px-6">
            <motion.div 
              className="text-center mb-16"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <h2 className="text-4xl font-light mb-6 text-gray-900">What Drives My Work</h2>
              <div className="w-16 h-px bg-gray-400 mx-auto mb-6" />
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Every photograph is created with these core principles in mind
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {values.map((value, index) => (
                <motion.div
                  key={index}
                  className="flex items-start space-x-6 p-6 bg-white rounded-lg"
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.8, delay: index * 0.1 }}
                >
                  <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                    <value.icon className="w-8 h-8 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold mb-3 text-gray-900">{value.title}</h3>
                    <p className="text-gray-600 leading-relaxed">{value.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Timeline */}
        <section className="py-20">
          <div className="max-w-4xl mx-auto px-6">
            <motion.div 
              className="text-center mb-16"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <h2 className="text-4xl font-light mb-6 text-gray-900">Photography Journey</h2>
              <div className="w-16 h-px bg-gray-400 mx-auto mb-6" />
              <p className="text-xl text-gray-600">Key milestones in my photography career</p>
            </motion.div>

            <div className="space-y-8">
              {achievements.map((achievement, index) => (
                <motion.div
                  key={index}
                  className="flex items-start space-x-6"
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.8, delay: index * 0.1 }}
                >
                  <div className="w-20 h-20 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0 text-white font-bold">
                    {achievement.year}
                  </div>
                  <div className="pt-4">
                    <h3 className="text-xl font-semibold mb-2 text-gray-900">{achievement.title}</h3>
                    <p className="text-gray-600 leading-relaxed">{achievement.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Equipment & Approach */}
        <section className="py-20 bg-gray-50">
          <div className="max-w-6xl mx-auto px-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
              >
                <h2 className="text-3xl font-light mb-6 text-gray-900">Technical Approach</h2>
                <div className="w-16 h-px bg-gray-400 mb-6" />
                <p className="text-lg text-gray-700 leading-relaxed mb-6">
                  I use professional-grade equipment to ensure every image meets the highest 
                  standards. My kit includes full-frame cameras, premium lenses, and specialized 
                  equipment for various shooting conditions.
                </p>
                <p className="text-lg text-gray-700 leading-relaxed mb-6">
                  Whether it's the golden hour light on Highland peaks or the subtle expressions 
                  in a portrait session, I combine technical expertise with artistic vision to 
                  create images that truly stand out.
                </p>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <Award className="w-5 h-5 text-blue-600" />
                    <span className="text-gray-700">Professional Canon & Sony systems</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Award className="w-5 h-5 text-blue-600" />
                    <span className="text-gray-700">Specialized landscape & portrait lenses</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Award className="w-5 h-5 text-blue-600" />
                    <span className="text-gray-700">Professional lighting equipment</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Award className="w-5 h-5 text-blue-600" />
                    <span className="text-gray-700">Advanced post-processing workflow</span>
                  </div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: 0.2 }}
              >
                <h2 className="text-3xl font-light mb-6 text-gray-900">My Philosophy</h2>
                <div className="w-16 h-px bg-gray-400 mb-6" />
                <p className="text-lg text-gray-700 leading-relaxed mb-6">
                  Great photography isn't just about technical skill - it's about understanding 
                  light, composition, and most importantly, the story you want to tell. Every 
                  session is approached with patience, creativity, and attention to detail.
                </p>
                <p className="text-lg text-gray-700 leading-relaxed mb-6">
                  I believe in collaboration with my clients, taking time to understand their 
                  vision and working together to create images that exceed expectations. Whether 
                  it's a commercial project or personal portraits, the goal is always the same: 
                  creating photographs that will be treasured for years to come.
                </p>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <Clock className="w-5 h-5 text-green-600" />
                    <span className="text-gray-700">Collaborative planning process</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Clock className="w-5 h-5 text-green-600" />
                    <span className="text-gray-700">Patient, relaxed shooting style</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Clock className="w-5 h-5 text-green-600" />
                    <span className="text-gray-700">Professional post-production</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Clock className="w-5 h-5 text-green-600" />
                    <span className="text-gray-700">Timely delivery and communication</span>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="py-20 bg-gray-900 text-white">
          <div className="max-w-4xl mx-auto px-6 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <h2 className="text-4xl font-light mb-6">Let's Create Together</h2>
              <p className="text-xl text-gray-300 mb-8 leading-relaxed">
                Whether you're looking for stunning landscape prints, professional portraits, 
                or commercial photography services, I'd love to discuss your project.
              </p>
              <div className="flex flex-col sm:flex-row gap-6 justify-center">
                <Link href="/contact">
                  <Button size="lg" className="bg-blue-600 hover:bg-blue-700 px-8 py-4">
                    Start a Project
                  </Button>
                </Link>
                <Link href="/portfolio">
                  <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-black px-8 py-4">
                    View My Work
                  </Button>
                </Link>
              </div>
            </motion.div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
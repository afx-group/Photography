import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { motion } from "framer-motion";
import { useState } from "react";
import { Camera, Filter, Grid, List, Eye, Heart, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

export default function Portfolio() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  // Fetch portfolio data from database
  const { data: assets = [], isLoading } = useQuery({
    queryKey: ['/api/assets'],
    queryFn: () => apiRequest('/api/assets')
  });

  const categories = ['all', ...Array.from(new Set(assets.map((asset: any) => asset.category).filter(Boolean)))];

  const filteredAssets = assets.filter((asset: any) => {
    const matchesSearch = searchQuery === "" || 
      asset.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      asset.file_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      asset.description?.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = selectedCategory === "all" || asset.category === selectedCategory;
    
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="overflow-x-hidden">
      <Navigation />

      <main className="pt-20">
        {/* Hero Section */}
        <section className="py-24 bg-gray-900 text-white">
          <div className="max-w-4xl mx-auto px-6 text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="text-5xl md:text-6xl font-light mb-6">Portfolio</h1>
              <div className="w-16 h-px bg-white mx-auto mb-6" />
              <p className="text-xl text-gray-300 leading-relaxed">
                A collection of landscape, portrait, and commercial photography 
                showcasing Scotland's beauty and authentic human moments.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Filters and Controls */}
        <section className="py-12 bg-white border-b">
          <div className="max-w-7xl mx-auto px-6">
            <div className="flex flex-col md:flex-row justify-between items-center gap-6">
              <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
                <div className="relative">
                  <Input
                    placeholder="Search portfolio..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-64"
                  />
                </div>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Filter by category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category === 'all' ? 'All Categories' : category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-center gap-4">
                <span className="text-gray-600">{filteredAssets.length} images</span>
                <div className="flex items-center gap-2">
                  <Button
                    variant={viewMode === 'grid' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setViewMode('grid')}
                  >
                    <Grid className="w-4 h-4" />
                  </Button>
                  <Button
                    variant={viewMode === 'list' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setViewMode('list')}
                  >
                    <List className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Portfolio Grid */}
        <section className="py-16">
          <div className="max-w-7xl mx-auto px-6">
            {isLoading ? (
              <div className="text-center py-16">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
                <p className="text-gray-600">Loading portfolio...</p>
              </div>
            ) : filteredAssets.length === 0 ? (
              <div className="text-center py-16">
                <Camera className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2 text-gray-900">No images found</h3>
                <p className="text-gray-600">Try adjusting your search or filter criteria.</p>
              </div>
            ) : viewMode === 'grid' ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredAssets.map((asset: any, index: number) => (
                  <motion.div
                    key={asset.id}
                    className="group cursor-pointer"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                    whileHover={{ y: -5 }}
                  >
                    <div className="aspect-square bg-gradient-to-br from-gray-200 to-gray-300 rounded-lg overflow-hidden mb-4 group-hover:shadow-xl transition-all duration-300">
                      <div className="w-full h-full bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center relative">
                        <Camera className="w-12 h-12 text-gray-400" />
                        <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                          <div className="flex space-x-2">
                            <Button size="sm" variant="secondary">
                              <Eye className="w-4 h-4" />
                            </Button>
                            <Button size="sm" variant="secondary">
                              <Heart className="w-4 h-4" />
                            </Button>
                            <Button size="sm" variant="secondary">
                              <Share2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                    <h3 className="font-semibold mb-1 text-gray-900 group-hover:text-blue-600 transition-colors">
                      {asset.title || asset.file_name}
                    </h3>
                    <p className="text-sm text-gray-600 mb-2">{asset.category}</p>
                    <p className="text-xs text-gray-500 line-clamp-2">{asset.description}</p>
                    {asset.date_taken && (
                      <p className="text-xs text-gray-400 mt-2">
                        {new Date(asset.date_taken).toLocaleDateString()}
                      </p>
                    )}
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="space-y-6">
                {filteredAssets.map((asset: any, index: number) => (
                  <motion.div
                    key={asset.id}
                    className="flex flex-col md:flex-row gap-6 p-6 bg-white rounded-lg border hover:shadow-lg transition-shadow duration-300"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                  >
                    <div className="w-full md:w-48 h-48 bg-gradient-to-br from-gray-200 to-gray-300 rounded-lg overflow-hidden flex-shrink-0">
                      <div className="w-full h-full bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center">
                        <Camera className="w-12 h-12 text-gray-400" />
                      </div>
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="text-xl font-semibold mb-2 text-gray-900">
                            {asset.title || asset.file_name}
                          </h3>
                          <div className="flex items-center gap-4 text-sm text-gray-600 mb-3">
                            <span className="bg-gray-100 px-2 py-1 rounded">{asset.category}</span>
                            {asset.date_taken && (
                              <span>{new Date(asset.date_taken).toLocaleDateString()}</span>
                            )}
                            {asset.device_used && (
                              <span>{asset.device_used}</span>
                            )}
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <Button size="sm" variant="outline">
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button size="sm" variant="outline">
                            <Heart className="w-4 h-4" />
                          </Button>
                          <Button size="sm" variant="outline">
                            <Share2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                      <p className="text-gray-700 leading-relaxed mb-4">{asset.description}</p>
                      <div className="flex justify-between items-center">
                        <div className="text-sm text-gray-500">
                          {asset.gps_coordinates && (
                            <span>📍 {asset.gps_coordinates}</span>
                          )}
                        </div>
                        <div className="text-sm text-gray-500">
                          AFX ID: {asset.afx_id}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
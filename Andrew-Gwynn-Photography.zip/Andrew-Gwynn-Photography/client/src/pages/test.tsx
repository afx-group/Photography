export default function Test() {
  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <h1 className="text-2xl font-bold">Test Page Working</h1>
      <p>This is a simple test page to verify routing is working.</p>
    </div>
  );
}
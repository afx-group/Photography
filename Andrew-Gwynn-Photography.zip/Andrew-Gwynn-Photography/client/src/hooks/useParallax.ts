import { useTransform, useScroll } from "framer-motion";

export function useParallax(offset: number = 0.5) {
  const { scrollY } = useScroll();
  const y = useTransform(scrollY, [0, 1000], [0, -1000 * offset]);
  return y;
}

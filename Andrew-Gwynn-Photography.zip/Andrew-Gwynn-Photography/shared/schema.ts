import { pgTable, text, serial, integer, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { relations } from "drizzle-orm";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const contactInquiries = pgTable("contact_inquiries", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  service: text("service").notNull(),
  message: text("message").notNull(),
  status: text("status").default("new").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Core asset management tables
export const assets = pgTable("assets", {
  id: serial("id").primaryKey(),
  afxId: text("afx_id").notNull().unique(), // AFX_Studios_YYYY_MM_DD_XXXXX format
  dateTaken: timestamp("date_taken"),
  fileNumber: text("file_number").notNull(),
  fileName: text("file_name").notNull(),
  title: text("title"),
  description: text("description"),
  gpsCoordinates: text("gps_coordinates"),
  photographer: text("photographer").notNull(),
  deviceUsed: text("device_used"),
  copyrightStatus: text("copyright_status").default("Not Started").notNull(),
  licenseType: text("license_type"),
  fileLocation: text("file_location"),
  notes: text("notes"),
  category: text("category"), // landscape, portrait, event, artistic
  featured: integer("featured").default(0).notNull(),
  displayOrder: integer("display_order").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const publications = pgTable("publications", {
  id: serial("id").primaryKey(),
  number: integer("number").notNull(),
  type: text("type").notNull(), // Photo Book, etc.
  title: text("title").notNull(),
  isbn: text("isbn").unique(),
  publicationDate: timestamp("publication_date"),
  description: text("description"),
  status: text("status").default("Planning").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const assetPublications = pgTable("asset_publications", {
  id: serial("id").primaryKey(),
  assetId: integer("asset_id").references(() => assets.id).notNull(),
  publicationId: integer("publication_id").references(() => publications.id).notNull(),
  pageNumber: integer("page_number"),
  featured: integer("featured").default(0).notNull(),
});

export const collections = pgTable("collections", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  type: text("type").notNull(), // portfolio, client_work, personal, etc.
  status: text("status").default("active").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const assetCollections = pgTable("asset_collections", {
  id: serial("id").primaryKey(),
  assetId: integer("asset_id").references(() => assets.id).notNull(),
  collectionId: integer("collection_id").references(() => collections.id).notNull(),
  displayOrder: integer("display_order").default(0).notNull(),
});

export const clients = pgTable("clients", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email"),
  phone: text("phone"),
  company: text("company"),
  address: text("address"),
  notes: text("notes"),
  status: text("status").default("active").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  clientId: integer("client_id").references(() => clients.id),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  status: text("status").default("planning").notNull(),
  budget: text("budget"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const assetProjects = pgTable("asset_projects", {
  id: serial("id").primaryKey(),
  assetId: integer("asset_id").references(() => assets.id).notNull(),
  projectId: integer("project_id").references(() => projects.id).notNull(),
  role: text("role"), // primary, secondary, reference, etc.
});

export const equipment = pgTable("equipment", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // camera, lens, lighting, etc.
  brand: text("brand"),
  model: text("model"),
  serialNumber: text("serial_number"),
  purchaseDate: timestamp("purchase_date"),
  purchasePrice: text("purchase_price"),
  status: text("status").default("active").notNull(),
  notes: text("notes"),
});

export const tags = pgTable("tags", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  category: text("category"), // location, subject, style, etc.
  color: text("color").default("#gray").notNull(),
});

export const assetTags = pgTable("asset_tags", {
  id: serial("id").primaryKey(),
  assetId: integer("asset_id").references(() => assets.id).notNull(),
  tagId: integer("tag_id").references(() => tags.id).notNull(),
});

// Keep existing portfolioItems for public display compatibility
export const portfolioItems = pgTable("portfolio_items", {
  id: serial("id").primaryKey(),
  assetId: integer("asset_id").references(() => assets.id), // Link to internal asset
  title: text("title").notNull(),
  description: text("description"),
  category: text("category").notNull(), // landscape, portrait, event, artistic
  imageUrl: text("image_url").notNull(),
  altText: text("alt_text").notNull(),
  featured: integer("featured").default(0).notNull(), // 0 = false, 1 = true
  displayOrder: integer("display_order").default(0).notNull(),
  metadata: jsonb("metadata"), // for additional image data like EXIF
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const testimonials = pgTable("testimonials", {
  id: serial("id").primaryKey(),
  clientName: text("client_name").notNull(),
  clientTitle: text("client_title"),
  content: text("content").notNull(),
  rating: integer("rating").notNull(),
  featured: integer("featured").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Relations
export const assetsRelations = relations(assets, ({ many }) => ({
  publications: many(assetPublications),
  collections: many(assetCollections),
  projects: many(assetProjects),
  tags: many(assetTags),
  portfolioItems: many(portfolioItems),
}));

export const publicationsRelations = relations(publications, ({ many }) => ({
  assets: many(assetPublications),
}));

export const assetPublicationsRelations = relations(assetPublications, ({ one }) => ({
  asset: one(assets, { fields: [assetPublications.assetId], references: [assets.id] }),
  publication: one(publications, { fields: [assetPublications.publicationId], references: [publications.id] }),
}));

export const collectionsRelations = relations(collections, ({ many }) => ({
  assets: many(assetCollections),
}));

export const assetCollectionsRelations = relations(assetCollections, ({ one }) => ({
  asset: one(assets, { fields: [assetCollections.assetId], references: [assets.id] }),
  collection: one(collections, { fields: [assetCollections.collectionId], references: [collections.id] }),
}));

export const clientsRelations = relations(clients, ({ many }) => ({
  projects: many(projects),
}));

export const projectsRelations = relations(projects, ({ one, many }) => ({
  client: one(clients, { fields: [projects.clientId], references: [clients.id] }),
  assets: many(assetProjects),
}));

export const assetProjectsRelations = relations(assetProjects, ({ one }) => ({
  asset: one(assets, { fields: [assetProjects.assetId], references: [assets.id] }),
  project: one(projects, { fields: [assetProjects.projectId], references: [projects.id] }),
}));

export const tagsRelations = relations(tags, ({ many }) => ({
  assets: many(assetTags),
}));

export const assetTagsRelations = relations(assetTags, ({ one }) => ({
  asset: one(assets, { fields: [assetTags.assetId], references: [assets.id] }),
  tag: one(tags, { fields: [assetTags.tagId], references: [tags.id] }),
}));

export const contactInquiriesRelations = relations(contactInquiries, ({ one }) => ({}));
export const portfolioItemsRelations = relations(portfolioItems, ({ one }) => ({
  asset: one(assets, { fields: [portfolioItems.assetId], references: [assets.id] }),
}));
export const testimonialsRelations = relations(testimonials, ({ one }) => ({}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertContactInquirySchema = createInsertSchema(contactInquiries).pick({
  name: true,
  email: true,
  service: true,
  message: true,
});

export const insertPortfolioItemSchema = createInsertSchema(portfolioItems).pick({
  title: true,
  description: true,
  category: true,
  imageUrl: true,
  altText: true,
  featured: true,
  displayOrder: true,
  metadata: true,
});

export const insertTestimonialSchema = createInsertSchema(testimonials).pick({
  clientName: true,
  clientTitle: true,
  content: true,
  rating: true,
  featured: true,
});

export const insertAssetSchema = createInsertSchema(assets).pick({
  afxId: true,
  dateTaken: true,
  fileNumber: true,
  fileName: true,
  title: true,
  description: true,
  gpsCoordinates: true,
  photographer: true,
  deviceUsed: true,
  copyrightStatus: true,
  licenseType: true,
  fileLocation: true,
  notes: true,
  category: true,
  featured: true,
  displayOrder: true,
});

export const insertPublicationSchema = createInsertSchema(publications).pick({
  number: true,
  type: true,
  title: true,
  isbn: true,
  publicationDate: true,
  description: true,
  status: true,
});

export const insertCollectionSchema = createInsertSchema(collections).pick({
  name: true,
  description: true,
  type: true,
  status: true,
});

export const insertClientSchema = createInsertSchema(clients).pick({
  name: true,
  email: true,
  phone: true,
  company: true,
  address: true,
  notes: true,
  status: true,
});

export const insertProjectSchema = createInsertSchema(projects).pick({
  name: true,
  description: true,
  clientId: true,
  startDate: true,
  endDate: true,
  status: true,
  budget: true,
  notes: true,
});

export const insertEquipmentSchema = createInsertSchema(equipment).pick({
  name: true,
  type: true,
  brand: true,
  model: true,
  serialNumber: true,
  purchaseDate: true,
  purchasePrice: true,
  status: true,
  notes: true,
});

export const insertTagSchema = createInsertSchema(tags).pick({
  name: true,
  category: true,
  color: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertContactInquiry = z.infer<typeof insertContactInquirySchema>;
export type ContactInquiry = typeof contactInquiries.$inferSelect;
export type InsertPortfolioItem = z.infer<typeof insertPortfolioItemSchema>;
export type PortfolioItem = typeof portfolioItems.$inferSelect;
export type InsertTestimonial = z.infer<typeof insertTestimonialSchema>;
export type Testimonial = typeof testimonials.$inferSelect;

export type InsertAsset = z.infer<typeof insertAssetSchema>;
export type Asset = typeof assets.$inferSelect;
export type InsertPublication = z.infer<typeof insertPublicationSchema>;
export type Publication = typeof publications.$inferSelect;
export type InsertCollection = z.infer<typeof insertCollectionSchema>;
export type Collection = typeof collections.$inferSelect;
export type InsertClient = z.infer<typeof insertClientSchema>;
export type Client = typeof clients.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type Project = typeof projects.$inferSelect;
export type InsertEquipment = z.infer<typeof insertEquipmentSchema>;
export type Equipment = typeof equipment.$inferSelect;
export type InsertTag = z.infer<typeof insertTagSchema>;
export type Tag = typeof tags.$inferSelect;

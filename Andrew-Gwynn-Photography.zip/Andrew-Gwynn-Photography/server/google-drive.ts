import { google } from 'googleapis';
import { GoogleAuth, OAuth2Client } from 'google-auth-library';

// Initialize Google Drive API with service account or OAuth
let auth: GoogleAuth | OAuth2Client | null = null;
let drive: any = null;

try {
  if (process.env.GOOGLE_DRIVE_SERVICE_ACCOUNT_KEY) {
    const serviceAccountKey = JSON.parse(process.env.GOOGLE_DRIVE_SERVICE_ACCOUNT_KEY);
    auth = new GoogleAuth({
      credentials: serviceAccountKey,
      scopes: ['https://www.googleapis.com/auth/drive.readonly']
    });
    drive = google.drive({ version: 'v3', auth });
  } else if (process.env.GOOGLE_DRIVE_CLIENT_ID && process.env.GOOGLE_DRIVE_CLIENT_SECRET) {
    // Fallback to OAuth if service account not available
    auth = new OAuth2Client(
      process.env.GOOGLE_DRIVE_CLIENT_ID,
      process.env.GOOGLE_DRIVE_CLIENT_SECRET,
      process.env.NODE_ENV === 'production' ? 'https://andrew-gwynn-photography.replit.app/auth/google/callback' : 'http://localhost:5000/auth/google/callback'
    );
    drive = google.drive({ version: 'v3', auth });
  }
} catch (error) {
  console.error('Google Drive setup error:', error);
}

export class GoogleDriveService {
  private isAuthenticated = false;

  async checkConnection(): Promise<boolean> {
    try {
      if (!drive) return false;
      
      // Test connection by listing files from configured folders
      const photoFolders = process.env.GOOGLE_DRIVE_PHOTO_FOLDERS?.split(',') || ['root'];
      await drive.files.list({ 
        q: `'${photoFolders[0]}' in parents and trashed=false`,
        pageSize: 1 
      });
      
      this.isAuthenticated = true;
      return true;
    } catch (error) {
      console.error('Drive connection check failed:', error);
      this.isAuthenticated = false;
      return false;
    }
  }

  async getAuthUrl(): Promise<string> {
    // For service account, no auth URL needed
    if (process.env.GOOGLE_DRIVE_SERVICE_ACCOUNT_KEY) {
      return '';
    }

    // Fallback OAuth method
    const scopes = [
      'https://www.googleapis.com/auth/drive.readonly',
      'https://www.googleapis.com/auth/drive.metadata.readonly'
    ];

    const oauth2Client = new (require('google-auth-library')).OAuth2Client(
      process.env.GOOGLE_DRIVE_CLIENT_ID,
      process.env.GOOGLE_DRIVE_CLIENT_SECRET,
      process.env.NODE_ENV === 'production' ? 'https://andrew-gwynn-photography.replit.app/auth/google/callback' : 'http://localhost:5000/auth/google/callback'
    );

    return oauth2Client.generateAuthUrl({
      access_type: 'offline',
      scope: scopes,
      include_granted_scopes: true
    });
  }

  async setCredentials(code: string): Promise<void> {
    try {
      const { tokens } = await oauth2Client.getToken(code);
      oauth2Client.setCredentials(tokens);
      this.isAuthenticated = true;
    } catch (error) {
      console.error('Error setting credentials:', error);
      throw new Error('Failed to authenticate with Google Drive');
    }
  }

  async checkConnection(): Promise<boolean> {
    try {
      if (!this.isAuthenticated) {
        return false;
      }
      
      // Test the connection by trying to list files
      await drive.files.list({ pageSize: 1 });
      return true;
    } catch (error) {
      console.error('Drive connection check failed:', error);
      return false;
    }
  }

  async listFiles(folderId: string = 'root', query: string = ''): Promise<any[]> {
    try {
      if (!this.isAuthenticated) {
        throw new Error('Not authenticated with Google Drive');
      }

      let searchQuery = "mimeType contains 'image/'";
      
      if (folderId !== 'root') {
        searchQuery += ` and '${folderId}' in parents`;
      }
      
      if (query) {
        searchQuery += ` and name contains '${query}'`;
      }

      const response = await drive.files.list({
        q: searchQuery,
        pageSize: 100,
        fields: 'files(id,name,mimeType,size,createdTime,modifiedTime,webViewLink,webContentLink,thumbnailLink,imageMediaMetadata)',
        orderBy: 'modifiedTime desc'
      });

      return response.data.files || [];
    } catch (error) {
      console.error('Error listing Drive files:', error);
      throw new Error('Failed to fetch files from Google Drive');
    }
  }

  async getFileMetadata(fileId: string): Promise<any> {
    try {
      if (!this.isAuthenticated) {
        throw new Error('Not authenticated with Google Drive');
      }

      const response = await drive.files.get({
        fileId,
        fields: 'id,name,mimeType,size,createdTime,modifiedTime,webViewLink,webContentLink,thumbnailLink,imageMediaMetadata,parents'
      });

      return response.data;
    } catch (error) {
      console.error('Error getting file metadata:', error);
      throw new Error('Failed to get file metadata');
    }
  }

  async getFolders(): Promise<any[]> {
    try {
      if (!this.isAuthenticated) {
        throw new Error('Not authenticated with Google Drive');
      }

      const response = await drive.files.list({
        q: "mimeType='application/vnd.google-apps.folder'",
        pageSize: 50,
        fields: 'files(id,name,modifiedTime)',
        orderBy: 'name'
      });

      return response.data.files || [];
    } catch (error) {
      console.error('Error listing folders:', error);
      throw new Error('Failed to fetch folders from Google Drive');
    }
  }

  async downloadFile(fileId: string): Promise<Buffer> {
    try {
      if (!this.isAuthenticated) {
        throw new Error('Not authenticated with Google Drive');
      }

      const response = await drive.files.get({
        fileId,
        alt: 'media'
      }, { responseType: 'arraybuffer' });

      return Buffer.from(response.data as ArrayBuffer);
    } catch (error) {
      console.error('Error downloading file:', error);
      throw new Error('Failed to download file from Google Drive');
    }
  }

  isConnected(): boolean {
    return this.isAuthenticated;
  }
}

export const googleDriveService = new GoogleDriveService();
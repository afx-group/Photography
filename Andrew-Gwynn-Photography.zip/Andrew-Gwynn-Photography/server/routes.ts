import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { upload, extractPhotoMetadata } from "./upload";
import { googleDriveService } from "./google-drive";
import path from "path";
import { 
  insertContactInquirySchema, 
  insertPortfolioItemSchema, 
  insertTestimonialSchema,
  insertAssetSchema,
  insertPublicationSchema,
  insertClientSchema,
  insertCollectionSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Contact inquiry routes
  app.post("/api/contact", async (req, res) => {
    try {
      const inquiry = insertContactInquirySchema.parse(req.body);
      const createdInquiry = await storage.createContactInquiry(inquiry);
      res.json(createdInquiry);
    } catch (error) {
      console.error("Error creating contact inquiry:", error);
      res.status(400).json({ error: "Invalid contact data" });
    }
  });

  app.get("/api/contact", async (req, res) => {
    try {
      const inquiries = await storage.getContactInquiries();
      res.json(inquiries);
    } catch (error) {
      console.error("Error fetching contact inquiries:", error);
      res.status(500).json({ error: "Failed to fetch inquiries" });
    }
  });

  app.patch("/api/contact/:id/status", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status } = req.body;
      const updatedInquiry = await storage.updateContactInquiryStatus(id, status);
      if (!updatedInquiry) {
        return res.status(404).json({ error: "Inquiry not found" });
      }
      res.json(updatedInquiry);
    } catch (error) {
      console.error("Error updating inquiry status:", error);
      res.status(500).json({ error: "Failed to update status" });
    }
  });

  // Portfolio routes
  app.get("/api/portfolio", async (req, res) => {
    try {
      const category = req.query.category as string;
      let items;
      if (category) {
        items = await storage.getPortfolioItemsByCategory(category);
      } else {
        items = await storage.getPortfolioItems();
      }
      res.json(items);
    } catch (error) {
      console.error("Error fetching portfolio items:", error);
      res.status(500).json({ error: "Failed to fetch portfolio items" });
    }
  });

  app.post("/api/portfolio", async (req, res) => {
    try {
      const item = insertPortfolioItemSchema.parse(req.body);
      const createdItem = await storage.createPortfolioItem(item);
      res.json(createdItem);
    } catch (error) {
      console.error("Error creating portfolio item:", error);
      res.status(400).json({ error: "Invalid portfolio data" });
    }
  });

  app.patch("/api/portfolio/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const updatedItem = await storage.updatePortfolioItem(id, updates);
      if (!updatedItem) {
        return res.status(404).json({ error: "Portfolio item not found" });
      }
      res.json(updatedItem);
    } catch (error) {
      console.error("Error updating portfolio item:", error);
      res.status(500).json({ error: "Failed to update portfolio item" });
    }
  });

  app.delete("/api/portfolio/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deletePortfolioItem(id);
      if (!deleted) {
        return res.status(404).json({ error: "Portfolio item not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting portfolio item:", error);
      res.status(500).json({ error: "Failed to delete portfolio item" });
    }
  });

  // Testimonial routes
  app.get("/api/testimonials", async (req, res) => {
    try {
      const featured = req.query.featured === "true";
      let testimonials;
      if (featured) {
        testimonials = await storage.getFeaturedTestimonials();
      } else {
        testimonials = await storage.getTestimonials();
      }
      res.json(testimonials);
    } catch (error) {
      console.error("Error fetching testimonials:", error);
      res.status(500).json({ error: "Failed to fetch testimonials" });
    }
  });

  app.post("/api/testimonials", async (req, res) => {
    try {
      const testimonial = insertTestimonialSchema.parse(req.body);
      const createdTestimonial = await storage.createTestimonial(testimonial);
      res.json(createdTestimonial);
    } catch (error) {
      console.error("Error creating testimonial:", error);
      res.status(400).json({ error: "Invalid testimonial data" });
    }
  });

  app.patch("/api/testimonials/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const updatedTestimonial = await storage.updateTestimonial(id, updates);
      if (!updatedTestimonial) {
        return res.status(404).json({ error: "Testimonial not found" });
      }
      res.json(updatedTestimonial);
    } catch (error) {
      console.error("Error updating testimonial:", error);
      res.status(500).json({ error: "Failed to update testimonial" });
    }
  });

  app.delete("/api/testimonials/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteTestimonial(id);
      if (!deleted) {
        return res.status(404).json({ error: "Testimonial not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting testimonial:", error);
      res.status(500).json({ error: "Failed to delete testimonial" });
    }
  });

  // Photo upload with EXIF extraction
  app.post("/api/upload-photo", upload.single('photo'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "No photo uploaded" });
      }

      const filePath = req.file.path;
      const metadata = await extractPhotoMetadata(filePath);
      
      const extractedData = {
        fileName: req.file.originalname,
        filePath: req.file.filename,
        title: metadata?.description || req.file.originalname.replace(/\.[^/.]+$/, ""),
        description: metadata?.description || "",
        photographer: metadata?.artist || "Andrew Gwynn",
        deviceUsed: metadata?.camera || "",
        lens: metadata?.lens || "",
        dateTaken: metadata?.dateTaken || "",
        gpsCoordinates: metadata?.gpsCoordinates || "",
        copyrightStatus: metadata?.copyright || "© Andrew Gwynn Photography",
        settings: metadata?.settings || "",
        width: metadata?.width || 0,
        height: metadata?.height || 0,
        tags: metadata?.tags || [],
        fileSize: req.file.size,
        mimeType: req.file.mimetype
      };

      res.json(extractedData);
    } catch (error) {
      console.error("Error processing photo upload:", error);
      res.status(500).json({ error: "Failed to process photo" });
    }
  });

  // Asset routes
  app.get("/api/assets", async (req, res) => {
    try {
      const category = req.query.category as string;
      let assets;
      if (category) {
        assets = await storage.getAssetsByCategory(category);
      } else {
        assets = await storage.getAssets();
      }
      res.json(assets);
    } catch (error) {
      console.error("Error fetching assets:", error);
      res.status(500).json({ error: "Failed to fetch assets" });
    }
  });

  app.post("/api/assets", async (req, res) => {
    try {
      const asset = insertAssetSchema.parse(req.body);
      const createdAsset = await storage.createAsset(asset);
      res.json(createdAsset);
    } catch (error) {
      console.error("Error creating asset:", error);
      res.status(400).json({ error: "Invalid asset data" });
    }
  });

  app.patch("/api/assets/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const updatedAsset = await storage.updateAsset(id, updates);
      if (!updatedAsset) {
        return res.status(404).json({ error: "Asset not found" });
      }
      res.json(updatedAsset);
    } catch (error) {
      console.error("Error updating asset:", error);
      res.status(500).json({ error: "Failed to update asset" });
    }
  });

  app.delete("/api/assets/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteAsset(id);
      if (!deleted) {
        return res.status(404).json({ error: "Asset not found" });
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting asset:", error);
      res.status(500).json({ error: "Failed to delete asset" });
    }
  });

  // Publication routes
  app.get("/api/publications", async (req, res) => {
    try {
      const publications = await storage.getPublications();
      res.json(publications);
    } catch (error) {
      console.error("Error fetching publications:", error);
      res.status(500).json({ error: "Failed to fetch publications" });
    }
  });

  app.post("/api/publications", async (req, res) => {
    try {
      const publication = insertPublicationSchema.parse(req.body);
      const createdPublication = await storage.createPublication(publication);
      res.json(createdPublication);
    } catch (error) {
      console.error("Error creating publication:", error);
      res.status(400).json({ error: "Invalid publication data" });
    }
  });

  // Client routes
  app.get("/api/clients", async (req, res) => {
    try {
      const clients = await storage.getClients();
      res.json(clients);
    } catch (error) {
      console.error("Error fetching clients:", error);
      res.status(500).json({ error: "Failed to fetch clients" });
    }
  });

  app.post("/api/clients", async (req, res) => {
    try {
      const client = insertClientSchema.parse(req.body);
      const createdClient = await storage.createClient(client);
      res.json(createdClient);
    } catch (error) {
      console.error("Error creating client:", error);
      res.status(400).json({ error: "Invalid client data" });
    }
  });

  // Collection routes
  app.get("/api/collections", async (req, res) => {
    try {
      const collections = await storage.getCollections();
      res.json(collections);
    } catch (error) {
      console.error("Error fetching collections:", error);
      res.status(500).json({ error: "Failed to fetch collections" });
    }
  });

  app.post("/api/collections", async (req, res) => {
    try {
      const collection = insertCollectionSchema.parse(req.body);
      const createdCollection = await storage.createCollection(collection);
      res.json(createdCollection);
    } catch (error) {
      console.error("Error creating collection:", error);
      res.status(400).json({ error: "Invalid collection data" });
    }
  });

  // Google Drive API routes
  app.get("/api/google-drive/status", async (req, res) => {
    try {
      // Check if credentials are configured
      if (!process.env.GOOGLE_DRIVE_CLIENT_ID || !process.env.GOOGLE_DRIVE_CLIENT_SECRET) {
        return res.json({ 
          connected: false, 
          error: "Google Drive API credentials not configured. Please provide GOOGLE_DRIVE_CLIENT_ID and GOOGLE_DRIVE_CLIENT_SECRET." 
        });
      }
      
      const connected = googleDriveService.isConnected();
      res.json({ connected });
    } catch (error) {
      console.error("Error checking Google Drive status:", error);
      res.status(500).json({ error: "Failed to check Google Drive status" });
    }
  });

  app.post("/api/google-drive/connect", async (req, res) => {
    try {
      const authUrl = await googleDriveService.getAuthUrl();
      res.json({ authUrl });
    } catch (error) {
      console.error("Error generating Google Drive auth URL:", error);
      res.status(500).json({ error: "Failed to generate auth URL" });
    }
  });

  app.get("/auth/google/callback", async (req, res) => {
    try {
      const { code } = req.query;
      if (!code) {
        return res.status(400).json({ error: "No authorization code provided" });
      }
      
      await googleDriveService.setCredentials(code as string);
      res.redirect('/admin?drive=connected');
    } catch (error) {
      console.error("Error handling Google Drive callback:", error);
      res.status(500).json({ error: "Failed to authenticate with Google Drive" });
    }
  });

  app.get("/api/google-drive/files", async (req, res) => {
    try {
      const { folder = 'root', q = '' } = req.query;
      const files = await googleDriveService.listFiles(folder as string, q as string);
      res.json(files);
    } catch (error) {
      console.error("Error fetching Google Drive files:", error);
      res.status(500).json({ error: "Failed to fetch files from Google Drive" });
    }
  });

  app.post("/api/google-drive/import", async (req, res) => {
    try {
      const driveFile = req.body;
      
      // Extract metadata from Drive file
      const assetData = {
        afxId: `DRIVE-${driveFile.id}`,
        fileNumber: driveFile.id.substring(0, 8),
        fileName: driveFile.name,
        title: driveFile.name.replace(/\.[^/.]+$/, ""),
        description: `Imported from Google Drive: ${driveFile.name}`,
        category: driveFile.mimeType.includes('image') ? 'Photography' : 'Other',
        photographer: 'Andrew Gwynn',
        deviceUsed: driveFile.imageMediaMetadata?.cameraMake && driveFile.imageMediaMetadata?.cameraModel 
          ? `${driveFile.imageMediaMetadata.cameraMake} ${driveFile.imageMediaMetadata.cameraModel}` 
          : '',
        dateTaken: driveFile.imageMediaMetadata?.time || driveFile.createdTime,
        gpsCoordinates: driveFile.imageMediaMetadata?.location 
          ? `${driveFile.imageMediaMetadata.location.latitude},${driveFile.imageMediaMetadata.location.longitude}` 
          : '',
        copyrightStatus: '© Andrew Gwynn Photography',
        licenseType: 'All Rights Reserved',
        fileLocation: driveFile.webViewLink,
        notes: `Google Drive file ID: ${driveFile.id}`,
        featured: 0
      };

      const newAsset = await storage.createAsset(assetData);
      res.json(newAsset);
    } catch (error) {
      console.error("Error importing Google Drive file:", error);
      res.status(500).json({ error: "Failed to import file from Google Drive" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}

import multer from 'multer';
import path from 'path';
import fs from 'fs';
import exifr from 'exifr';

// Ensure uploads directory exists
const uploadsDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadsDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const fileFilter = (req: any, file: any, cb: any) => {
  // Accept only image files
  if (file.mimetype.startsWith('image/')) {
    cb(null, true);
  } else {
    cb(new Error('Only image files are allowed'), false);
  }
};

export const upload = multer({
  storage: storage,
  fileFilter: fileFilter,
  limits: {
    fileSize: 50 * 1024 * 1024 // 50MB limit
  }
});

export async function extractPhotoMetadata(filePath: string) {
  try {
    const exifData = await exifr.parse(filePath, true);

    if (!exifData) {
      return null;
    }

    // Extract GPS coordinates
    let gpsCoordinates = '';
    if (exifData.latitude && exifData.longitude) {
      gpsCoordinates = `${exifData.latitude.toFixed(6)},${exifData.longitude.toFixed(6)}`;
    }

    // Format date taken
    let dateTaken = '';
    if (exifData.DateTimeOriginal || exifData.DateTime || exifData.CreateDate) {
      const date = exifData.DateTimeOriginal || exifData.DateTime || exifData.CreateDate;
      dateTaken = date instanceof Date ? date.toISOString().split('T')[0] : 
                  typeof date === 'string' ? new Date(date).toISOString().split('T')[0] : '';
    }

    // Extract camera and lens information
    const camera = exifData.Make && exifData.Model ? 
      `${exifData.Make} ${exifData.Model}`.trim() : '';
    
    const lens = exifData.LensModel || exifData.LensInfo || '';

    // Extract technical settings
    const settings = [];
    if (exifData.ISO) settings.push(`ISO ${exifData.ISO}`);
    if (exifData.FNumber) settings.push(`f/${exifData.FNumber}`);
    if (exifData.ExposureTime) {
      const exposure = exifData.ExposureTime < 1 ? 
        `1/${Math.round(1 / exifData.ExposureTime)}s` : 
        `${exifData.ExposureTime}s`;
      settings.push(exposure);
    }
    if (exifData.FocalLength) settings.push(`${exifData.FocalLength}mm`);

    // Extract image dimensions
    const width = exifData.ExifImageWidth || exifData.ImageWidth || 0;
    const height = exifData.ExifImageHeight || exifData.ImageHeight || 0;

    // Extract copyright and artist information
    const artist = exifData.Artist || exifData.Creator || '';
    const copyright = exifData.Copyright || '';

    // Extract description/caption
    const description = exifData.ImageDescription || exifData.Description || 
                       exifData.Caption || exifData['Caption-Abstract'] || '';

    // Extract keywords/tags
    const keywords = exifData.Keywords || exifData.Subject || [];
    const tags = Array.isArray(keywords) ? keywords : 
                 typeof keywords === 'string' ? keywords.split(',').map(k => k.trim()) : [];

    return {
      dateTaken,
      gpsCoordinates,
      camera,
      lens,
      settings: settings.join(', '),
      width,
      height,
      artist,
      copyright,
      description,
      tags,
      raw: exifData
    };
  } catch (error) {
    console.error('Error extracting EXIF data:', error);
    return null;
  }
}